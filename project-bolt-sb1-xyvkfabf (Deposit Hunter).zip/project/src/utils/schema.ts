export interface OrganizationSchema {
  '@context': string;
  '@type': string;
  name: string;
  url: string;
  logo: string;
  description: string;
  email: string;
  foundingDate: string;
  sameAs?: string[];
}

export interface WebSiteSchema {
  '@context': string;
  '@type': string;
  name: string;
  url: string;
  description: string;
  publisher: {
    '@type': string;
    name: string;
  };
}

export interface ArticleSchema {
  '@context': string;
  '@type': string;
  headline: string;
  description: string;
  author: {
    '@type': string;
    name: string;
  };
  publisher: {
    '@type': string;
    name: string;
    logo: {
      '@type': string;
      url: string;
    };
  };
  datePublished: string;
  dateModified: string;
  mainEntityOfPage: string;
}

export interface BreadcrumbSchema {
  '@context': string;
  '@type': string;
  itemListElement: Array<{
    '@type': string;
    position: number;
    name: string;
    item?: string;
  }>;
}

export interface FAQSchema {
  '@context': string;
  '@type': string;
  mainEntity: Array<{
    '@type': string;
    name: string;
    acceptedAnswer: {
      '@type': string;
      text: string;
    };
  }>;
}

export function generateOrganizationSchema(): OrganizationSchema {
  const baseUrl = import.meta.env.VITE_APP_URL || 'https://www.deposithunter.com';

  return {
    '@context': 'https://schema.org',
    '@type': 'EducationalOrganization',
    name: 'DepositHunter - Portal Educacional',
    url: baseUrl,
    logo: `${baseUrl}/deposithunter.png`,
    description: 'Independent educational portal dedicated to financial safety, consumer protection, and financial literacy in Portugal. No commercial partnerships or affiliate relationships.',
    email: 'info@deposithunter.com',
    foundingDate: '2024',
    sameAs: []
  };
}

export function generateWebSiteSchema(): WebSiteSchema {
  const baseUrl = import.meta.env.VITE_APP_URL || 'https://www.deposithunter.com';

  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'DepositHunter',
    url: baseUrl,
    description: '100% independent educational resource about financial safety and consumer protection in Portugal',
    publisher: {
      '@type': 'EducationalOrganization',
      name: 'DepositHunter'
    }
  };
}

export function generateArticleSchema(
  headline: string,
  description: string,
  datePublished: string,
  dateModified: string,
  slug: string
): ArticleSchema {
  const baseUrl = import.meta.env.VITE_APP_URL || 'https://www.deposithunter.com';

  return {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline,
    description,
    author: {
      '@type': 'Organization',
      name: 'DepositHunter Editorial Team'
    },
    publisher: {
      '@type': 'EducationalOrganization',
      name: 'DepositHunter',
      logo: {
        '@type': 'ImageObject',
        url: `${baseUrl}/deposithunter.png`
      }
    },
    datePublished,
    dateModified,
    mainEntityOfPage: `${baseUrl}${slug}`
  };
}

export function generateBreadcrumbSchema(items: Array<{ name: string; url?: string }>): BreadcrumbSchema {
  const baseUrl = import.meta.env.VITE_APP_URL || 'https://www.deposithunter.com';

  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      ...(item.url && { item: `${baseUrl}${item.url}` })
    }))
  };
}

export function generateFAQSchema(faqs: Array<{ question: string; answer: string }>): FAQSchema {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(faq => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer
      }
    }))
  };
}

export function injectSchemaMarkup(schema: object): void {
  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.text = JSON.stringify(schema);
  document.head.appendChild(script);
}
