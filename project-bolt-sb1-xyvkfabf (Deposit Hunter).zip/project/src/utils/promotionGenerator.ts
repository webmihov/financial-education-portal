import { supabase } from '../lib/supabase';
import { LeadGenPage, LeadGenPromotion, PromotionType, PlacementPosition, TargetLocation } from '../types';

export interface PromotionGenerationResult {
  success: boolean;
  created: number;
  skipped: number;
  errors: string[];
  details: Array<{
    pageName: string;
    promotionsCreated: number;
    status: 'created' | 'skipped' | 'error';
    reason?: string;
  }>;
}

export interface PromotionDistributionConfig {
  type: PromotionType;
  position: PlacementPosition;
  count: number;
}

interface PromotionTemplate {
  type: PromotionType;
  position: PlacementPosition;
  titleTemplate: (pageName: string) => string;
  descriptionTemplate: (pageName: string) => string;
  ctaText: string;
  targetLocations: TargetLocation[];
}

const ENHANCED_TEMPLATES: PromotionTemplate[] = [
  {
    type: 'text_ad',
    position: 'top',
    titleTemplate: (name) => `Novo: ${name}`,
    descriptionTemplate: (name) => `Guia educacional disponível`,
    ctaText: 'Ver Guia',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'text_ad',
    position: 'top',
    titleTemplate: (name) => `Atualizado: ${name}`,
    descriptionTemplate: (name) => `Informação revista`,
    ctaText: 'Ler Agora',
    targetLocations: ['article'],
  },
  {
    type: 'text_ad',
    position: 'middle',
    titleTemplate: (name) => `Em destaque: ${name}`,
    descriptionTemplate: (name) => `Guia educacional disponível`,
    ctaText: 'Aceder',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'text_ad',
    position: 'middle',
    titleTemplate: (name) => `Aprenda: ${name}`,
    descriptionTemplate: (name) => `Recurso educacional gratuito`,
    ctaText: 'Ver Guia',
    targetLocations: ['article'],
  },
  {
    type: 'text_ad',
    position: 'middle',
    titleTemplate: (name) => `Descubra: ${name}`,
    descriptionTemplate: (name) => `Informação completa e atualizada`,
    ctaText: 'Explorar',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'inline_card',
    position: 'middle',
    titleTemplate: (name) => `Guia Completo: ${name}`,
    descriptionTemplate: (name) => `Explore o nosso guia educacional detalhado sobre ${name.toLowerCase()}. Informação verificada e atualizada por especialistas.`,
    ctaText: 'Descarregar Guia',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'inline_card',
    position: 'middle',
    titleTemplate: (name) => `Aprenda Mais: ${name}`,
    descriptionTemplate: (name) => `Recursos educacionais sobre ${name.toLowerCase()} com análise de riscos e melhores práticas do mercado português.`,
    ctaText: 'Ver Guia Completo',
    targetLocations: ['article'],
  },
  {
    type: 'inline_card',
    position: 'middle',
    titleTemplate: (name) => `Tudo sobre ${name}`,
    descriptionTemplate: (name) => `Guia educacional gratuito com informação regulatória e dicas práticas sobre ${name.toLowerCase()}.`,
    ctaText: 'Aceder ao Guia',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'inline_card',
    position: 'top',
    titleTemplate: (name) => `Novo Recurso: ${name}`,
    descriptionTemplate: (name) => `Obtenha acesso ao nosso guia educacional completo sobre ${name.toLowerCase()}. Informação verificada e atualizada.`,
    ctaText: 'Aceder ao Guia',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'inline_card',
    position: 'top',
    titleTemplate: (name) => `Introdução: ${name}`,
    descriptionTemplate: (name) => `Comece a aprender sobre ${name.toLowerCase()} com o nosso guia educacional gratuito e completo.`,
    ctaText: 'Começar Agora',
    targetLocations: ['article'],
  },
  {
    type: 'inline_card',
    position: 'bottom',
    titleTemplate: (name) => `Material Adicional: ${name}`,
    descriptionTemplate: (name) => `Aprofunde os seus conhecimentos sobre ${name.toLowerCase()} com recursos educacionais adicionais.`,
    ctaText: 'Ver Recursos',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'inline_card',
    position: 'bottom',
    titleTemplate: (name) => `Continue a Aprender: ${name}`,
    descriptionTemplate: (name) => `Guia educacional complementar sobre ${name.toLowerCase()} com análise detalhada e dicas práticas.`,
    ctaText: 'Explorar Mais',
    targetLocations: ['article'],
  },
  {
    type: 'banner',
    position: 'top',
    titleTemplate: (name) => `Educação Financeira: ${name}`,
    descriptionTemplate: (name) => `Tome decisões informadas com o nosso guia completo sobre ${name.toLowerCase()}. Informação atualizada e independente.`,
    ctaText: 'Saber Mais',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'banner',
    position: 'top',
    titleTemplate: (name) => `Guia Gratuito: ${name}`,
    descriptionTemplate: (name) => `Informação regulatória e educacional sobre ${name.toLowerCase()}. Proteja-se com conhecimento.`,
    ctaText: 'Aceder ao Guia',
    targetLocations: ['article'],
  },
  {
    type: 'banner',
    position: 'middle',
    titleTemplate: (name) => `Explore ${name} em Detalhe`,
    descriptionTemplate: (name) => `Guia educacional completo sobre ${name.toLowerCase()} com análise de regulação portuguesa e dicas de segurança.`,
    ctaText: 'Ver Guia',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'banner',
    position: 'bottom',
    titleTemplate: (name) => `Não Perca: ${name}`,
    descriptionTemplate: (name) => `Obtenha acesso ao guia educacional gratuito sobre ${name.toLowerCase()}.`,
    ctaText: 'Obter Guia',
    targetLocations: ['article'],
  },
  {
    type: 'text_ad',
    position: 'bottom',
    titleTemplate: (name) => `Mais sobre ${name}`,
    descriptionTemplate: (name) => `Guia educacional completo disponível`,
    ctaText: 'Ler Agora',
    targetLocations: ['article'],
  },
  {
    type: 'text_ad',
    position: 'bottom',
    titleTemplate: (name) => `Leitura relacionada: ${name}`,
    descriptionTemplate: (name) => `Recurso educacional gratuito`,
    ctaText: 'Ver Guia',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'text_ad',
    position: 'bottom',
    titleTemplate: (name) => `Continue a aprender: ${name}`,
    descriptionTemplate: (name) => `Informação detalhada disponível`,
    ctaText: 'Explorar',
    targetLocations: ['article'],
  },
  {
    type: 'button',
    position: 'top',
    titleTemplate: (name) => `${name} - Guia Rápido`,
    descriptionTemplate: (name) => `Acesso rápido ao guia`,
    ctaText: 'Ver Guia',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'button',
    position: 'middle',
    titleTemplate: (name) => `Explorar ${name}`,
    descriptionTemplate: (name) => `Guia educacional`,
    ctaText: 'Aceder',
    targetLocations: ['article'],
  },
  {
    type: 'button',
    position: 'bottom',
    titleTemplate: (name) => `Recursos: ${name}`,
    descriptionTemplate: (name) => `Material educacional`,
    ctaText: 'Ver Mais',
    targetLocations: ['article', 'landing'],
  },
  {
    type: 'text_ad',
    position: 'sidebar',
    titleTemplate: (name) => name,
    descriptionTemplate: (name) => `Guia completo`,
    ctaText: 'Ver',
    targetLocations: ['article'],
  },
  {
    type: 'button',
    position: 'sidebar',
    titleTemplate: (name) => `${name}`,
    descriptionTemplate: (name) => `Guia educacional`,
    ctaText: 'Aceder',
    targetLocations: ['article', 'landing'],
  },
];

function getTemplatesForTypeAndPosition(type: PromotionType, position: PlacementPosition): PromotionTemplate[] {
  return ENHANCED_TEMPLATES.filter(t => t.type === type && t.position === position);
}

function selectRandomTemplate(templates: PromotionTemplate[]): PromotionTemplate | null {
  if (templates.length === 0) return null;
  return templates[Math.floor(Math.random() * templates.length)];
}

function getDisplayOrderForPosition(position: PlacementPosition, index: number): number {
  const baseOrders: Record<PlacementPosition, number> = {
    top: 1,
    middle: 20,
    bottom: 40,
    sidebar: 60,
  };
  return baseOrders[position] + index;
}

async function hasActivePromotions(pageId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('lead_gen_promotions')
    .select('id')
    .eq('lead_gen_page_id', pageId)
    .eq('is_active', true)
    .limit(1);

  if (error) {
    console.error('Error checking promotions:', error);
    return false;
  }

  return (data && data.length > 0) || false;
}

export async function generatePromotionsWithConfig(
  distributionConfig: PromotionDistributionConfig[]
): Promise<PromotionGenerationResult> {
  const result: PromotionGenerationResult = {
    success: true,
    created: 0,
    skipped: 0,
    errors: [],
    details: [],
  };

  try {
    const { data: pages, error: pagesError } = await supabase
      .from('lead_gen_pages')
      .select('*')
      .eq('is_active', true)
      .order('display_order', { ascending: true });

    if (pagesError) {
      throw pagesError;
    }

    if (!pages || pages.length === 0) {
      result.errors.push('No active Lead Gen Pages found');
      result.success = false;
      return result;
    }

    for (const page of pages) {
      const hasPromotions = await hasActivePromotions(page.id);

      if (hasPromotions) {
        result.skipped++;
        result.details.push({
          pageName: page.name,
          promotionsCreated: 0,
          status: 'skipped',
          reason: 'Page already has active promotions',
        });
        continue;
      }

      const promotionsToCreate: Partial<LeadGenPromotion>[] = [];
      const usedTemplates = new Set<string>();

      for (const configItem of distributionConfig) {
        const templates = getTemplatesForTypeAndPosition(configItem.type, configItem.position);

        if (templates.length === 0) {
          console.warn(`No templates found for ${configItem.type} at ${configItem.position}`);
          continue;
        }

        for (let i = 0; i < configItem.count; i++) {
          const availableTemplates = templates.filter(t => {
            const templateKey = `${t.type}-${t.position}-${t.titleTemplate.toString()}`;
            return !usedTemplates.has(templateKey);
          });

          const template = selectRandomTemplate(
            availableTemplates.length > 0 ? availableTemplates : templates
          );

          if (!template) continue;

          const templateKey = `${template.type}-${template.position}-${template.titleTemplate.toString()}`;
          usedTemplates.add(templateKey);

          const cleanPageName = page.name.replace('Guia Educacional: ', '');
          const targetCategoryIds = page.category_id ? [page.category_id] : [];

          const promotion: Partial<LeadGenPromotion> = {
            lead_gen_page_id: page.id,
            promotion_type: template.type,
            promotion_title: template.titleTemplate(cleanPageName),
            promotion_description: template.descriptionTemplate(cleanPageName),
            cta_text: template.ctaText,
            target_locations: template.targetLocations,
            target_category_ids: targetCategoryIds,
            placement_position: template.position,
            display_order: getDisplayOrderForPosition(template.position, promotionsToCreate.length),
            is_active: true,
          };

          promotionsToCreate.push(promotion);
        }
      }

      if (promotionsToCreate.length === 0) {
        result.details.push({
          pageName: page.name,
          promotionsCreated: 0,
          status: 'skipped',
          reason: 'No valid templates found for configuration',
        });
        continue;
      }

      const { error: insertError } = await supabase
        .from('lead_gen_promotions')
        .insert(promotionsToCreate);

      if (insertError) {
        result.errors.push(`Failed to create promotions for ${page.name}: ${insertError.message}`);
        result.details.push({
          pageName: page.name,
          promotionsCreated: 0,
          status: 'error',
          reason: insertError.message,
        });
      } else {
        result.created += promotionsToCreate.length;
        result.details.push({
          pageName: page.name,
          promotionsCreated: promotionsToCreate.length,
          status: 'created',
        });
      }
    }

    if (result.errors.length > 0) {
      result.success = false;
    }

  } catch (error) {
    result.success = false;
    result.errors.push(`General error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }

  return result;
}

export async function generatePromotionsForPages(
  targetPromotionsPerPage: number = 5
): Promise<PromotionGenerationResult> {
  const naturalConfig: PromotionDistributionConfig[] = [
    { type: 'text_ad', position: 'top', count: 1 },
    { type: 'inline_card', position: 'middle', count: 1 },
    { type: 'text_ad', position: 'bottom', count: 1 },
  ];

  return generatePromotionsWithConfig(naturalConfig);
}

export async function generatePromotionsForPage(
  pageId: string,
  targetPromotionsCount: number = 5
): Promise<{ success: boolean; created: number; error?: string }> {
  try {
    const { data: page, error: pageError } = await supabase
      .from('lead_gen_pages')
      .select('*')
      .eq('id', pageId)
      .maybeSingle();

    if (pageError || !page) {
      return {
        success: false,
        created: 0,
        error: 'Lead Gen Page not found',
      };
    }

    const naturalConfig: PromotionDistributionConfig[] = [
      { type: 'text_ad', position: 'top', count: 1 },
      { type: 'inline_card', position: 'middle', count: 1 },
      { type: 'text_ad', position: 'bottom', count: 1 },
    ];

    const promotionsToCreate: Partial<LeadGenPromotion>[] = [];
    const usedTemplates = new Set<string>();

    for (const configItem of naturalConfig) {
      const templates = getTemplatesForTypeAndPosition(configItem.type, configItem.position);

      if (templates.length === 0) continue;

      for (let i = 0; i < configItem.count; i++) {
        const availableTemplates = templates.filter(t => {
          const templateKey = `${t.type}-${t.position}-${t.titleTemplate.toString()}`;
          return !usedTemplates.has(templateKey);
        });

        const template = selectRandomTemplate(
          availableTemplates.length > 0 ? availableTemplates : templates
        );

        if (!template) continue;

        const templateKey = `${template.type}-${template.position}-${template.titleTemplate.toString()}`;
        usedTemplates.add(templateKey);

        const cleanPageName = page.name.replace('Guia Educacional: ', '');
        const targetCategoryIds = page.category_id ? [page.category_id] : [];

        const promotion: Partial<LeadGenPromotion> = {
          lead_gen_page_id: page.id,
          promotion_type: template.type,
          promotion_title: template.titleTemplate(cleanPageName),
          promotion_description: template.descriptionTemplate(cleanPageName),
          cta_text: template.ctaText,
          target_locations: template.targetLocations,
          target_category_ids: targetCategoryIds,
          placement_position: template.position,
          display_order: getDisplayOrderForPosition(template.position, promotionsToCreate.length),
          is_active: true,
        };

        promotionsToCreate.push(promotion);
      }
    }

    const { error: insertError } = await supabase
      .from('lead_gen_promotions')
      .insert(promotionsToCreate);

    if (insertError) {
      return {
        success: false,
        created: 0,
        error: insertError.message,
      };
    }

    return {
      success: true,
      created: promotionsToCreate.length,
    };
  } catch (error) {
    return {
      success: false,
      created: 0,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}
