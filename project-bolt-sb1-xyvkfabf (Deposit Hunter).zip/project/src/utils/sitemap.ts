export interface SitemapUrl {
  loc: string;
  lastmod?: string;
  changefreq?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
  priority?: number;
}

export function generateSitemap(urls: SitemapUrl[]): string {
  const baseUrl = import.meta.env.VITE_APP_URL || 'https://www.deposithunter.com';

  const urlsXml = urls.map(url => `
  <url>
    <loc>${baseUrl}${url.loc}</loc>${url.lastmod ? `
    <lastmod>${url.lastmod}</lastmod>` : ''}${url.changefreq ? `
    <changefreq>${url.changefreq}</changefreq>` : ''}${url.priority !== undefined ? `
    <priority>${url.priority}</priority>` : ''}
  </url>`).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urlsXml}
</urlset>`;
}

export function getStaticSitemapUrls(): SitemapUrl[] {
  const today = new Date().toISOString().split('T')[0];

  return [
    {
      loc: '/',
      lastmod: today,
      changefreq: 'daily',
      priority: 1.0
    },
    {
      loc: '/about',
      lastmod: '2024-12-04',
      changefreq: 'monthly',
      priority: 0.8
    },
    {
      loc: '/terms',
      lastmod: '2024-12-04',
      changefreq: 'monthly',
      priority: 0.6
    },
    {
      loc: '/privacy',
      lastmod: '2024-12-04',
      changefreq: 'monthly',
      priority: 0.6
    },
    {
      loc: '/disclaimer',
      lastmod: '2024-12-04',
      changefreq: 'monthly',
      priority: 0.6
    },
    {
      loc: '/cookie-policy',
      lastmod: '2024-12-04',
      changefreq: 'monthly',
      priority: 0.5
    },
    {
      loc: '/accessibility',
      lastmod: '2024-12-04',
      changefreq: 'monthly',
      priority: 0.5
    },
    {
      loc: '/editorial-standards',
      lastmod: '2024-12-04',
      changefreq: 'monthly',
      priority: 0.5
    }
  ];
}
