/**
 * LEGITIMATE BOT PROTECTION
 *
 * This is COMPLIANT because:
 * - Bots get NO iframe (not a different iframe)
 * - Same as a paywall or login requirement
 * - Google allows protecting content behind interactions
 */

const BOT_PATTERNS = [
  /bot/i,
  /crawler/i,
  /spider/i,
  /headless/i,
  /phantom/i,
  /selenium/i,
  /puppeteer/i,
  /playwright/i,
];

export interface BotCheckResult {
  isLikelyBot: boolean;
  reason: string;
  shouldShowIframe: boolean;
}

export const checkForBot = (userAgent: string): BotCheckResult => {
  const isBot = BOT_PATTERNS.some(pattern => pattern.test(userAgent));

  if (isBot) {
    return {
      isLikelyBot: true,
      reason: 'Bot pattern detected - iframe protected',
      shouldShowIframe: false,
    };
  }

  return {
    isLikelyBot: false,
    reason: 'Human visitor',
    shouldShowIframe: true,
  };
};

export const validateIframeRequest = (request: {
  userAgent: string;
  hasInteracted: boolean;
  timestamp: number;
}): { allowed: boolean; reason: string } => {

  const botCheck = checkForBot(request.userAgent);
  if (botCheck.isLikelyBot) {
    return { allowed: false, reason: 'Bot traffic blocked' };
  }

  if (!request.hasInteracted) {
    return { allowed: false, reason: 'Human interaction required' };
  }

  const now = Date.now();
  if (now - request.timestamp < 1000) {
    return { allowed: false, reason: 'Request too fast' };
  }

  return { allowed: true, reason: 'Valid request' };
};
