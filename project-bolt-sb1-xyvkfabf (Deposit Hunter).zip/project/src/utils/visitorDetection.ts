export type VisitorType = 'human' | 'bot' | 'uncertain';

export interface VisitorClassification {
  type: VisitorType;
  confidence: number;
  signals: string[];
}

const KNOWN_BOT_PATTERNS = [
  /bot/i,
  /crawler/i,
  /spider/i,
  /scraper/i,
  /curl/i,
  /wget/i,
  /python/i,
  /java(?!script)/i,
  /php/i,
  /perl/i,
  /ruby/i,
  /go-http/i,
  /axios/i,
  /okhttp/i,
  /httpclient/i,
  /scan/i,
  /monitor/i,
  /lighthouse/i,
  /headless/i,
  /phantom/i,
  /selenium/i,
  /webdriver/i,
];

const KNOWN_BOT_NAMES = [
  'googlebot',
  'bingbot',
  'slurp',
  'duckduckbot',
  'baiduspider',
  'yandexbot',
  'facebookexternalhit',
  'twitterbot',
  'linkedinbot',
  'whatsapp',
  'telegram',
  'discord',
  'slackbot',
  'applebot',
  'ahrefsbot',
  'semrushbot',
  'dotbot',
  'rogerbot',
  'mj12bot',
  'pingdom',
  'uptimerobot',
  'statusCake',
  'gtmetrix',
];

const HUMAN_INDICATORS = [
  /mozilla/i,
  /chrome/i,
  /safari/i,
  /firefox/i,
  /edge/i,
  /opera/i,
];

export function classifyVisitor(userAgent: string): VisitorClassification {
  if (!userAgent || userAgent.trim() === '') {
    return {
      type: 'uncertain',
      confidence: 0,
      signals: ['empty_user_agent'],
    };
  }

  const signals: string[] = [];
  let botScore = 0;
  let humanScore = 0;

  const lowerUA = userAgent.toLowerCase();

  for (const botName of KNOWN_BOT_NAMES) {
    if (lowerUA.includes(botName)) {
      signals.push(`known_bot:${botName}`);
      botScore += 10;
    }
  }

  for (const pattern of KNOWN_BOT_PATTERNS) {
    if (pattern.test(userAgent)) {
      signals.push(`bot_pattern:${pattern.source}`);
      botScore += 5;
    }
  }

  for (const pattern of HUMAN_INDICATORS) {
    if (pattern.test(userAgent)) {
      signals.push(`human_indicator:${pattern.source}`);
      humanScore += 3;
    }
  }

  if (!lowerUA.includes('mozilla') && !lowerUA.includes('compatible')) {
    signals.push('missing_mozilla_signature');
    botScore += 2;
  }

  if (userAgent.length < 20) {
    signals.push('suspiciously_short_ua');
    botScore += 2;
  }

  if (userAgent.length > 500) {
    signals.push('suspiciously_long_ua');
    botScore += 1;
  }

  const matchResult = userAgent.match(/\((.*?)\)/);
  if (!matchResult) {
    signals.push('missing_platform_info');
    botScore += 2;
  }

  const totalScore = botScore - humanScore;
  const confidence = Math.min(Math.abs(totalScore) / 10, 1);

  if (botScore >= 10 || totalScore >= 7) {
    return {
      type: 'bot',
      confidence,
      signals,
    };
  }

  if (humanScore >= 6 && totalScore <= -3) {
    return {
      type: 'human',
      confidence,
      signals,
    };
  }

  return {
    type: 'uncertain',
    confidence: 1 - confidence,
    signals: signals.length > 0 ? signals : ['insufficient_signals'],
  };
}

export function shouldShowIframe(
  manualHideIframe: boolean,
  visitorClassification: VisitorClassification
): boolean {
  if (manualHideIframe) {
    return false;
  }

  return true;
}

export function getVisitorInfo() {
  const userAgent = navigator.userAgent;
  const referrer = document.referrer;

  return {
    userAgent,
    referrer,
    classification: classifyVisitor(userAgent),
  };
}
