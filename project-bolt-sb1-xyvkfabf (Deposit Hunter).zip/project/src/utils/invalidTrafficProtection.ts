/**
 * GOOGLE INVALID TRAFFIC (IVT) COMPLIANCE
 *
 * Work WITH Google's systems, not against them.
 * This helps Google identify valid vs invalid traffic.
 */

declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

export const initializeGoogleTracking = (measurementId: string) => {
  window.dataLayer = window.dataLayer || [];

  window.gtag = function gtag() {
    window.dataLayer.push(arguments);
  };

  window.gtag('js', new Date());
  window.gtag('config', measurementId, {
    allow_enhanced_conversions: true,
    send_page_view: true,
  });
};

export const trackEngagementSignals = () => {
  let scrollDepth = 0;
  let timeOnPage = 0;
  let interactions = 0;

  window.addEventListener('scroll', () => {
    const newDepth = Math.round(
      (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100
    );
    if (newDepth > scrollDepth) {
      scrollDepth = newDepth;
      if (scrollDepth % 25 === 0) {
        window.gtag?.('event', 'scroll_depth', { depth: scrollDepth });
      }
    }
  });

  setInterval(() => {
    timeOnPage += 10;
    if (timeOnPage % 30 === 0) {
      window.gtag?.('event', 'time_on_page', { seconds: timeOnPage });
    }
  }, 10000);

  ['click', 'scroll', 'mousemove', 'keypress'].forEach(event => {
    window.addEventListener(event, () => {
      interactions++;
    }, { passive: true });
  });
};

export const trackAffiliateClick = (data: {
  pageId: string;
  operatorName: string;
  position: string;
  timeOnPageBeforeClick: number;
  scrollDepthBeforeClick: number;
  interactionsBeforeClick: number;
}) => {
  window.gtag?.('event', 'affiliate_click', {
    page_id: data.pageId,
    operator: data.operatorName,
    position: data.position,
    time_before_click: data.timeOnPageBeforeClick,
    scroll_before_click: data.scrollDepthBeforeClick,
    interactions_before_click: data.interactionsBeforeClick,
    engagement_time_msec: data.timeOnPageBeforeClick * 1000,
  });
};

export const logSuspiciousActivity = async (data: {
  type: 'rapid_clicks' | 'no_engagement' | 'unusual_pattern';
  details: string;
}) => {
  try {
    await fetch('/api/security-log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...data,
        timestamp: new Date().toISOString(),
        url: window.location.href,
      }),
    });
  } catch (error) {
    console.error('Failed to log suspicious activity:', error);
  }
};
