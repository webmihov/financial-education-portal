export interface IPClassificationResult {
  ipType: 'residential' | 'mobile' | 'datacenter' | 'organization' | 'vpn' | 'proxy' | 'unknown';
  confidence: number;
  indicators: string[];
}

export const KNOWN_DATACENTER_KEYWORDS = [
  'amazonaws',
  'googlecloud',
  'azure',
  'digitalocean',
  'linode',
  'hetzner',
  'ovh',
  'vultr',
  'hosting',
  'server',
  'cloud',
  'vps',
  'dedicated',
];

export const MOBILE_CARRIER_KEYWORDS = [
  'mobile',
  'carrier',
  'telecom',
  'wireless',
  'cellular',
  'vodafone',
  'meo',
  'nos',
  'tmobile',
  'verizon',
  'att',
  'orange',
  'telefonica',
  'sprint',
  'three',
];

export const VPN_PROXY_KEYWORDS = [
  'vpn',
  'proxy',
  'tor',
  'anonymizer',
  'tunnel',
  'relay',
];

export function classifyHostname(hostname: string): IPClassificationResult {
  const lower = hostname.toLowerCase();
  const indicators: string[] = [];
  let ipType: IPClassificationResult['ipType'] = 'unknown';
  let confidence = 0;

  if (!hostname || hostname === '') {
    return { ipType: 'unknown', confidence: 0, indicators: ['No PTR hostname'] };
  }

  for (const keyword of MOBILE_CARRIER_KEYWORDS) {
    if (lower.includes(keyword)) {
      indicators.push(`Mobile carrier keyword: ${keyword}`);
      ipType = 'mobile';
      confidence = 85;
      break;
    }
  }

  if (ipType === 'unknown') {
    for (const keyword of KNOWN_DATACENTER_KEYWORDS) {
      if (lower.includes(keyword)) {
        indicators.push(`Datacenter keyword: ${keyword}`);
        ipType = 'datacenter';
        confidence = 90;
        break;
      }
    }
  }

  if (ipType === 'unknown') {
    for (const keyword of VPN_PROXY_KEYWORDS) {
      if (lower.includes(keyword)) {
        indicators.push(`VPN/Proxy keyword: ${keyword}`);
        ipType = 'vpn';
        confidence = 85;
        break;
      }
    }
  }

  if (ipType === 'unknown') {
    if (lower.includes('business') || lower.includes('corporate') || lower.includes('enterprise')) {
      indicators.push('Business/Corporate hostname');
      ipType = 'organization';
      confidence = 70;
    } else if (lower.includes('dynamic') || lower.includes('dhcp') || lower.includes('pool')) {
      indicators.push('Dynamic IP pool');
      ipType = 'residential';
      confidence = 75;
    } else if (lower.match(/\d{1,3}-\d{1,3}-\d{1,3}-\d{1,3}/)) {
      indicators.push('Generic ISP hostname pattern');
      ipType = 'residential';
      confidence = 65;
    }
  }

  if (ipType === 'unknown') {
    indicators.push('No matching patterns');
    confidence = 50;
  }

  return { ipType, confidence, indicators };
}

export function isPrivateIP(ip: string): boolean {
  const patterns = [
    /^10\./,
    /^172\.(1[6-9]|2[0-9]|3[01])\./,
    /^192\.168\./,
    /^127\./,
    /^169\.254\./,
    /^::1$/,
    /^fe80:/,
    /^fc00:/,
  ];

  return patterns.some(pattern => pattern.test(ip));
}

export function isLoopback(ip: string): boolean {
  return ip === '127.0.0.1' || ip === '::1' || ip === 'localhost';
}

export async function callServerDetection(userAgent: string, signals: any): Promise<any> {
  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
      console.warn('Supabase credentials not configured');
      return null;
    }

    const apiUrl = `${supabaseUrl}/functions/v1/visitor-detection`;

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${supabaseAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userAgent,
        signals,
      }),
    });

    if (!response.ok) {
      console.warn('Server detection failed:', response.status);
      return null;
    }

    return await response.json();
  } catch (error) {
    console.warn('Server detection error:', error);
    return null;
  }
}

export function getIPTypeLabel(ipType: string): string {
  const labels: Record<string, string> = {
    residential: 'Residential ISP',
    mobile: 'Mobile Carrier',
    datacenter: 'Datacenter/Server',
    organization: 'Organization',
    vpn: 'VPN/Proxy',
    proxy: 'Proxy',
    unknown: 'Unknown',
  };

  return labels[ipType] || 'Unknown';
}

export function getIPTypeRiskLevel(ipType: string): 'low' | 'medium' | 'high' {
  const riskLevels: Record<string, 'low' | 'medium' | 'high'> = {
    residential: 'low',
    mobile: 'low',
    organization: 'medium',
    vpn: 'high',
    proxy: 'high',
    datacenter: 'high',
    unknown: 'medium',
  };

  return riskLevels[ipType] || 'medium';
}
