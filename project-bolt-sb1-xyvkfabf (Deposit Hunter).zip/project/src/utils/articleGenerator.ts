import { PlatformCategory } from '../types';

interface ArticleContent {
  intro_pt: string;
  intro_en: string;
  how_it_works_pt: string;
  how_it_works_en: string;
  regulatory_status_pt: string;
  regulatory_status_en: string;
  risks_pt: string;
  risks_en: string;
  security_pt: string;
  security_en: string;
  red_flags_pt: string;
  red_flags_en: string;
  consumer_protection_pt: string;
  consumer_protection_en: string;
  disclaimer_pt: string;
  disclaimer_en: string;
}

function getContentByRegulatoryFocus(category: PlatformCategory): ArticleContent {
  const { regulatory_focus, name_pt, name_en, description_pt, description_en } = category;

  if (regulatory_focus === 'SRIJ') {
    return {
      intro_pt: `${description_pt}. O SRIJ (Serviço de Regulação e Inspeção de Jogos) supervisiona estas plataformas em Portugal para garantir operação legal e proteção do consumidor.`,
      intro_en: `${description_en}. SRIJ (Gaming Regulation and Inspection Service) supervises these platforms in Portugal to ensure legal operation and consumer protection.`,

      how_it_works_pt: `Plataformas em ${name_pt.toLowerCase()} permitem que consumidores façam depósitos para participar em atividades de entretenimento. Para operar legalmente em Portugal, estas plataformas devem ter licença SRIJ válida. Os depósitos são geralmente processados através de métodos de pagamento regulados como Multibanco, MB WAY, ou cartões bancários.`,
      how_it_works_en: `Platforms in ${name_en.toLowerCase()} allow consumers to make deposits to participate in entertainment activities. To operate legally in Portugal, these platforms must have a valid SRIJ license. Deposits are typically processed through regulated payment methods such as Multibanco, MB WAY, or bank cards.`,

      regulatory_status_pt: `O SRIJ regula ${name_pt.toLowerCase()} em Portugal. Apenas plataformas licenciadas podem operar legalmente. Verifique sempre a licença no registo público do SRIJ (https://www.srij.turismodeportugal.pt) antes de fazer qualquer depósito. Plataformas sem licença SRIJ operam ilegalmente e não oferecem proteções ao consumidor.`,
      regulatory_status_en: `SRIJ regulates ${name_en.toLowerCase()} in Portugal. Only licensed platforms can operate legally. Always verify the license on SRIJ's public registry (https://www.srij.turismodeportugal.pt) before making any deposit. Platforms without SRIJ license operate illegally and offer no consumer protections.`,

      risks_pt: `Os principais riscos incluem: perda total dos valores depositados, dependência, dificuldades em levantar fundos de plataformas não licenciadas, e falta de proteção legal se usar serviços sem licença SRIJ. Nunca deposite mais do que pode perder.`,
      risks_en: `Main risks include: total loss of deposited amounts, dependency, difficulties withdrawing funds from unlicensed platforms, and lack of legal protection if using services without SRIJ license. Never deposit more than you can afford to lose.`,

      security_pt: `Para proteger-se: use apenas plataformas com licença SRIJ válida, ative limites de depósito, nunca partilhe credenciais de acesso, use métodos de pagamento seguros, e mantenha registos de todas as transações. Plataformas licenciadas devem ter medidas de jogo responsável.`,
      security_en: `To protect yourself: only use platforms with valid SRIJ license, activate deposit limits, never share login credentials, use secure payment methods, and keep records of all transactions. Licensed platforms must have responsible gaming measures.`,

      red_flags_pt: `Sinais de alerta: ausência de licença SRIJ, promessas de ganhos garantidos, dificuldade em levantar fundos, pressão para depositar mais, site sem informações de contacto em Portugal, ausência de ferramentas de jogo responsável, e recusa em fornecer documentação oficial.`,
      red_flags_en: `Warning signs: absence of SRIJ license, promises of guaranteed winnings, difficulty withdrawing funds, pressure to deposit more, website without contact information in Portugal, absence of responsible gaming tools, and refusal to provide official documentation.`,

      consumer_protection_pt: `Se usar plataformas licenciadas pelo SRIJ, tem direito a proteção ao consumidor e pode apresentar queixas. Para reclamações, consulte o Portal do Consumidor (https://www.consumidor.gov.pt) ou o Livro de Reclamações Eletrónico (https://www.livroreclamacoes.pt). O SRIJ também aceita denúncias de operadores ilegais.`,
      consumer_protection_en: `If using SRIJ-licensed platforms, you have consumer protection rights and can file complaints. For complaints, consult Consumer Portal (https://www.consumidor.gov.pt) or Electronic Complaints Book (https://www.livroreclamacoes.pt). SRIJ also accepts reports of illegal operators.`,

      disclaimer_pt: `Esta informação é apenas educacional. Não promovemos nem recomendamos qualquer plataforma específica. Não temos afiliações comerciais e não recebemos comissões. A participação em ${name_pt.toLowerCase()} envolve riscos financeiros. Consulte sempre fontes oficiais e, se necessário, procure aconselhamento profissional independente.`,
      disclaimer_en: `This information is educational only. We do not promote or recommend any specific platform. We have no commercial affiliations and receive no commissions. Participation in ${name_en.toLowerCase()} involves financial risks. Always consult official sources and, if necessary, seek independent professional advice.`
    };
  }

  if (regulatory_focus === 'Banco de Portugal') {
    return {
      intro_pt: `${description_pt}. O Banco de Portugal supervisiona estas entidades para garantir estabilidade financeira, proteção de depósitos, e conformidade com regulamentação bancária europeia.`,
      intro_en: `${description_en}. Banco de Portugal supervises these entities to ensure financial stability, deposit protection, and compliance with European banking regulation.`,

      how_it_works_pt: `${name_pt} em Portugal operam sob supervisão do Banco de Portugal. Os depósitos são geralmente protegidos pelo Fundo de Garantia de Depósitos até €100.000 por depositante. As transações seguem normas SEPA e legislação bancária europeia, garantindo segurança e rastreabilidade.`,
      how_it_works_en: `${name_en} in Portugal operate under Banco de Portugal supervision. Deposits are generally protected by Deposit Guarantee Fund up to €100,000 per depositor. Transactions follow SEPA standards and European banking legislation, ensuring security and traceability.`,

      regulatory_status_pt: `O Banco de Portugal regula ${name_pt.toLowerCase()} em Portugal. Entidades autorizadas constam no registo público (https://www.bportugal.pt). Esta supervisão garante conformidade com requisitos de capital, proteção de depósitos, e normas de conduta. Só use serviços de entidades reguladas.`,
      regulatory_status_en: `Banco de Portugal regulates ${name_en.toLowerCase()} in Portugal. Authorized entities are listed in public registry (https://www.bportugal.pt). This supervision ensures compliance with capital requirements, deposit protection, and conduct standards. Only use services from regulated entities.`,

      risks_pt: `Riscos principais incluem: perda de acesso temporário a fundos em caso de falência (apesar da garantia de depósitos), taxas e comissões não transparentes, fraudes por entidades não reguladas, e riscos cambiais se usar moedas estrangeiras. Sempre verifique se a entidade é supervisionada pelo Banco de Portugal.`,
      risks_en: `Main risks include: temporary loss of fund access in case of bankruptcy (despite deposit guarantee), non-transparent fees and commissions, fraud by unregulated entities, and currency risks if using foreign currencies. Always verify if entity is supervised by Banco de Portugal.`,

      security_pt: `Para segurança: confirme que a instituição é supervisionada pelo Banco de Portugal, use autenticação forte, nunca partilhe códigos de acesso, verifique se comunicações são legítimas (phishing é comum), ative notificações de transações, e mantenha software atualizado.`,
      security_en: `For security: confirm institution is supervised by Banco de Portugal, use strong authentication, never share access codes, verify communications are legitimate (phishing is common), activate transaction notifications, and keep software updated.`,

      red_flags_pt: `Sinais de alerta: ausência de supervisão do Banco de Portugal, promessas de rendimentos irrealistas, pressão para investir rapidamente, site sem informações de contacto válidas, pedidos de transferências para contas estrangeiras, e ausência de informação sobre garantia de depósitos.`,
      red_flags_en: `Warning signs: absence of Banco de Portugal supervision, unrealistic return promises, pressure to invest quickly, website without valid contact information, requests for transfers to foreign accounts, and absence of deposit guarantee information.`,

      consumer_protection_pt: `O Banco de Portugal oferece serviço de atendimento ao cliente bancário (https://clientebancario.bportugal.pt) para esclarecimentos e reclamações. Os depósitos em bancos são cobertos pelo Fundo de Garantia de Depósitos até €100.000. Para litígios, pode recorrer também ao Portal do Consumidor.`,
      consumer_protection_en: `Banco de Portugal offers banking customer service (https://clientebancario.bportugal.pt) for clarifications and complaints. Bank deposits are covered by Deposit Guarantee Fund up to €100,000. For disputes, you can also use Consumer Portal.`,

      disclaimer_pt: `Esta informação é apenas educacional. Não somos consultores financeiros e não temos afiliações com instituições bancárias. Não promovemos produtos específicos nem recebemos comissões. Para decisões financeiras importantes, consulte profissionais qualificados.`,
      disclaimer_en: `This information is educational only. We are not financial advisors and have no affiliations with banking institutions. We do not promote specific products nor receive commissions. For important financial decisions, consult qualified professionals.`
    };
  }

  if (regulatory_focus === 'ASAE') {
    return {
      intro_pt: `${description_pt}. A ASAE (Autoridade de Segurança Alimentar e Económica) fiscaliza atividades de comércio eletrónico em Portugal, protegendo consumidores contra práticas abusivas.`,
      intro_en: `${description_en}. ASAE (Food and Economic Safety Authority) supervises e-commerce activities in Portugal, protecting consumers against abusive practices.`,

      how_it_works_pt: `Em ${name_pt.toLowerCase()}, os consumidores fazem pagamentos por bens ou serviços online. Estes pagamentos são protegidos pela legislação de comércio eletrónico e direitos do consumidor português. As plataformas devem fornecer informações claras sobre preços, prazos de entrega, e políticas de devolução.`,
      how_it_works_en: `In ${name_en.toLowerCase()}, consumers make payments for goods or services online. These payments are protected by Portuguese e-commerce legislation and consumer rights. Platforms must provide clear information about prices, delivery times, and return policies.`,

      regulatory_status_pt: `O comércio eletrónico em Portugal está sujeito à Lei do Comércio Eletrónico e ao Código de Defesa do Consumidor. A ASAE fiscaliza o cumprimento destas normas. As plataformas devem ter número de IVA português, informações de contacto visíveis, e respeitar o direito de arrependimento de 14 dias.`,
      regulatory_status_en: `E-commerce in Portugal is subject to Electronic Commerce Law and Consumer Protection Code. ASAE supervises compliance with these standards. Platforms must have Portuguese VAT number, visible contact information, and respect 14-day right of withdrawal.`,

      risks_pt: `Riscos incluem: não receber produto/serviço após pagamento, receber produtos diferentes do anunciado, dificuldade em obter reembolsos, fraudes por sites falsos, e roubo de dados de pagamento. Sempre verifique legitimidade da plataforma antes de pagar.`,
      risks_en: `Risks include: not receiving product/service after payment, receiving products different from advertised, difficulty obtaining refunds, fraud by fake websites, and payment data theft. Always verify platform legitimacy before paying.`,

      security_pt: `Para comprar com segurança: verifique se o site tem HTTPS, confirme dados da empresa (nome, morada, NIF), use métodos de pagamento seguros com proteção ao consumidor, guarde comprovantes de compra, e desconfie de ofertas irrealistas. Leia termos e condições.`,
      security_en: `To shop safely: verify website has HTTPS, confirm company details (name, address, tax ID), use secure payment methods with consumer protection, keep purchase receipts, and be wary of unrealistic offers. Read terms and conditions.`,

      red_flags_pt: `Sinais de alerta: preços muito abaixo do mercado, ausência de informações da empresa, site sem contactos em Portugal, pedidos de transferência bancária direta, pressão para comprar rapidamente, erros gramaticais, e ausência de política de devolução.`,
      red_flags_en: `Warning signs: prices far below market, absence of company information, website without contacts in Portugal, requests for direct bank transfer, pressure to buy quickly, grammatical errors, and absence of return policy.`,

      consumer_protection_pt: `Tem direito de arrependimento de 14 dias na maioria das compras online. Para reclamações, use o Livro de Reclamações Eletrónico (https://www.livroreclamacoes.pt) ou o Portal do Consumidor. A ASAE pode fiscalizar práticas comerciais abusivas.`,
      consumer_protection_en: `You have 14-day right of withdrawal on most online purchases. For complaints, use Electronic Complaints Book (https://www.livroreclamacoes.pt) or Consumer Portal. ASAE can supervise abusive commercial practices.`,

      disclaimer_pt: `Esta informação é apenas educacional. Não promovemos plataformas específicas nem temos relações comerciais com vendedores. Não recebemos comissões. Os consumidores devem sempre verificar legitimidade das plataformas e ler termos de serviço antes de efetuar pagamentos.`,
      disclaimer_en: `This information is educational only. We do not promote specific platforms nor have commercial relationships with sellers. We receive no commissions. Consumers should always verify platform legitimacy and read terms of service before making payments.`
    };
  }

  if (regulatory_focus === 'CMVM') {
    return {
      intro_pt: `${description_pt}. A CMVM (Comissão do Mercado de Valores Mobiliários) regula mercados de investimento em Portugal, protegendo investidores.`,
      intro_en: `${description_en}. CMVM (Portuguese Securities Market Commission) regulates investment markets in Portugal, protecting investors.`,

      how_it_works_pt: `${name_pt} permitem que investidores façam depósitos para negociar instrumentos financeiros. Para operar legalmente em Portugal, estas plataformas devem ser autorizadas pela CMVM ou registadas como entidades europeias com passaporte. Os depósitos de investidores têm proteções específicas.`,
      how_it_works_en: `${name_en} allow investors to make deposits to trade financial instruments. To operate legally in Portugal, these platforms must be authorized by CMVM or registered as European entities with passport. Investor deposits have specific protections.`,

      regulatory_status_pt: `A CMVM regula ${name_pt.toLowerCase()} em Portugal. Verifique sempre se a plataforma consta no registo da CMVM (https://www.cmvm.pt) antes de investir. Plataformas não autorizadas operam ilegalmente e não oferecem proteções ao investidor.`,
      regulatory_status_en: `CMVM regulates ${name_en.toLowerCase()} in Portugal. Always verify if platform is listed in CMVM registry (https://www.cmvm.pt) before investing. Unauthorized platforms operate illegally and offer no investor protections.`,

      risks_pt: `Investir comporta riscos de perda de capital. Riscos adicionais incluem: volatilidade de mercado, custos e comissões elevadas, complexidade de produtos, conflitos de interesse, e fraudes por plataformas não autorizadas. Nunca invista dinheiro que não pode perder.`,
      risks_en: `Investing carries risks of capital loss. Additional risks include: market volatility, high costs and commissions, product complexity, conflicts of interest, and fraud by unauthorized platforms. Never invest money you cannot afford to lose.`,

      security_pt: `Para investir com segurança: use apenas plataformas autorizadas pela CMVM, entenda completamente os produtos antes de investir, diversifique investimentos, desconfie de promessas de ganhos garantidos, e mantenha registos de todas as transações.`,
      security_en: `To invest safely: only use CMVM-authorized platforms, fully understand products before investing, diversify investments, be wary of guaranteed return promises, and keep records of all transactions.`,

      red_flags_pt: `Sinais de alerta: ausência de autorização CMVM, promessas de retornos garantidos ou muito altos, pressão para investir rapidamente, falta de informação sobre riscos, dificuldade em levantar fundos, e ausência de documentação oficial.`,
      red_flags_en: `Warning signs: absence of CMVM authorization, promises of guaranteed or very high returns, pressure to invest quickly, lack of risk information, difficulty withdrawing funds, and absence of official documentation.`,

      consumer_protection_pt: `A CMVM oferece serviço de atendimento ao investidor (https://www.cmvm.pt) para esclarecimentos e reclamações. Investidores em entidades autorizadas têm acesso ao Fundo de Garantia de Investidores. Pode também usar o Portal do Consumidor para reclamações.`,
      consumer_protection_en: `CMVM offers investor service (https://www.cmvm.pt) for clarifications and complaints. Investors in authorized entities have access to Investor Guarantee Fund. You can also use Consumer Portal for complaints.`,

      disclaimer_pt: `Esta informação é apenas educacional. Não somos consultores de investimento e não temos afiliações com plataformas. Não promovemos investimentos específicos nem recebemos comissões. Procure sempre aconselhamento profissional antes de investir.`,
      disclaimer_en: `This information is educational only. We are not investment advisors and have no platform affiliations. We do not promote specific investments nor receive commissions. Always seek professional advice before investing.`
    };
  }

  return {
    intro_pt: `${description_pt}. Este tipo de serviço online processa pagamentos e depósitos de consumidores, sendo importante entender como funcionam e quais as proteções disponíveis.`,
    intro_en: `${description_en}. This type of online service processes consumer payments and deposits, being important to understand how they work and what protections are available.`,

    how_it_works_pt: `${name_pt} processam pagamentos e depósitos de consumidores para acesso a serviços digitais. As transações devem ser transparentes, com informações claras sobre custos, prazos, e condições de cancelamento. Os consumidores têm direitos protegidos pela legislação portuguesa de defesa do consumidor.`,
    how_it_works_en: `${name_en} process consumer payments and deposits for access to digital services. Transactions must be transparent, with clear information about costs, deadlines, and cancellation conditions. Consumers have rights protected by Portuguese consumer protection legislation.`,

    regulatory_status_pt: `Serviços em ${name_pt.toLowerCase()} devem cumprir legislação portuguesa de comércio eletrónico e proteção do consumidor. Embora não haja regulador específico para este setor, entidades como a ASAE e o Portal do Consumidor monitorizam práticas comerciais e protegem direitos dos consumidores.`,
    regulatory_status_en: `Services in ${name_en.toLowerCase()} must comply with Portuguese e-commerce and consumer protection legislation. Although there is no specific regulator for this sector, entities like ASAE and Consumer Portal monitor commercial practices and protect consumer rights.`,

    risks_pt: `Riscos incluem: cobrança de valores não autorizados, dificuldade em cancelar subscrições, falta de transparência em custos adicionais, problemas com reembolsos, e perda de acesso a serviços após pagamento. Leia sempre os termos de serviço antes de subscrever.`,
    risks_en: `Risks include: charging unauthorized amounts, difficulty canceling subscriptions, lack of transparency in additional costs, refund problems, and loss of service access after payment. Always read terms of service before subscribing.`,

    security_pt: `Para se proteger: use métodos de pagamento seguros que permitam contestação, ative notificações de transações, reveja regularmente subscrições ativas, guarde comprovativos de pagamento, e cancele serviços que não usa. Desconfie de cobranças inesperadas.`,
    security_en: `To protect yourself: use secure payment methods that allow disputes, activate transaction notifications, regularly review active subscriptions, keep payment receipts, and cancel unused services. Be wary of unexpected charges.`,

    red_flags_pt: `Sinais de alerta: dificuldade extrema em cancelar serviço, cobranças não anunciadas, ausência de informações de contacto, termos de serviço pouco claros, renovações automáticas sem aviso, e recusa em processar reembolsos legítimos.`,
    red_flags_en: `Warning signs: extreme difficulty canceling service, unannounced charges, absence of contact information, unclear terms of service, automatic renewals without notice, and refusal to process legitimate refunds.`,

    consumer_protection_pt: `Tem direitos de consumidor protegidos pela lei portuguesa, incluindo informação clara, direito de arrependimento (quando aplicável), e possibilidade de reclamação. Use o Livro de Reclamações Eletrónico (https://www.livroreclamacoes.pt) ou Portal do Consumidor para reportar problemas.`,
    consumer_protection_en: `You have consumer rights protected by Portuguese law, including clear information, right of withdrawal (when applicable), and possibility of complaint. Use Electronic Complaints Book (https://www.livroreclamacoes.pt) or Consumer Portal to report problems.`,

    disclaimer_pt: `Esta informação é apenas educacional. Não promovemos serviços específicos e não temos afiliações comerciais. Não recebemos comissões. Os consumidores devem sempre verificar termos de serviço e avaliar necessidade real antes de subscrever qualquer serviço online.`,
    disclaimer_en: `This information is educational only. We do not promote specific services and have no commercial affiliations. We receive no commissions. Consumers should always verify terms of service and assess real need before subscribing to any online service.`
  };
}

export function generateArticleFromCategory(category: PlatformCategory) {
  const content = getContentByRegulatoryFocus(category);
  const slug = category.slug + '-guia-educacional';

  return {
    title_pt: `Guia Educacional: ${category.name_pt}`,
    title_en: `Educational Guide: ${category.name_en}`,
    slug,
    category_id: category.id,
    ...content,
    author: 'DepositHunter Editorial Team',
    display_order: 0,
    is_active: false,
  };
}
