import { supabase } from '../lib/supabase';

export async function trackInteraction(
  actionType: string,
  websiteId?: string
): Promise<void> {
  try {
    const ipHash = await hashIP();
    const userAgent = navigator.userAgent;

    await supabase.from('user_interactions').insert({
      action_type: actionType,
      website_id: websiteId || null,
      ip_hash: ipHash,
      user_agent: userAgent,
    });
  } catch (error) {
    console.error('Failed to track interaction:', error);
  }
}

async function hashIP(): Promise<string> {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    const encoder = new TextEncoder();
    const data_encoded = encoder.encode(data.ip);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data_encoded);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } catch {
    return 'unknown';
  }
}
