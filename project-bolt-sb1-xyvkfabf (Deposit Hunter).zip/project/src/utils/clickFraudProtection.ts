/**
 * CLICK FRAUD PROTECTION INTEGRATION
 *
 * Integrates with legitimate third-party services:
 * - ClickCease
 * - TrafficGuard
 * - Lunio
 * - CHEQ
 *
 * These are industry-standard tools that Google approves of.
 */

export interface FraudProtectionConfig {
  provider: 'clickcease' | 'trafficguard' | 'lunio' | 'cheq' | 'none';
  apiKey?: string;
  blockThreshold?: number;
}

export const DEFAULT_FRAUD_CONFIG: FraudProtectionConfig = {
  provider: 'none',
  blockThreshold: 80,
};

export const getClickCeaseScript = (accountId: string): string => {
  return `
    <script type="text/javascript">
      var script = document.createElement('script');
      script.async = true;
      script.type = 'text/javascript';
      script.src = '//www.clickcease.com/monitor/stat.js';
      document.head.appendChild(script);
    </script>
    <noscript>
      <a href="https://www.clickcease.com" rel="nofollow">
        <img src="https://monitor.clickcease.com/stats/stats.aspx" alt="ClickCease"/>
      </a>
    </noscript>
  `;
};

export const getTrafficGuardScript = (propertyId: string): string => {
  return `
    <script>
      (function(t,r,a,f,i,c,g,u,a,r,d){
        t.tg=t.tg||function(){(t.tg.q=t.tg.q||[]).push(arguments)};
        var s=r.createElement('script');s.async=1;s.src=a;
        r.head.appendChild(s);
      })(window,document,'https://cdn.trafficguard.ai/tg.js');
      tg('init', '${propertyId}');
    </script>
  `;
};

export const checkVisitorFraudScore = async (
  config: FraudProtectionConfig,
  visitorData: { ip?: string; userAgent: string; sessionId: string }
): Promise<{ isFraud: boolean; score: number; action: 'allow' | 'block' | 'challenge' }> => {

  if (config.provider === 'none') {
    return { isFraud: false, score: 0, action: 'allow' };
  }

  try {
    const response = await fetch('/api/fraud-check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        provider: config.provider,
        visitorData,
      }),
    });

    const result = await response.json();

    return {
      isFraud: result.score > (config.blockThreshold || 80),
      score: result.score,
      action: result.score > 80 ? 'block' : result.score > 50 ? 'challenge' : 'allow',
    };
  } catch (error) {
    console.error('Fraud check failed:', error);
    return { isFraud: false, score: 0, action: 'allow' };
  }
};
