import { supabase } from '../lib/supabase';
import { PlatformCategory, EducationalArticle, LeadGenPage } from '../types';

export interface GenerationResult {
  success: boolean;
  created: number;
  skipped: number;
  errors: string[];
  details: Array<{
    name: string;
    status: 'created' | 'skipped' | 'error';
    reason?: string;
  }>;
}

function createSlug(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

async function checkExistingPageForCategory(categoryId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('lead_gen_pages')
    .select('id')
    .eq('category_id', categoryId)
    .maybeSingle();

  if (error) {
    console.error('Error checking existing page:', error);
    return false;
  }

  return !!data;
}

function getRegulatoryBodyNote(regulatoryFocus: string): string {
  const lowerFocus = regulatoryFocus.toLowerCase();

  if (lowerFocus.includes('srij') || lowerFocus.includes('jogo')) {
    return 'Regulamentado pelo SRIJ (Serviço de Regulação e Inspeção de Jogos). Verifique sempre a licença no site oficial.';
  }

  if (lowerFocus.includes('banco') || lowerFocus.includes('bancário')) {
    return 'Supervisionado pelo Banco de Portugal. Certifique-se de que a instituição está devidamente autorizada.';
  }

  if (lowerFocus.includes('cmvm') || lowerFocus.includes('mercado')) {
    return 'Regulado pela CMVM (Comissão do Mercado de Valores Mobiliários). Verifique o registo oficial antes de investir.';
  }

  if (lowerFocus.includes('asae') || lowerFocus.includes('consumo')) {
    return 'Supervisionado pela ASAE (Autoridade de Segurança Alimentar e Económica). Procure fornecedores registados.';
  }

  return 'Verifique sempre a legalidade e regulamentação da plataforma antes de utilizar os seus serviços.';
}

function generateBullets(category: PlatformCategory): string[] {
  const bullets: string[] = [];

  bullets.push(`Guia completo sobre ${category.name_pt.toLowerCase()}`);
  bullets.push(`Informação sobre regulamentação e segurança`);
  bullets.push(`Análise de riscos e melhores práticas`);
  bullets.push(`Recursos educacionais para decisões informadas`);

  return bullets;
}

export async function generateLeadGenPagesFromCategories(): Promise<GenerationResult> {
  const result: GenerationResult = {
    success: true,
    created: 0,
    skipped: 0,
    errors: [],
    details: [],
  };

  try {
    const { data: categories, error: categoriesError } = await supabase
      .from('platform_categories')
      .select('*')
      .eq('is_active', true)
      .order('display_order', { ascending: true });

    if (categoriesError) {
      throw categoriesError;
    }

    if (!categories || categories.length === 0) {
      result.errors.push('No active categories found');
      result.success = false;
      return result;
    }

    for (const category of categories) {
      const exists = await checkExistingPageForCategory(category.id);

      if (exists) {
        result.skipped++;
        result.details.push({
          name: category.name_pt,
          status: 'skipped',
          reason: 'Lead Gen Page already exists for this category',
        });
        continue;
      }

      const baseSlug = createSlug(`${category.slug}-guia`);
      let slug = baseSlug;
      let counter = 1;

      while (true) {
        const { data: existingSlug } = await supabase
          .from('lead_gen_pages')
          .select('id')
          .eq('slug', slug)
          .maybeSingle();

        if (!existingSlug) break;
        slug = `${baseSlug}-${counter}`;
        counter++;
      }

      const newPage: Partial<LeadGenPage> = {
        name: `Guia Educacional: ${category.name_pt}`,
        slug,
        category_id: category.id,
        hero_title: `Guia Educacional: ${category.name_pt}`,
        hero_subtitle: category.description_pt || `Aprenda tudo sobre ${category.name_pt.toLowerCase()} de forma segura e informada.`,
        bullets: generateBullets(category),
        preview_text: `Este guia educacional oferece informação detalhada sobre ${category.name_pt.toLowerCase()}, incluindo aspectos regulatórios, riscos e melhores práticas. ${category.regulatory_focus}`,
        compliance_note: getRegulatoryBodyNote(category.regulatory_focus),
        iframe_embed_code: '',
        display_order: category.display_order,
        is_active: false,
      };

      const { error: insertError } = await supabase
        .from('lead_gen_pages')
        .insert([newPage]);

      if (insertError) {
        result.errors.push(`Failed to create page for ${category.name_pt}: ${insertError.message}`);
        result.details.push({
          name: category.name_pt,
          status: 'error',
          reason: insertError.message,
        });
      } else {
        result.created++;
        result.details.push({
          name: category.name_pt,
          status: 'created',
        });
      }
    }

    if (result.errors.length > 0) {
      result.success = false;
    }

  } catch (error) {
    result.success = false;
    result.errors.push(`General error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }

  return result;
}

export async function generateLeadGenPagesFromArticles(): Promise<GenerationResult> {
  const result: GenerationResult = {
    success: true,
    created: 0,
    skipped: 0,
    errors: [],
    details: [],
  };

  try {
    const { data: articles, error: articlesError } = await supabase
      .from('educational_articles')
      .select('*, platform_categories(*)')
      .eq('is_active', true)
      .not('category_id', 'is', null)
      .order('display_order', { ascending: true });

    if (articlesError) {
      throw articlesError;
    }

    if (!articles || articles.length === 0) {
      result.errors.push('No active articles with categories found');
      result.success = false;
      return result;
    }

    for (const article of articles) {
      if (!article.category_id) {
        continue;
      }

      const exists = await checkExistingPageForCategory(article.category_id);

      if (exists) {
        result.skipped++;
        result.details.push({
          name: article.title_pt,
          status: 'skipped',
          reason: 'Lead Gen Page already exists for this category',
        });
        continue;
      }

      const category = article.platform_categories;
      if (!category) {
        result.skipped++;
        result.details.push({
          name: article.title_pt,
          status: 'skipped',
          reason: 'Category not found',
        });
        continue;
      }

      const baseSlug = createSlug(`${article.slug}-guia`);
      let slug = baseSlug;
      let counter = 1;

      while (true) {
        const { data: existingSlug } = await supabase
          .from('lead_gen_pages')
          .select('id')
          .eq('slug', slug)
          .maybeSingle();

        if (!existingSlug) break;
        slug = `${baseSlug}-${counter}`;
        counter++;
      }

      const bullets: string[] = [];
      if (article.regulatory_status_pt) {
        bullets.push('Informação sobre regulamentação e licenciamento');
      }
      if (article.security_pt) {
        bullets.push('Medidas de segurança e proteção de dados');
      }
      if (article.consumer_protection_pt) {
        bullets.push('Direitos do consumidor e proteção legal');
      }
      if (article.risks_pt) {
        bullets.push('Análise de riscos e como os evitar');
      }

      if (bullets.length === 0) {
        bullets.push('Guia educacional completo');
        bullets.push('Informação verificada e atualizada');
        bullets.push('Recursos para decisões informadas');
      }

      const newPage: Partial<LeadGenPage> = {
        name: `Guia: ${article.title_pt}`,
        slug,
        category_id: article.category_id,
        hero_title: article.title_pt,
        hero_subtitle: article.intro_pt || `Aprenda tudo sobre este tema de forma segura e informada.`,
        bullets,
        preview_text: article.intro_pt || `Este guia oferece informação detalhada e educacional. Por ${article.author}.`,
        compliance_note: article.disclaimer_pt || getRegulatoryBodyNote(category.regulatory_focus || ''),
        iframe_embed_code: '',
        display_order: article.display_order,
        is_active: false,
      };

      const { error: insertError } = await supabase
        .from('lead_gen_pages')
        .insert([newPage]);

      if (insertError) {
        result.errors.push(`Failed to create page for ${article.title_pt}: ${insertError.message}`);
        result.details.push({
          name: article.title_pt,
          status: 'error',
          reason: insertError.message,
        });
      } else {
        result.created++;
        result.details.push({
          name: article.title_pt,
          status: 'created',
        });
      }
    }

    if (result.errors.length > 0) {
      result.success = false;
    }

  } catch (error) {
    result.success = false;
    result.errors.push(`General error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }

  return result;
}
