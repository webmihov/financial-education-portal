export const DEFAULT_HERO_TITLE = 'Guia Educacional Gratuito';
export const DEFAULT_HERO_SUBTITLE = 'Aprenda mais sobre depósitos e levantamentos em Portugal';

export const DEFAULT_BULLETS = [
  'Informação atualizada e independente',
  'Análise de regulação portuguesa',
  'Dicas de segurança e proteção',
  'Recursos educacionais gratuitos'
];

export const DEFAULT_PREVIEW_TEXT =
  'Complete o formulário abaixo para receber o nosso guia educacional gratuito. ' +
  'Este recurso ajuda-o a compreender melhor as opções disponíveis no mercado português.';

export const DEFAULT_COMPLIANCE_NOTE =
  'Este é um recurso educacional independente. Não somos consultores financeiros e não temos ' +
  'afiliações com instituições financeiras, bancos, ou outras entidades. O conteúdo é apenas ' +
  'informativo e não constitui aconselhamento financeiro. Para decisões importantes, consulte ' +
  'sempre profissionais qualificados.';

export const DEFAULT_CTA_TEXT = 'Saber Mais';

export const DEFAULT_PROMOTION_TITLE = 'Guia Educacional Gratuito';
export const DEFAULT_PROMOTION_DESCRIPTION =
  'Aprenda sobre depósitos, levantamentos e proteção do consumidor em Portugal.';

export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .substring(0, 100);
}

export function validateInternalSlug(slug: string): boolean {
  if (!slug || slug.length === 0) {
    return false;
  }

  const externalPatterns = [
    'http://',
    'https://',
    'www.',
    '//',
    '.com',
    '.pt',
    '.eu',
  ];

  return !externalPatterns.some(pattern => slug.includes(pattern));
}

export function sanitizeSlug(slug: string): string {
  return slug.toLowerCase().replace(/[^a-z0-9-]/g, '');
}

export const PROMOTION_TYPE_LABELS: Record<string, string> = {
  banner: 'Banner (Full width)',
  button: 'Button (Compact)',
  inline_card: 'Card (With border)',
  text_ad: 'Text Ad (Minimal)'
};

export const PLACEMENT_POSITION_LABELS: Record<string, string> = {
  top: 'Top of page',
  middle: 'Middle of page',
  bottom: 'Bottom of page',
  sidebar: 'Sidebar'
};

export const TARGET_LOCATION_LABELS: Record<string, string> = {
  landing: 'Landing page',
  article: 'Educational articles',
  category: 'Category pages'
};

export const VALID_POSITIONS_BY_TYPE: Record<string, string[]> = {
  banner: ['top', 'middle', 'bottom'],
  inline_card: ['top', 'middle', 'bottom', 'sidebar'],
  text_ad: ['top', 'middle', 'bottom', 'sidebar'],
  button: ['top', 'middle', 'bottom', 'sidebar']
};

export const RECOMMENDED_POSITION_BY_TYPE: Record<string, string> = {
  banner: 'top',
  inline_card: 'middle',
  text_ad: 'sidebar',
  button: 'middle'
};

export function getValidPositionsForType(promotionType: string): string[] {
  return VALID_POSITIONS_BY_TYPE[promotionType] || [];
}

export function getRecommendedPositionForType(promotionType: string): string {
  return RECOMMENDED_POSITION_BY_TYPE[promotionType] || 'middle';
}

export function isValidPositionForType(promotionType: string, position: string): boolean {
  const validPositions = VALID_POSITIONS_BY_TYPE[promotionType];
  return validPositions ? validPositions.includes(position) : false;
}
