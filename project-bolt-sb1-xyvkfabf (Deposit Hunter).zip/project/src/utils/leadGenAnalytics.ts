import { supabase } from '../lib/supabase';
import type { DetectionSignals } from '../hooks/useVisitorProfile';

async function hashIP(ip: string): Promise<string> {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(ip + 'salt_for_privacy');
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } catch {
    return 'unknown';
  }
}

async function getClientIP(): Promise<string> {
  return 'client_ip_unavailable';
}

interface EnhancedAnalyticsData {
  visitorClassification?: 'human' | 'bot' | 'uncertain';
  ipType?: string;
  hasJavascript?: boolean;
  detectionSignals?: DetectionSignals;
  deviceAuthenticityScore?: number;
  isHeadlessBrowser?: boolean;
  isOldBrowser?: boolean;
  ptrHostname?: string;
  iframeVersionShown?: 'version1' | 'version2' | 'none' | 'pending';
  detectionReason?: string;
  pageUrl?: string;
}

async function callVisitorDetectionEdgeFunction(
  pageId: string,
  promotionId: string | null,
  eventType: 'page_view' | 'promotion_click',
  referrer: string,
  enhancedData?: EnhancedAnalyticsData
): Promise<void> {
  try {
    const ip = await getClientIP();
    const ipHash = await hashIP(ip);
    const userAgent = navigator.userAgent;

    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/visitor-detection`;

    const signals = enhancedData?.detectionSignals || {
      hasModernApis: true,
      isHeadless: false,
      behaviorScore: 70,
    };

    await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userAgent,
        ipHash,
        signals,
        leadGenPageId: pageId,
        promotionId,
        eventType,
        referrerPage: referrer,
        iframeVersionShown: enhancedData?.iframeVersionShown || 'pending',
        detectionReason: enhancedData?.detectionReason || '',
        pageUrl: enhancedData?.pageUrl || window.location.pathname,
      }),
    });
  } catch (error) {
    console.error('Failed to call visitor detection:', error);
  }
}

export async function trackLeadGenPageView(
  pageId: string,
  referrer: string = document.referrer || 'direct',
  enhancedData?: EnhancedAnalyticsData
): Promise<void> {
  await callVisitorDetectionEdgeFunction(pageId, null, 'page_view', referrer, enhancedData);
}

export async function trackPromotionClick(
  promotionId: string,
  pageId: string,
  referrer: string = window.location.pathname,
  enhancedData?: EnhancedAnalyticsData
): Promise<void> {
  await callVisitorDetectionEdgeFunction(pageId, promotionId, 'promotion_click', referrer, enhancedData);
}

export async function getLeadGenPageStats(pageId: string) {
  try {
    const { data: pageViews, error: viewsError } = await supabase
      .from('lead_gen_analytics')
      .select('id')
      .eq('lead_gen_page_id', pageId)
      .eq('event_type', 'page_view');

    const { data: clicks, error: clicksError } = await supabase
      .from('lead_gen_analytics')
      .select('id')
      .eq('lead_gen_page_id', pageId)
      .eq('event_type', 'promotion_click');

    if (viewsError || clicksError) {
      throw new Error('Failed to fetch stats');
    }

    return {
      pageViews: pageViews?.length || 0,
      clicks: clicks?.length || 0,
    };
  } catch (error) {
    console.error('Failed to get page stats:', error);
    return { pageViews: 0, clicks: 0 };
  }
}

export async function getPromotionStats(promotionId: string) {
  try {
    const { data, error } = await supabase
      .from('lead_gen_analytics')
      .select('id')
      .eq('promotion_id', promotionId)
      .eq('event_type', 'promotion_click');

    if (error) {
      throw error;
    }

    return {
      clicks: data?.length || 0,
    };
  } catch (error) {
    console.error('Failed to get promotion stats:', error);
    return { clicks: 0 };
  }
}
