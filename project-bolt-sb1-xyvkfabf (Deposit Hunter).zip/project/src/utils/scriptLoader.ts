import { supabase } from '../lib/supabase';

interface TrackingScript {
  id: string;
  name: string;
  script_type: 'google_analytics' | 'remarketing' | 'custom';
  content: string;
  placement: 'head' | 'body';
  priority: number;
  is_active: boolean;
  requires_consent: boolean;
  consent_category: 'analytics' | 'marketing' | 'preferences' | null;
}

interface ConsentPreferences {
  necessary: boolean;
  analytics: boolean;
  marketing: boolean;
  preferences: boolean;
}

const loadedScripts = new Set<string>();

export async function loadTrackingScripts(consentPreferences: ConsentPreferences) {
  try {
    const { data: scripts, error } = await supabase
      .from('tracking_scripts')
      .select('*')
      .eq('is_active', true)
      .order('priority', { ascending: true });

    if (error) {
      console.error('Error fetching tracking scripts:', error);
      return;
    }

    if (!scripts || scripts.length === 0) {
      return;
    }

    scripts.forEach((script: TrackingScript) => {
      if (loadedScripts.has(script.id)) {
        return;
      }

      if (script.requires_consent && script.consent_category) {
        const hasConsent = consentPreferences[script.consent_category as keyof ConsentPreferences];
        if (!hasConsent) {
          return;
        }
      }

      injectScript(script);
      loadedScripts.add(script.id);
    });
  } catch (error) {
    console.error('Error loading tracking scripts:', error);
  }
}

function injectScript(script: TrackingScript) {
  try {
    const targetElement = script.placement === 'head' ? document.head : document.body;
    const content = script.content.trim();

    if (content.includes('<script')) {
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = content;
      const parsedScripts = tempDiv.querySelectorAll('script');

      parsedScripts.forEach((parsedScript, index) => {
        const scriptElement = document.createElement('script');
        scriptElement.setAttribute('data-script-id', script.id);
        scriptElement.setAttribute('data-script-name', script.name);
        scriptElement.setAttribute('data-script-index', index.toString());
        scriptElement.type = 'text/javascript';

        if (parsedScript.src) {
          scriptElement.src = parsedScript.src;
          if (parsedScript.async) scriptElement.async = true;
          if (parsedScript.defer) scriptElement.defer = true;

          Array.from(parsedScript.attributes).forEach((attr) => {
            if (!['src', 'async', 'defer', 'type'].includes(attr.name)) {
              scriptElement.setAttribute(attr.name, attr.value);
            }
          });
        } else {
          const scriptContent = parsedScript.textContent || parsedScript.innerHTML;
          if (scriptContent) {
            scriptElement.textContent = scriptContent;
          }
        }

        targetElement.appendChild(scriptElement);
      });
    } else {
      const scriptElement = document.createElement('script');
      scriptElement.setAttribute('data-script-id', script.id);
      scriptElement.setAttribute('data-script-name', script.name);
      scriptElement.type = 'text/javascript';
      scriptElement.textContent = content;
      targetElement.appendChild(scriptElement);
    }
  } catch (error) {
    console.error(`Error injecting script "${script.name}":`, error);
  }
}

export function removeTrackingScripts(consentCategory?: string) {
  const scripts = document.querySelectorAll('[data-script-id]');

  scripts.forEach((scriptElement) => {
    const scriptId = scriptElement.getAttribute('data-script-id');

    if (consentCategory) {
      const scriptName = scriptElement.getAttribute('data-script-name');
      if (scriptName?.toLowerCase().includes(consentCategory.toLowerCase())) {
        scriptElement.remove();
        if (scriptId) loadedScripts.delete(scriptId);
      }
    } else {
      scriptElement.remove();
      if (scriptId) loadedScripts.delete(scriptId);
    }
  });
}

export function reloadTrackingScripts(consentPreferences: ConsentPreferences) {
  removeTrackingScripts();
  loadTrackingScripts(consentPreferences);
}
