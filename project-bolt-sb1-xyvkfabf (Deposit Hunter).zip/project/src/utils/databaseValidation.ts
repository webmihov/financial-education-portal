import { supabase } from '../lib/supabase';

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  info: string[];
}

export async function validateLeadGenSystem(): Promise<ValidationResult> {
  const result: ValidationResult = {
    isValid: true,
    errors: [],
    warnings: [],
    info: [],
  };

  try {
    const orphanedPromotions = await findOrphanedPromotions();
    if (orphanedPromotions.length > 0) {
      result.isValid = false;
      result.errors.push(
        `Found ${orphanedPromotions.length} orphaned promotions (lead_gen_page deleted)`
      );
      result.info.push(
        `Orphaned promotion IDs: ${orphanedPromotions.map((p) => p.id).join(', ')}`
      );
    }

    const invalidCategoryRefs = await findInvalidCategoryReferences();
    if (invalidCategoryRefs.length > 0) {
      result.warnings.push(
        `Found ${invalidCategoryRefs.length} promotions with invalid category_id references`
      );
    }

    const inactivePagePromotions = await findPromotionsWithInactivePages();
    if (inactivePagePromotions.length > 0) {
      result.warnings.push(
        `Found ${inactivePagePromotions.length} active promotions linked to inactive pages`
      );
    }

    const emptyTargetPromotions = await findPromotionsWithEmptyTargets();
    if (emptyTargetPromotions.length > 0) {
      result.warnings.push(
        `Found ${emptyTargetPromotions.length} promotions with no target locations`
      );
    }

    const pagesWithoutPromotions = await findPagesWithoutPromotions();
    if (pagesWithoutPromotions.length > 0) {
      result.info.push(
        `Found ${pagesWithoutPromotions.length} active pages without any promotions`
      );
    }

    const orphanedAnalytics = await findOrphanedAnalytics();
    if (orphanedAnalytics > 0) {
      result.warnings.push(
        `Found ${orphanedAnalytics} orphaned analytics entries`
      );
    }

  } catch (error) {
    result.isValid = false;
    result.errors.push(
      `Validation error: ${error instanceof Error ? error.message : 'Unknown error'}`
    );
  }

  return result;
}

async function findOrphanedPromotions() {
  const { data: promotions, error } = await supabase
    .from('lead_gen_promotions')
    .select('id, lead_gen_page_id');

  if (error || !promotions) return [];

  const { data: pages } = await supabase
    .from('lead_gen_pages')
    .select('id');

  if (!pages) return [];

  const pageIds = new Set(pages.map((p) => p.id));
  return promotions.filter((promo) => !pageIds.has(promo.lead_gen_page_id));
}

async function findInvalidCategoryReferences() {
  const { data: promotions, error } = await supabase
    .from('lead_gen_promotions')
    .select('id, target_category_ids');

  if (error || !promotions) return [];

  const { data: categories } = await supabase
    .from('platform_categories')
    .select('id');

  if (!categories) return [];

  const categoryIds = new Set(categories.map((c) => c.id));

  return promotions.filter((promo) =>
    promo.target_category_ids.some((catId: string) => !categoryIds.has(catId))
  );
}

async function findPromotionsWithInactivePages() {
  const { data, error } = await supabase
    .from('lead_gen_promotions')
    .select(`
      id,
      is_active,
      lead_gen_pages!inner(id, is_active)
    `)
    .eq('is_active', true);

  if (error || !data) return [];

  return data.filter((promo: any) => !promo.lead_gen_pages?.is_active);
}

async function findPromotionsWithEmptyTargets() {
  const { data, error } = await supabase
    .from('lead_gen_promotions')
    .select('id, target_locations')
    .eq('is_active', true);

  if (error || !data) return [];

  return data.filter((promo) => !promo.target_locations || promo.target_locations.length === 0);
}

async function findPagesWithoutPromotions() {
  const { data: pages, error } = await supabase
    .from('lead_gen_pages')
    .select('id')
    .eq('is_active', true);

  if (error || !pages) return [];

  const { data: promotions } = await supabase
    .from('lead_gen_promotions')
    .select('lead_gen_page_id')
    .eq('is_active', true);

  if (!promotions) return pages;

  const pageIdsWithPromotions = new Set(promotions.map((p) => p.lead_gen_page_id));
  return pages.filter((page) => !pageIdsWithPromotions.has(page.id));
}

async function findOrphanedAnalytics() {
  const { data: analytics, error } = await supabase
    .from('lead_gen_analytics')
    .select('id, lead_gen_page_id, promotion_id')
    .not('lead_gen_page_id', 'is', null);

  if (error || !analytics) return 0;

  const { data: pages } = await supabase.from('lead_gen_pages').select('id');
  const { data: promotions } = await supabase.from('lead_gen_promotions').select('id');

  if (!pages || !promotions) return 0;

  const pageIds = new Set(pages.map((p) => p.id));
  const promotionIds = new Set(promotions.map((p) => p.id));

  return analytics.filter((entry) => {
    if (entry.lead_gen_page_id && !pageIds.has(entry.lead_gen_page_id)) return true;
    if (entry.promotion_id && !promotionIds.has(entry.promotion_id)) return true;
    return false;
  }).length;
}

export async function cleanupOrphanedPromotions(): Promise<{ deleted: number; error?: string }> {
  try {
    const orphaned = await findOrphanedPromotions();

    if (orphaned.length === 0) {
      return { deleted: 0 };
    }

    const orphanedIds = orphaned.map((p) => p.id);
    const { error } = await supabase
      .from('lead_gen_promotions')
      .delete()
      .in('id', orphanedIds);

    if (error) {
      return { deleted: 0, error: error.message };
    }

    return { deleted: orphanedIds.length };
  } catch (error) {
    return {
      deleted: 0,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

export async function cleanupOrphanedAnalytics(): Promise<{ deleted: number; error?: string }> {
  try {
    const { data: analytics, error: fetchError } = await supabase
      .from('lead_gen_analytics')
      .select('id, lead_gen_page_id, promotion_id');

    if (fetchError || !analytics) {
      return { deleted: 0, error: fetchError?.message || 'Failed to fetch analytics' };
    }

    const { data: pages } = await supabase.from('lead_gen_pages').select('id');
    const { data: promotions } = await supabase.from('lead_gen_promotions').select('id');

    if (!pages || !promotions) {
      return { deleted: 0, error: 'Failed to fetch references' };
    }

    const pageIds = new Set(pages.map((p) => p.id));
    const promotionIds = new Set(promotions.map((p) => p.id));

    const orphanedIds = analytics
      .filter((entry) => {
        if (entry.lead_gen_page_id && !pageIds.has(entry.lead_gen_page_id)) return true;
        if (entry.promotion_id && !promotionIds.has(entry.promotion_id)) return true;
        return false;
      })
      .map((entry) => entry.id);

    if (orphanedIds.length === 0) {
      return { deleted: 0 };
    }

    const { error: deleteError } = await supabase
      .from('lead_gen_analytics')
      .delete()
      .in('id', orphanedIds);

    if (deleteError) {
      return { deleted: 0, error: deleteError.message };
    }

    return { deleted: orphanedIds.length };
  } catch (error) {
    return {
      deleted: 0,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}
