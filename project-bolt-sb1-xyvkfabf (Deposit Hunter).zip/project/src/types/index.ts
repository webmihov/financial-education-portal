export interface DepositType {
  id: string;
  name: string;
  rating: number;
  educational_note: string;
  pros: string[];
  cons: string[];
  category: string;
  typical_rate_range: string;
  description: string;
  minimum_deposit_typical: string;
  fdic_insured: boolean;
  liquidity_rating: string;
  best_for: string;
  srij_license_required: boolean;
  regulatory_body_pt: string;
  license_verification_url: string;
  risk_level_pt: string;
  legal_status_pt: string;
  display_order: number;
  is_active: boolean;
  icon_name: string;
  created_at: string;
  updated_at: string;
}

export interface PlatformCategory {
  id: string;
  name_pt: string;
  name_en: string;
  slug: string;
  description_pt: string;
  description_en: string;
  icon_name: string;
  regulatory_focus: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface EducationalArticle {
  id: string;
  title_pt: string;
  title_en: string;
  slug: string;
  category_id: string | null;
  intro_pt: string;
  intro_en: string;
  how_it_works_pt: string;
  how_it_works_en: string;
  regulatory_status_pt: string;
  regulatory_status_en: string;
  risks_pt: string;
  risks_en: string;
  security_pt: string;
  security_en: string;
  red_flags_pt: string;
  red_flags_en: string;
  consumer_protection_pt: string;
  consumer_protection_en: string;
  disclaimer_pt: string;
  disclaimer_en: string;
  author: string;
  last_reviewed: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface RegulatoryBody {
  id: string;
  name_pt: string;
  name_en: string;
  acronym: string;
  description_pt: string;
  description_en: string;
  jurisdiction: string;
  oversight_areas: string[];
  website_url: string;
  verification_url: string;
  complaint_url: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface PaymentMethodPT {
  id: string;
  name_pt: string;
  name_en: string;
  method_type: string;
  description_pt: string;
  description_en: string;
  pros_pt: string[];
  pros_en: string[];
  cons_pt: string[];
  cons_en: string[];
  security_level: string;
  typical_fees_pt: string;
  typical_fees_en: string;
  processing_time_pt: string;
  processing_time_en: string;
  icon_name: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface RiskWarning {
  id: string;
  warning_key: string;
  title_pt: string;
  title_en: string;
  content_pt: string;
  content_en: string;
  severity_level: string;
  applies_to: string[];
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface EducationalTestimonial {
  id: string;
  user_name: string;
  location: string;
  review_text: string;
  is_verified: boolean;
  is_active: boolean;
  display_order: number;
  created_at: string;
}

export interface PageContent {
  id: string;
  section_key: string;
  title: string;
  subtitle: string;
  content_json: Record<string, any>;
  is_active: boolean;
  updated_at: string;
}

export interface AdminUser {
  id: string;
  email: string;
  role: 'admin' | 'editor' | 'viewer';
  last_login: string | null;
  created_at: string;
}

export interface ComplianceSetting {
  id: string;
  setting_key: string;
  setting_value: string;
  description: string;
  updated_at: string;
}

export interface UserInteraction {
  id: string;
  action_type: string;
  deposit_type_id: string | null;
  ip_hash: string;
  user_agent: string;
  timestamp: string;
}

export interface Website {
  id: string;
  name: string;
  category: string;
  status_badge: string;
  icon_name: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export type Language = 'pt' | 'en';

export type PromotionType = 'banner' | 'button' | 'inline_card' | 'text_ad';
export type PlacementPosition = 'top' | 'middle' | 'bottom' | 'sidebar';
export type TargetLocation = 'landing' | 'article' | 'category';

export interface LeadGenPage {
  id: string;
  name: string;
  slug: string;
  category_id: string | null;
  hero_title: string;
  hero_subtitle: string;
  bullets: string[];
  preview_text: string;
  compliance_note: string;
  iframe_embed_code: string;
  iframe_version1: string | null;
  iframe_visibility_mode: 'all';
  display_order: number;
  is_active: boolean;
  manual_hide_iframe: boolean;
  created_at: string;
  updated_at: string;
}

export interface LeadGenPromotion {
  id: string;
  lead_gen_page_id: string;
  promotion_type: PromotionType;
  promotion_title: string;
  promotion_description: string;
  cta_text: string;
  target_locations: TargetLocation[];
  target_category_ids: string[];
  placement_position: PlacementPosition;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface LeadGenAnalytics {
  id: string;
  lead_gen_page_id: string | null;
  promotion_id: string | null;
  event_type: 'page_view' | 'promotion_click';
  referrer_page: string;
  ip_hash: string;
  user_agent: string;
  timestamp: string;
}
