import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useEffect } from 'react';
import { LandingPage } from './pages/LandingPage';
import { ArticlePage } from './pages/ArticlePage';
import { LeadGenPage } from './pages/LeadGenPage';
import { TermsPage } from './pages/TermsPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { AboutPage } from './pages/AboutPage';
import { DisclaimerPage } from './pages/DisclaimerPage';
import { CookiePolicyPage } from './pages/CookiePolicyPage';
import { AccessibilityPage } from './pages/AccessibilityPage';
import { EditorialStandardsPage } from './pages/EditorialStandardsPage';
import { AffiliateDisclosurePage } from './pages/AffiliateDisclosurePage';
import { AdminLogin } from './pages/admin/AdminLogin';
import { AdminLayout } from './pages/admin/AdminLayout';
import { Dashboard } from './pages/admin/Dashboard';
import { PlatformCategoriesManagement } from './pages/admin/PlatformCategoriesManagement';
import { EducationalTestimonialsManagement } from './pages/admin/ReviewsManagement';
import { EducationalArticlesManagement } from './pages/admin/EducationalArticlesManagement';
import { RegulatoryBodiesManagement } from './pages/admin/RegulatoryBodiesManagement';
import { PaymentMethodsManagement } from './pages/admin/PaymentMethodsManagement';
import { RiskWarningsManagement } from './pages/admin/RiskWarningsManagement';
import { ContentManagement } from './pages/admin/ContentManagement';
import TrackingScriptsManagement from './pages/admin/TrackingScriptsManagement';
import { LeadGenPagesManagement } from './pages/admin/LeadGenPagesManagement';
import { LeadGenPromotionsManagement } from './pages/admin/LeadGenPromotionsManagement';
import PromotionDiagnostics from './pages/admin/PromotionDiagnostics';
import { VisitorAnalytics } from './pages/admin/VisitorAnalytics';
import { ProtectedRoute } from './components/ProtectedRoute';
import { RiskWarningBanner } from './components/RiskWarningBanner';
import { loadTrackingScripts } from './utils/scriptLoader';
import { useLocalStorage } from './hooks/useLocalStorage';

function App() {
  const [cookieConsent] = useLocalStorage('cookie_consent', null);

  useEffect(() => {
    const consentPreferences = {
      necessary: true,
      analytics: cookieConsent?.analytics || false,
      marketing: cookieConsent?.marketing || cookieConsent?.advertising || false,
      preferences: cookieConsent?.essential || false,
    };
    loadTrackingScripts(consentPreferences);
  }, [cookieConsent]);

  return (
    <BrowserRouter>
      <RiskWarningBanner />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/guia/:slug" element={<ArticlePage />} />
        <Route path="/lp/:slug" element={<LeadGenPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/disclaimer" element={<DisclaimerPage />} />
        <Route path="/cookie-policy" element={<CookiePolicyPage />} />
        <Route path="/accessibility" element={<AccessibilityPage />} />
        <Route path="/editorial-standards" element={<EditorialStandardsPage />} />
        <Route path="/affiliate-disclosure" element={<AffiliateDisclosurePage />} />

        <Route path="/admin" element={<AdminLogin />} />

        <Route
          path="/admin/*"
          element={
            <ProtectedRoute>
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="categories" element={<PlatformCategoriesManagement />} />
          <Route path="articles" element={<EducationalArticlesManagement />} />
          <Route path="testimonials" element={<EducationalTestimonialsManagement />} />
          <Route path="regulatory" element={<RegulatoryBodiesManagement />} />
          <Route path="payments" element={<PaymentMethodsManagement />} />
          <Route path="warnings" element={<RiskWarningsManagement />} />
          <Route path="compliance" element={<ContentManagement />} />
          <Route path="tracking" element={<TrackingScriptsManagement />} />
          <Route path="lead-gen" element={<LeadGenPagesManagement />} />
          <Route path="lead-gen-promotions" element={<LeadGenPromotionsManagement />} />
          <Route path="promotion-diagnostics" element={<PromotionDiagnostics />} />
          <Route path="visitor-analytics" element={<VisitorAnalytics />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
