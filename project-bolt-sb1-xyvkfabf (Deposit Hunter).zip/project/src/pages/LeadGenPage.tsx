import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { CheckCircle, AlertCircle, ArrowLeft, Info, ExternalLink } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { LeadGenPage as LeadGenPageType } from '../types';
import { trackLeadGenPageView } from '../utils/leadGenAnalytics';
import { getVisitorInfo, shouldShowIframe } from '../utils/visitorDetection';
import { Header } from '../components/landing/Header';
import { Footer } from '../components/landing/Footer';

export function LeadGenPage() {
  const { slug } = useParams<{ slug: string }>();
  const [page, setPage] = useState<LeadGenPageType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [showIframe, setShowIframe] = useState(true);

  useEffect(() => {
    async function fetchPage() {
      if (!slug) {
        setError(true);
        setLoading(false);
        return;
      }

      try {
        const { data, error: fetchError } = await supabase
          .from('lead_gen_pages')
          .select('*')
          .eq('slug', slug)
          .eq('is_active', true)
          .maybeSingle();

        if (fetchError || !data) {
          setError(true);
        } else {
          setPage(data);
        }
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    }

    fetchPage();
  }, [slug]);

  useEffect(() => {
    if (page) {
      trackLeadGenPageView(page.id, document.referrer);

      const visitorInfo = getVisitorInfo();
      const iframeVisible = shouldShowIframe(page.manual_hide_iframe, visitorInfo.classification);
      setShowIframe(iframeVisible);

      async function trackVisitorAnalytics() {
        try {
          let ipHash: string | null = null;

          try {
            const ipResponse = await fetch('https://api.ipify.org?format=json', {
              signal: AbortSignal.timeout(2000),
            });
            const ipData = await ipResponse.json();
            ipHash = await hashIP(ipData.ip);
          } catch {
            // IP lookup failed or timed out - continue without it
          }

          await supabase.from('visitor_analytics').insert({
            page_id: page.id,
            visitor_type: visitorInfo.classification.type,
            saw_iframe: iframeVisible,
            user_agent: visitorInfo.userAgent,
            referrer: visitorInfo.referrer,
            ip_hash: ipHash,
          });
        } catch (error) {
          console.error('Failed to track visitor analytics:', error);
        }
      }

      trackVisitorAnalytics();
    }
  }, [page]);

  async function hashIP(ip: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(ip);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-3/4 mx-auto mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !page) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Página Não Encontrada
          </h1>
          <p className="text-gray-600 mb-8">
            A página que procura não existe ou não está disponível.
          </p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-6 py-3 bg-educational-primary text-white rounded-lg hover:bg-educational-secondary transition"
          >
            <ArrowLeft className="w-5 h-5" />
            Voltar à Página Principal
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main className="max-w-5xl mx-auto px-4 py-12">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-blue-800">
                <strong>Divulgação de Afiliado:</strong> Este site pode receber compensação
                por referências a operadores licenciados. Todos os operadores apresentados
                são licenciados pelo SRIJ.{' '}
                <a
                  href="https://www.srij.turismodeportugal.pt/pt/atividade/operadores-licenciados/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 underline hover:text-blue-900"
                >
                  Verificar licenças <ExternalLink className="w-3 h-3" />
                </a>
              </p>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-educational-primary hover:text-educational-secondary transition mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Link>

          <div className="bg-gradient-to-r from-educational-primary to-educational-secondary text-white rounded-2xl p-8 md:p-12 mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {page.hero_title}
            </h1>
            <p className="text-xl text-white/90">
              {page.hero_subtitle}
            </p>
          </div>

          {page.bullets && page.bullets.length > 0 && (
            <div className="grid md:grid-cols-2 gap-4 mb-8">
              {page.bullets.map((bullet, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 bg-gray-50 rounded-lg p-4"
                >
                  <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">{bullet}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {page.preview_text && (
          <div className="bg-blue-50 border-l-4 border-blue-600 p-6 rounded-r-lg mb-8">
            <p className="text-gray-700 leading-relaxed">{page.preview_text}</p>
          </div>
        )}

        {page.iframe_version1 && showIframe && (
          <div
            className="mb-8"
            dangerouslySetInnerHTML={{ __html: page.iframe_version1 }}
          />
        )}

        <div className="bg-red-50 border-2 border-red-300 rounded-lg p-6 mb-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-red-900 mb-2 text-lg">
                ⚠️ Jogo Responsável
              </h3>
              <div className="space-y-2 text-sm text-red-800">
                <p className="font-semibold">
                  O jogo pode causar dependência. Jogue com moderação.
                </p>
                <p>
                  <strong>Linha de Apoio:</strong> 808 200 204 (Linha Vida)
                </p>
                <p>
                  <strong>Idade mínima:</strong> 18 anos
                </p>
                <a
                  href="https://www.srij.turismodeportugal.pt"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-red-700 hover:text-red-900 underline"
                >
                  SRIJ - Verificar Licenças <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {page.compliance_note && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-amber-900 mb-2">
                  Aviso Importante
                </h3>
                <p className="text-sm text-amber-800 leading-relaxed">
                  {page.compliance_note}
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
