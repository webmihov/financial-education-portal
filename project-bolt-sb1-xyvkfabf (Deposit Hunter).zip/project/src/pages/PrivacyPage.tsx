import { LegalLayout } from './LegalLayout';

export function PrivacyPage() {
  return (
    <LegalLayout title="Privacy Policy" lastUpdated="December 4, 2024">
      <div className="space-y-6 text-gray-700">
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Introduction</h2>
          <p>
            This Privacy Policy explains how we collect, use, disclose, and safeguard your information
            when you visit our educational portal. We are committed to protecting your privacy
            and complying with GDPR and Portuguese data protection laws (CNPD).
          </p>
          <p className="mt-2">
            <strong>Affiliate Disclosure:</strong> We operate as an educational resource that includes
            affiliate links and promotional content. We use tracking technologies for analytics,
            advertising, and affiliate marketing purposes, which helps fund this free educational resource.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Information We Collect</h2>
          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Automatically Collected Information</h3>
          <p>When you visit our website, we automatically collect:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>IP address (hashed for privacy)</li>
            <li>Browser type and version</li>
            <li>Pages visited and time spent</li>
            <li>Referring website</li>
            <li>Date and time of visit</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Cookies and Tracking</h3>
          <p>
            We use cookies and similar tracking technologies to enhance your experience. You can manage
            your cookie preferences through our cookie consent banner.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">3. How We Use Your Information</h2>
          <p>We use the collected information to:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Operate and maintain the educational portal</li>
            <li>Improve user experience and educational content quality</li>
            <li>Analyze usage patterns to understand educational content effectiveness</li>
            <li>Understand user interests for content improvement</li>
            <li>Prevent fraud and ensure website security</li>
            <li>Comply with legal obligations</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Remarketing and Advertising Tracking</h2>
          <p>
            <strong>Important Disclosure:</strong> We use remarketing and advertising tracking technologies
            from third-party advertising platforms to understand user interests and improve our educational
            content. This is our primary funding model that allows us to provide free educational resources.
          </p>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Tracking Technologies Used</h3>
          <p>We use tracking pixels and cookies from the following advertising platforms:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li><strong>Google Ads Remarketing:</strong> Tracks user interactions for remarketing purposes</li>
            <li><strong>Google Analytics:</strong> Analyzes user behavior and content effectiveness</li>
            <li><strong>Other advertising platforms:</strong> May include Meta Pixel, Bing Ads, or similar platforms</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Purpose of Tracking</h3>
          <p>These tracking technologies help us:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Understand which educational topics interest our visitors</li>
            <li>Improve our educational content based on user engagement</li>
            <li>Measure the effectiveness of our educational materials</li>
            <li>Support our free educational portal through advertising revenue</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">How to Opt-Out</h3>
          <p>You can opt-out of remarketing and advertising tracking through:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Google Ads Settings (adssettings.google.com) - Manage Google Ads personalization</li>
            <li>Facebook Ad Preferences (facebook.com/ads/preferences) - Control Facebook ads</li>
            <li>Your Online Choices EU (youronlinechoices.eu) - Opt-out of behavioral advertising</li>
            <li>Our cookie consent banner - Disable advertising/remarketing cookies</li>
            <li>Browser settings - Block third-party cookies</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Information Sharing</h2>
          <p>
            <strong>We do not sell your personal information.</strong> We may share anonymized, aggregated
            data with:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Analytics service providers (Google Analytics)</li>
            <li>Advertising platforms (for remarketing purposes as described above)</li>
            <li>Legal authorities when required by Portuguese or EU law</li>
          </ul>
          <p className="mt-2">
            All third-party services are GDPR-compliant and operate under data processing agreements.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Cookies and Tracking Technologies</h2>
          <p>
            We use cookies and similar tracking technologies. You can control cookie preferences through
            our cookie consent banner that appears on your first visit.
          </p>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Essential Cookies</h3>
          <p>
            Required for the website to function properly. These cookies cannot be disabled as they are
            necessary for basic operations like age verification, cookie consent preferences, and security.
          </p>
          <p className="text-sm text-gray-600 mt-1">
            Examples: age_verified, cookie_consent, session_id
          </p>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Analytics Cookies</h3>
          <p>
            Help us understand how visitors interact with our educational content by collecting and
            reporting information anonymously. These cookies track page views, session duration, and
            content engagement.
          </p>
          <p className="text-sm text-gray-600 mt-1">
            Examples: _ga, _gid, _gat (Google Analytics)
          </p>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Remarketing/Advertising Cookies</h3>
          <p>
            <strong>These cookies are used for remarketing purposes.</strong> They track your visit to our
            educational portal so we can understand user interests and support our free educational content
            through advertising revenue. These cookies are set by advertising platforms like Google Ads.
          </p>
          <p className="text-sm text-gray-600 mt-1">
            Examples: _gcl_au (Google Ads), fr (Facebook Pixel), other advertising platform identifiers
          </p>
          <p className="mt-2">
            <strong>You can disable these cookies through our cookie consent banner or your browser settings.</strong>
            This will not affect your ability to use our educational content.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Your Rights (GDPR)</h2>
          <p>Under GDPR and Portuguese law, you have the right to:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Access your personal data</li>
            <li>Rectify inaccurate data</li>
            <li>Request deletion of your data</li>
            <li>Object to data processing</li>
            <li>Data portability</li>
            <li>Withdraw consent at any time</li>
          </ul>
          <p className="mt-2">
            To exercise these rights, contact us at: info@deposithunter.com
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Data Security</h2>
          <p>
            We implement appropriate technical and organizational measures to protect your data against
            unauthorized access, alteration, disclosure, or destruction. However, no method of transmission
            over the internet is 100% secure.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Third-Party Links and Affiliate Relationships</h2>
          <p>
            Our educational portal contains links to third-party websites, including affiliate partner sites
            and Portuguese regulatory authorities. Some links may be affiliate links where we receive
            compensation for referrals. We are not responsible for the privacy practices of these external
            sites. We encourage you to read their privacy policies.
          </p>
          <p className="mt-2">
            <strong>Note:</strong> Affiliate relationships may influence which services are featured or
            linked on this site. We encourage independent research before making any decisions.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Children's Privacy</h2>
          <p>
            Our website is not intended for individuals under 18 years of age. We do not knowingly collect
            data from minors. If you believe we have collected data from a minor, please contact us immediately.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">11. Data Retention</h2>
          <p>
            We retain your data only as long as necessary for the purposes outlined in this policy or
            as required by Portuguese and EU law. Analytics and remarketing data is typically retained
            for 14-26 months as per platform policies.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">12. Changes to Privacy Policy</h2>
          <p>
            We may update this Privacy Policy periodically. Changes will be posted on this page with an
            updated revision date. We encourage you to review this policy regularly.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">13. Portuguese Compliance</h2>
          <p>
            We comply with Portuguese data protection regulations enforced by CNPD (Comissão Nacional
            de Proteção de Dados). Portuguese residents have all GDPR rights plus any additional rights
            under Portuguese law.
          </p>
          <p className="mt-2">
            To file a complaint with the Portuguese Data Protection Authority (CNPD): www.cnpd.pt
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">14. Contact Us</h2>
          <p>
            For questions about this Privacy Policy, data rights requests, or our data practices:
          </p>
          <div className="mt-2 bg-gray-50 p-4 rounded-lg">
            <p><strong>Email:</strong> info@deposithunter.com</p>
            <p className="mt-2 text-sm text-gray-600">
              We will respond to all data rights requests within 30 days as required by GDPR.
            </p>
          </div>
        </section>
      </div>
    </LegalLayout>
  );
}
