import { LegalLayout } from './LegalLayout';

export function AccessibilityPage() {
  return (
    <LegalLayout title="Accessibility Statement" lastUpdated="December 9, 2024">
      <div className="space-y-6 text-gray-700">
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Commitment to Accessibility</h2>
          <p>
            We are committed to ensuring that our educational portal is accessible to all Portuguese
            consumers, including those with disabilities. We strive to meet WCAG 2.1 Level AA standards
            and continuously work to improve the accessibility of our educational content.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Accessibility Features</h2>
          <p>
            Our website includes the following accessibility features:
          </p>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Visual Accessibility</h3>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>High contrast text and backgrounds for readability</li>
            <li>Resizable text without loss of content or functionality</li>
            <li>Clear, readable fonts and appropriate font sizes</li>
            <li>Meaningful color contrast ratios (WCAG AA compliant)</li>
            <li>Information not conveyed by color alone</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Keyboard Navigation</h3>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>All functionality available via keyboard</li>
            <li>Logical tab order throughout the site</li>
            <li>Visible focus indicators</li>
            <li>Skip navigation links for screen readers</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Screen Reader Compatibility</h3>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Descriptive alt text for all meaningful images</li>
            <li>Proper heading hierarchy (H1-H6)</li>
            <li>ARIA labels and landmarks</li>
            <li>Semantic HTML5 elements</li>
            <li>Descriptive link text</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Content Clarity</h3>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Clear, simple Portuguese language</li>
            <li>Logical content structure</li>
            <li>Explanation of technical terms</li>
            <li>Consistent navigation and layout</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Responsive Design</h3>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Mobile-friendly design</li>
            <li>Content adapts to different screen sizes</li>
            <li>Touch-friendly interactive elements</li>
            <li>Zoom support up to 200% without horizontal scrolling</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Standards Compliance</h2>
          <p>
            We aim to conform to the following accessibility standards:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Web Content Accessibility Guidelines (WCAG) 2.1 Level AA</li>
            <li>Portuguese accessibility legislation</li>
            <li>European Accessibility Act requirements</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Assistive Technologies</h2>
          <p>
            Our website is designed to work with common assistive technologies, including:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Screen readers (JAWS, NVDA, VoiceOver)</li>
            <li>Screen magnification software</li>
            <li>Speech recognition software</li>
            <li>Keyboard-only navigation</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Known Limitations</h2>
          <p>
            While we strive for full accessibility, some limitations may exist:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Some third-party embedded content may have accessibility limitations</li>
            <li>PDF documents may require accessible versions (contact us for assistance)</li>
            <li>Complex interactive features may require additional assistive technology support</li>
          </ul>
          <p className="mt-2">
            We are actively working to address these limitations and welcome your feedback.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Ongoing Improvements</h2>
          <p>
            We are committed to continuously improving accessibility:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Regular accessibility audits</li>
            <li>Testing with assistive technologies</li>
            <li>Staff training on accessibility best practices</li>
            <li>User feedback integration</li>
            <li>Updates to meet evolving standards</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Browser and Device Support</h2>
          <p>
            Our website is designed to work with:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Modern web browsers (Chrome, Firefox, Safari, Edge)</li>
            <li>Desktop and mobile devices</li>
            <li>Various screen sizes and orientations</li>
            <li>Both touchscreen and mouse/keyboard input</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Feedback and Assistance</h2>
          <p>
            We welcome feedback on the accessibility of our educational portal. If you encounter
            accessibility barriers or need assistance accessing our content:
          </p>

          <div className="mt-4 bg-gray-50 p-4 rounded-lg">
            <p className="font-semibold mb-2">Contact Us:</p>
            <p><strong>Email:</strong> info@deposithunter.com</p>
            <p className="mt-2 text-sm">Please include:</p>
            <ul className="list-disc pl-6 mt-1 text-sm space-y-1">
              <li>Description of the accessibility issue</li>
              <li>Page URL where you encountered the problem</li>
              <li>Assistive technology you were using (if applicable)</li>
              <li>Browser and device information</li>
            </ul>
            <p className="mt-3 text-sm">
              We will respond to accessibility feedback within 5 business days and strive to
              resolve issues as quickly as possible.
            </p>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Alternative Formats</h2>
          <p>
            If you need content in an alternative format (large print, audio, simplified text),
            please contact us at info@deposithunter.com. We will work to provide the information
            in a format that meets your needs.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Formal Complaints</h2>
          <p>
            If you are not satisfied with our response to accessibility concerns, you may file a
            complaint with:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>
              Portuguese accessibility authorities
            </li>
            <li>
              Portal do Consumidor (link available in footer)
            </li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Assessment and Testing</h2>
          <p>
            This accessibility statement was last reviewed on December 9, 2024. We assess our
            website regularly using:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Automated accessibility testing tools</li>
            <li>Manual testing with keyboard navigation</li>
            <li>Screen reader testing</li>
            <li>User feedback and reports</li>
          </ul>
        </section>
      </div>
    </LegalLayout>
  );
}
