import { Header } from '../components/landing/Header';
import { Hero } from '../components/landing/Hero';
import { PlatformCategories } from '../components/landing/PlatformCategories';
import { Reviews } from '../components/landing/Reviews';
import { Education } from '../components/landing/Education';
import { Footer } from '../components/landing/Footer';
import { CookieConsent } from '../components/modals/CookieConsent';
import { PromotionContainer } from '../components/leadgen/PromotionContainer';

export function LandingPage() {
  return (
    <>
      <CookieConsent />

      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4">
          <PromotionContainer currentPage="landing" position="top" />
        </div>
        <Hero />
        <PlatformCategories />
        <div className="max-w-7xl mx-auto px-4">
          <PromotionContainer currentPage="landing" position="middle" />
        </div>
        <Education />
        <Reviews />
        <div className="max-w-7xl mx-auto px-4">
          <PromotionContainer currentPage="landing" position="bottom" />
        </div>
        <Footer />
      </div>
    </>
  );
}
