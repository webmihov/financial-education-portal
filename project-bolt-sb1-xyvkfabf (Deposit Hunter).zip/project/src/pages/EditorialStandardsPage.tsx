import { LegalLayout } from './LegalLayout';

export function EditorialStandardsPage() {
  return (
    <LegalLayout title="Editorial Standards" lastUpdated="December 9, 2024">
      <div className="space-y-6 text-gray-700">
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Commitment to Quality</h2>
          <p>
            As an independent educational portal, we are committed to providing accurate, unbiased, and
            high-quality educational content about financial safety and consumer protection in Portugal.
            These editorial standards guide all our content creation and ensure the integrity of our
            educational mission.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Editorial Independence</h2>
          <p>
            <strong>100% Independent:</strong> We maintain complete editorial independence with no
            commercial partnerships, affiliate relationships, or financial arrangements with any
            companies, financial institutions, or service providers.
          </p>
          <p className="mt-2">
            All educational content is created independently based on factual information, official
            regulatory sources, and consumer protection principles. Our content is never influenced
            by commercial interests.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Accuracy and Verification</h2>
          <p>
            All factual claims and regulatory information in our content must be:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Verified through official Portuguese regulatory authority sources</li>
            <li>Cross-referenced with multiple authoritative sources when possible</li>
            <li>Clearly attributed with sources and references</li>
            <li>Updated regularly to reflect current regulations and information</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Primary Sources</h3>
          <p>We rely on official sources including:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>SRIJ (Serviço de Regulação e Inspeção de Jogos)</li>
            <li>Banco de Portugal</li>
            <li>CMVM (Comissão do Mercado de Valores Mobiliários)</li>
            <li>CNPD (Comissão Nacional de Proteção de Dados)</li>
            <li>Portuguese Consumer Protection Authority</li>
            <li>Official EU regulatory bodies</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Content Review Process</h2>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Initial Creation</h3>
          <p>All new content undergoes:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Research from authoritative sources</li>
            <li>Fact-checking of all claims</li>
            <li>Review for clarity and educational value</li>
            <li>Verification of all links and references</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Regular Updates</h3>
          <p>We review and update content:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Quarterly for regulatory content</li>
            <li>Monthly for consumer protection information</li>
            <li>Immediately when significant regulatory changes occur</li>
            <li>Upon discovery of any inaccuracies</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Transparency and Disclosure</h2>
          <p>
            We maintain complete transparency about:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Our educational mission and independence</li>
            <li>Sources of information and data</li>
            <li>Funding model (educational advertising)</li>
            <li>Tracking technologies used</li>
            <li>Limitations of our educational content</li>
          </ul>

          <p className="mt-4">
            <strong>Important:</strong> All content includes clear disclaimers that we are an educational
            resource and do not provide professional financial or legal advice.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Objectivity Standards</h2>
          <p>
            Our educational content must be:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Factual and evidence-based</li>
            <li>Free from commercial bias or promotional language</li>
            <li>Balanced and fair in presentation</li>
            <li>Clear about uncertainties or limitations</li>
            <li>Focused on consumer education and protection</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Prohibited Content</h3>
          <p>We do not publish content that:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Promotes specific companies or services</li>
            <li>Makes income claims or financial promises</li>
            <li>Uses manipulative or urgent language</li>
            <li>Encourages irresponsible financial behavior</li>
            <li>Misrepresents risks or regulatory requirements</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Consumer Protection Focus</h2>
          <p>
            All content prioritizes consumer education and protection:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Clear explanation of consumer rights</li>
            <li>Information about Portuguese regulatory protections</li>
            <li>Warning about potential risks and red flags</li>
            <li>Guidance on making informed decisions</li>
            <li>Resources for filing complaints and seeking help</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Accessibility and Clarity</h2>
          <p>
            We strive to make educational content accessible to all Portuguese consumers:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Clear, simple Portuguese language</li>
            <li>Explanation of technical terms and jargon</li>
            <li>Logical organization and structure</li>
            <li>Visual aids where helpful</li>
            <li>WCAG accessibility standards compliance</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Corrections Policy</h2>
          <p>
            When errors are identified:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>We correct them promptly</li>
            <li>Significant corrections are noted with date and description</li>
            <li>Users who reported errors are notified</li>
            <li>We analyze how the error occurred to prevent recurrence</li>
          </ul>

          <p className="mt-4">
            To report an error: <a href="mailto:info@deposithunter.com" className="text-educational-accent hover:underline">info@deposithunter.com</a>
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Content Dating</h2>
          <p>
            All content includes:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Publication date</li>
            <li>Last updated date</li>
            <li>Next scheduled review date (for regulatory content)</li>
            <li>Version history for major updates</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">10. User Feedback</h2>
          <p>
            We value feedback from our users and educational community:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>All feedback is reviewed and considered</li>
            <li>Factual corrections are implemented promptly</li>
            <li>Suggestions for content improvements are evaluated</li>
            <li>User concerns about accuracy are investigated thoroughly</li>
          </ul>

          <p className="mt-4">
            Send feedback to: <a href="mailto:info@deposithunter.com" className="text-educational-accent hover:underline">info@deposithunter.com</a>
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact Editorial Team</h2>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p>
              <strong>Email:</strong> info@deposithunter.com
            </p>
            <p className="mt-2 text-sm">
              For questions about our editorial standards, to report inaccuracies, or to provide
              feedback on our educational content.
            </p>
          </div>
        </section>
      </div>
    </LegalLayout>
  );
}
