import { LegalLayout } from './LegalLayout';

export function AffiliateDisclosurePage() {
  return (
    <LegalLayout title="Affiliate Disclosure" lastUpdated="December 14, 2024">
      <div className="space-y-6 text-gray-700">
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Transparency Statement</h2>
          <p>
            This website contains affiliate links and promotional content. We believe in being
            completely transparent about our business relationships and how we generate revenue.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">What Are Affiliate Links?</h2>
          <p>
            Affiliate links are special tracking links that allow us to receive compensation when
            visitors click on them or complete certain actions (like signing up for a service or
            making a deposit). This compensation helps us maintain and operate this educational portal.
          </p>
          <p className="mt-2">
            When you click on an affiliate link and interact with a partner service, we may receive
            a commission. This does not cost you anything extra - the price you pay remains the same.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Affiliate Relationships</h2>
          <p>
            We partner with various licensed online gaming operators, financial services, and other
            platforms featured on this website. These partnerships help fund our operations and allow
            us to provide free educational content.
          </p>
          <p className="mt-2">
            <strong>Important:</strong> All gaming operators featured on this site are licensed by
            SRIJ (Serviço de Regulação e Inspeção de Jogos) and operate legally in Portugal. You can
            verify any operator's license status at{' '}
            <a
              href="https://www.srij.turismodeportugal.pt"
              target="_blank"
              rel="noopener noreferrer"
              className="text-educational-primary hover:underline"
            >
              the official SRIJ website
            </a>.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">How Affiliate Relationships May Influence Content</h2>
          <p>
            We strive to provide useful and accurate educational information. However, you should be
            aware that:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>
              The services and platforms featured on this site may be selected based on commercial
              arrangements and potential compensation
            </li>
            <li>
              The placement, prominence, and frequency with which services appear may be influenced
              by our affiliate relationships
            </li>
            <li>
              We may feature services from partners with whom we have affiliate relationships more
              prominently than those without such relationships
            </li>
            <li>
              Promotional content, banners, and calls-to-action may contain affiliate links
            </li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Your Responsibility</h2>
          <p>
            While we aim to provide helpful information, we encourage you to:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>
              Conduct your own independent research before making any financial decisions
            </li>
            <li>
              Verify information directly with service providers
            </li>
            <li>
              Check official regulatory sources for licensing and compliance information
            </li>
            <li>
              Consult with qualified professionals for personalized financial advice
            </li>
            <li>
              Never gamble with money you cannot afford to lose
            </li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">No Endorsements or Guarantees</h2>
          <p>
            The presence of affiliate links does not constitute an endorsement, recommendation, or
            guarantee of any service. We do not guarantee:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>The quality, safety, or suitability of any service for your specific needs</li>
            <li>That you will have a positive experience with any featured service</li>
            <li>Any specific outcomes, results, or financial returns</li>
            <li>The accuracy or completeness of information provided by third-party services</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Regulatory Compliance</h2>
          <p>
            This website complies with:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Portuguese consumer protection laws</li>
            <li>GDPR data protection regulations</li>
            <li>FTC guidelines on affiliate disclosure (where applicable)</li>
            <li>Google Ads policies on transparency and disclosure</li>
          </ul>
          <p className="mt-2">
            All gaming-related content is restricted to users 18+ and includes appropriate
            responsible gaming warnings and support resources.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Responsible Gaming</h2>
          <p className="font-semibold text-red-800">
            If you choose to engage with gaming services featured on this site, please gamble responsibly:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Only gamble with money you can afford to lose</li>
            <li>Set limits on time and money spent</li>
            <li>Never chase losses</li>
            <li>Seek help if gambling becomes a problem</li>
          </ul>
          <p className="mt-2">
            <strong>Portuguese Helpline:</strong> Linha Vida - 808 200 204
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Questions About Our Affiliate Relationships</h2>
          <p>
            If you have questions about our affiliate relationships or would like more information
            about specific partnerships, please contact us at: info@deposithunter.com
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Updates to This Disclosure</h2>
          <p>
            We may update this affiliate disclosure from time to time to reflect changes in our
            partnerships or business practices. Changes will be effective immediately upon posting
            to this page with an updated revision date.
          </p>
        </section>
      </div>
    </LegalLayout>
  );
}
