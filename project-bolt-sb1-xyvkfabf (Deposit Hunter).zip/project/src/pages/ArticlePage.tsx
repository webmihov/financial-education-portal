import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Header } from '../components/landing/Header';
import { Footer } from '../components/landing/Footer';
import { PromotionContainer } from '../components/leadgen/PromotionContainer';
import { BookOpen, Home, AlertTriangle, Shield, Flag, Users, FileText } from 'lucide-react';

interface Article {
  id: string;
  title_pt: string;
  title_en: string;
  slug: string;
  intro_pt: string;
  intro_en: string;
  how_it_works_pt: string;
  how_it_works_en: string;
  regulatory_status_pt: string;
  regulatory_status_en: string;
  risks_pt: string;
  risks_en: string;
  security_pt: string;
  security_en: string;
  red_flags_pt: string;
  red_flags_en: string;
  consumer_protection_pt: string;
  consumer_protection_en: string;
  disclaimer_pt: string;
  disclaimer_en: string;
  author: string;
  last_reviewed: string;
  category_id: string;
}

interface Category {
  name_pt: string;
  name_en: string;
}

export function ArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const [article, setArticle] = useState<Article | null>(null);
  const [category, setCategory] = useState<Category | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetchArticle();
  }, [slug]);

  async function fetchArticle() {
    setLoading(true);
    setError(false);

    try {
      const { data: articleData, error: articleError } = await supabase
        .from('educational_articles')
        .select('*')
        .eq('slug', slug)
        .eq('is_active', true)
        .maybeSingle();

      if (articleError || !articleData) {
        setError(true);
        setLoading(false);
        return;
      }

      setArticle(articleData);

      if (articleData.category_id) {
        const { data: categoryData } = await supabase
          .from('platform_categories')
          .select('name_pt, name_en')
          .eq('id', articleData.category_id)
          .maybeSingle();

        if (categoryData) {
          setCategory(categoryData);
        }
      }
    } catch (err) {
      setError(true);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <BookOpen className="w-16 h-16 text-educational-primary mx-auto mb-4 animate-pulse" />
            <p className="text-gray-600">A carregar artigo...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  if (error || !article) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center max-w-md mx-auto px-4">
            <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Artigo não encontrado</h1>
            <p className="text-gray-600 mb-6">
              O artigo que procura não existe ou não está disponível.
            </p>
            <Link
              to="/"
              className="inline-flex items-center gap-2 bg-educational-primary text-white px-6 py-3 rounded-lg hover:bg-educational-secondary transition-colors"
            >
              <Home className="w-5 h-5" />
              Voltar à Página Inicial
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-PT', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white border-b">
          <div className="container mx-auto px-4 py-4">
            <nav className="flex items-center gap-2 text-sm text-gray-600">
              <Link to="/" className="hover:text-educational-primary transition-colors">
                Início
              </Link>
              <span>/</span>
              {category && (
                <>
                  <Link to="/#categories" className="hover:text-educational-primary transition-colors">
                    {category.name_pt}
                  </Link>
                  <span>/</span>
                </>
              )}
              <span className="text-gray-900">{article.title_pt}</span>
            </nav>
          </div>
        </div>

        <article className="container mx-auto px-4 py-12 max-w-4xl">
          <header className="mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              {article.title_pt}
            </h1>
            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                <span>{article.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                <span>Última revisão: {formatDate(article.last_reviewed)}</span>
              </div>
            </div>
          </header>

          {article.intro_pt && (
            <section className="mb-10">
              <div className="bg-educational-lightBlue border-l-4 border-educational-primary p-6 rounded-r-lg">
                <p className="text-lg text-gray-800 leading-relaxed whitespace-pre-line">
                  {article.intro_pt}
                </p>
              </div>
            </section>
          )}

          {article.how_it_works_pt && (
            <section className="mb-10">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-educational-primary" />
                Como Funciona
              </h2>
              <div className="bg-white border-2 border-gray-200 rounded-lg p-6">
                <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                  {article.how_it_works_pt}
                </p>
              </div>
            </section>
          )}

          {article.regulatory_status_pt && (
            <section className="mb-10">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Shield className="w-6 h-6 text-educational-primary" />
                Situação Regulatória em Portugal
              </h2>
              <div className="bg-white border-2 border-gray-200 rounded-lg p-6">
                <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                  {article.regulatory_status_pt}
                </p>
              </div>
            </section>
          )}

          <PromotionContainer
            currentPage="article"
            position="middle"
            categoryId={article.category_id}
          />

          {article.risks_pt && (
            <section className="mb-10">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <AlertTriangle className="w-6 h-6 text-red-500" />
                Riscos Associados
              </h2>
              <div className="bg-red-50 border-2 border-red-200 rounded-lg p-6">
                <p className="text-gray-800 leading-relaxed whitespace-pre-line">
                  {article.risks_pt}
                </p>
              </div>
            </section>
          )}

          {article.security_pt && (
            <section className="mb-10">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Shield className="w-6 h-6 text-green-600" />
                Segurança e Proteção
              </h2>
              <div className="bg-green-50 border-2 border-green-200 rounded-lg p-6">
                <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                  {article.security_pt}
                </p>
              </div>
            </section>
          )}

          {article.red_flags_pt && (
            <section className="mb-10">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Flag className="w-6 h-6 text-red-600" />
                Sinais de Alerta (Red Flags)
              </h2>
              <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-6">
                <p className="text-gray-800 leading-relaxed whitespace-pre-line">
                  {article.red_flags_pt}
                </p>
              </div>
            </section>
          )}

          {article.consumer_protection_pt && (
            <section className="mb-10">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Users className="w-6 h-6 text-educational-primary" />
                Proteção do Consumidor
              </h2>
              <div className="bg-white border-2 border-gray-200 rounded-lg p-6">
                <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                  {article.consumer_protection_pt}
                </p>
              </div>
            </section>
          )}

          {article.disclaimer_pt && (
            <section className="mb-10">
              <div className="bg-gray-100 border-l-4 border-gray-500 p-6 rounded-r-lg">
                <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">
                  <strong>Aviso Legal:</strong> {article.disclaimer_pt}
                </p>
              </div>
            </section>
          )}

          <div className="mt-12 pt-8 border-t border-gray-200">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-educational-primary hover:text-educational-secondary font-semibold transition-colors"
            >
              <Home className="w-5 h-5" />
              Voltar à Página Inicial
            </Link>
          </div>
        </article>
      </div>
      <Footer />
    </>
  );
}
