import { LegalLayout } from './LegalLayout';

export function DisclaimerPage() {
  return (
    <LegalLayout title="Disclaimer" lastUpdated="December 4, 2024">
      <div className="space-y-6 text-gray-700">
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">General Disclaimer</h2>
          <p>
            The information provided on this educational portal is for general educational and informational
            purposes only. While we strive for accuracy, we make no representations or warranties of
            any kind about the completeness, accuracy, reliability, suitability, or availability of
            the information, educational content, or related resources contained on the website.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">No Professional Advice</h2>
          <p>
            The content on this website does not constitute professional, financial, or legal advice.
            Users should conduct their own research and consult with appropriate professionals before
            making any decisions based on information found on this platform.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Affiliate Disclosure</h2>
          <p>
            <strong>Important:</strong> This website contains affiliate links and promotional content.
            We may receive compensation when you click on links to partner websites or services.
            This compensation helps support the operation and maintenance of this educational portal.
          </p>
          <p className="mt-2">
            While we strive to provide accurate educational content to help Portuguese consumers
            understand financial safety and consumer rights, the presence of affiliate relationships
            may influence which products, services, or platforms are featured on this site.
          </p>
          <p className="mt-2">
            We encourage you to conduct your own independent research and consult with qualified
            professionals before making any financial decisions.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Third-Party Links</h2>
          <p>
            Our website contains links to third-party websites, including partner services and regulatory
            authorities. Some of these links are affiliate links, meaning we may receive compensation
            when you click on them or make a purchase. We have no control over the nature, content,
            and availability of those sites.
          </p>
          <p className="mt-2">
            Users should carefully review the terms, conditions, and privacy policies of any third-party
            websites before engaging with their services. We recommend conducting independent research
            before making any financial commitments.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Information Accuracy</h2>
          <p>
            While we make every effort to keep information up-to-date and accurate, websites change
            their features, terms, and offerings frequently. We cannot guarantee that all information
            displayed is current at the time of viewing.
          </p>
          <p className="mt-2">
            Users should verify all information directly with the featured websites before making
            any commitments or decisions.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Ratings and Reviews</h2>
          <p>
            Ratings and reviews displayed on this platform may include user-submitted content and
            publicly available information. While we moderate content for authenticity, individual
            experiences may vary.
          </p>
          <p className="mt-2">
            Ratings do not constitute guarantees of service quality and should be considered as one
            factor among many when evaluating websites.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Promotional Content</h2>
          <p>
            This website contains promotional content, advertising, and affiliate links. Interactive
            elements, featured services, and promotional banners may include paid partnerships.
            The services and platforms featured on this site may be selected based on commercial
            arrangements.
          </p>
          <p className="mt-2">
            While we aim to provide useful information, users should understand that commercial
            relationships may influence the content, placement, and prominence of featured services.
            Always conduct independent research before making any decisions.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Limitation of Liability</h2>
          <p>
            In no event shall we be liable for any direct, indirect, incidental, consequential, or
            punitive damages arising from:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Your use of this website or inability to use it</li>
            <li>Any errors or omissions in the content</li>
            <li>Any actions taken based on information provided</li>
            <li>Any interactions with third-party websites linked from our platform</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Age Requirement Disclaimer</h2>
          <p>
            This website is intended for users who are 18 years of age or older. By using this platform,
            you confirm that you meet this age requirement. We are not responsible for verifying the
            age of users beyond the age gate presented upon first visit.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Changes to Disclaimer</h2>
          <p>
            We reserve the right to modify this disclaimer at any time without prior notice. Changes
            will be effective immediately upon posting to the website.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Governing Law</h2>
          <p>
            This disclaimer is governed by the laws of Portugal. Any disputes arising from or related
            to this disclaimer shall be subject to the exclusive jurisdiction of the Portuguese courts.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact</h2>
          <p>
            For questions about this disclaimer, contact us at: info@deposithunter.com
          </p>
        </section>
      </div>
    </LegalLayout>
  );
}
