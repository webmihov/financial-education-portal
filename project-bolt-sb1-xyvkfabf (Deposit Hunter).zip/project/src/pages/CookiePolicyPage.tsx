import { LegalLayout } from './LegalLayout';

export function CookiePolicyPage() {
  return (
    <LegalLayout title="Cookie Policy" lastUpdated="December 9, 2024">
      <div className="space-y-6 text-gray-700">
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">What Are Cookies?</h2>
          <p>
            Cookies are small text files stored on your device when you visit our educational portal.
            They help us provide you with a better experience and allow us to analyze how our educational
            content is used.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">How We Use Cookies</h2>
          <p>
            We use cookies for three main purposes:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Essential website functionality (age verification, preferences)</li>
            <li>Understanding how users interact with our educational content</li>
            <li>Supporting our free educational portal through advertising revenue</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Types of Cookies We Use</h2>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">1. Essential Cookies (Always Active)</h3>
          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <p className="font-semibold mb-2">Purpose:</p>
            <p>Required for basic website functionality. Cannot be disabled.</p>

            <p className="font-semibold mt-3 mb-2">Examples:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li><code>age_verified</code> - Stores age verification status</li>
              <li><code>cookie_consent</code> - Remembers your cookie preferences</li>
              <li><code>session_id</code> - Maintains your session</li>
            </ul>

            <p className="font-semibold mt-3 mb-2">Duration:</p>
            <p>Session cookies or 1 year</p>
          </div>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">2. Analytics Cookies (Optional)</h3>
          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <p className="font-semibold mb-2">Purpose:</p>
            <p>Help us understand how visitors use our educational content.</p>

            <p className="font-semibold mt-3 mb-2">Platform:</p>
            <p>Google Analytics</p>

            <p className="font-semibold mt-3 mb-2">Examples:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li><code>_ga</code> - Distinguishes users</li>
              <li><code>_gid</code> - Distinguishes users</li>
              <li><code>_gat</code> - Throttles request rate</li>
            </ul>

            <p className="font-semibold mt-3 mb-2">Duration:</p>
            <p>2 years (ga), 24 hours (gid), 1 minute (gat)</p>

            <p className="font-semibold mt-3 mb-2">Opt-Out:</p>
            <p>
              Google Analytics Opt-out Browser Add-on (tools.google.com/dlpage/gaoptout)
            </p>
          </div>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">3. Remarketing/Advertising Cookies (Optional)</h3>
          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <p className="font-semibold mb-2">Purpose:</p>
            <p>
              Track visits for remarketing purposes and support our free educational portal through
              advertising revenue.
            </p>

            <p className="font-semibold mt-3 mb-2">Platforms:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Google Ads</li>
              <li>Facebook/Meta (if applicable)</li>
              <li>Other advertising networks</li>
            </ul>

            <p className="font-semibold mt-3 mb-2">Examples:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li><code>_gcl_au</code> - Google Ads conversion tracking</li>
              <li><code>fr</code> - Facebook Pixel (if applicable)</li>
              <li><code>IDE</code> - Google DoubleClick for remarketing</li>
            </ul>

            <p className="font-semibold mt-3 mb-2">Duration:</p>
            <p>90 days to 2 years depending on platform</p>

            <p className="font-semibold mt-3 mb-2">Opt-Out Options:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Google Ads Settings (adssettings.google.com)</li>
              <li>Facebook Ad Preferences (facebook.com/ads/preferences)</li>
              <li>Your Online Choices EU (youronlinechoices.eu)</li>
            </ul>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Managing Your Cookie Preferences</h2>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Through Our Website</h3>
          <p>
            You can manage your cookie preferences through the cookie consent banner that appears on
            your first visit. You can also update your preferences at any time by clearing your cookies
            and revisiting our site.
          </p>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Through Your Browser</h3>
          <p>Most browsers allow you to:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>View and delete cookies</li>
            <li>Block third-party cookies</li>
            <li>Block all cookies (may affect website functionality)</li>
            <li>Clear cookies when closing the browser</li>
          </ul>

          <p className="mt-4">Browser-specific instructions:</p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Google Chrome - Check browser settings</li>
            <li>Mozilla Firefox - Check browser settings</li>
            <li>Safari - Check browser settings</li>
            <li>Microsoft Edge - Check browser settings</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Impact of Disabling Cookies</h2>
          <p>
            <strong>Essential Cookies:</strong> Cannot be disabled as they are required for basic
            website functionality. Blocking these may prevent the site from working properly.
          </p>
          <p className="mt-2">
            <strong>Analytics Cookies:</strong> Disabling these will not affect your use of the site.
            It only prevents us from understanding how our educational content is used.
          </p>
          <p className="mt-2">
            <strong>Remarketing/Advertising Cookies:</strong> Disabling these will not affect your
            access to educational content. You simply won't be tracked for remarketing purposes.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Third-Party Cookies</h2>
          <p>
            Some cookies are set by third-party services we use (Google Analytics, Google Ads, etc.).
            These services have their own privacy policies which can be found on their respective websites.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Updates to Cookie Policy</h2>
          <p>
            We may update this Cookie Policy periodically. Changes will be posted on this page with
            an updated date. Significant changes will be communicated through our cookie consent banner.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact Us</h2>
          <p>
            For questions about our use of cookies:
          </p>
          <div className="mt-2 bg-gray-50 p-4 rounded-lg">
            <p><strong>Email:</strong> info@deposithunter.com</p>
          </div>
        </section>
      </div>
    </LegalLayout>
  );
}
