import { LegalLayout } from './LegalLayout';

export function AboutPage() {
  return (
    <LegalLayout title="About Us" lastUpdated="December 4, 2024">
      <div className="space-y-6 text-gray-700">
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
          <p>
            We are an educational portal dedicated to helping Portuguese consumers understand
            financial safety, consumer rights, and protection when using online services. Our goal is to
            provide educational content about financial literacy, regulatory compliance,
            and consumer protection in Portugal.
          </p>
          <p className="mt-2">
            <strong>Affiliate Disclosure:</strong> This website contains affiliate links and promotional
            content. We may receive compensation when visitors click on partner links. This helps us maintain
            this free educational resource. We strive to provide useful information while being transparent
            about our business relationships.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">What We Do</h2>
          <p>
            We provide educational content about financial safety, consumer protection, and understanding
            regulated services in Portugal. Our educational portal offers:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Educational guides about financial safety and consumer rights</li>
            <li>Information about Portuguese regulatory authorities and consumer protection</li>
            <li>Factual data about officially registered and licensed platforms in Portugal</li>
            <li>Consumer protection resources and educational articles</li>
            <li>Direct links to official Portuguese regulatory bodies: SRIJ, Banco de Portugal, CMVM, CNPD</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Values</h2>
          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Transparency</h3>
          <p>
            We believe in being transparent about our business relationships. This site contains affiliate
            links and promotional content, and we disclose this openly. We aim to provide useful educational
            content while being honest about how we generate revenue.
          </p>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Accuracy</h3>
          <p>
            We strive to provide factual, up-to-date educational information. All regulatory data is verified
            through official Portuguese authority sources.
          </p>

          <h3 className="text-xl font-semibold text-gray-900 mt-4 mb-2">Consumer Protection</h3>
          <p>
            We prioritize consumer safety by providing education about Portuguese regulations, consumer rights,
            and maintaining strict age verification requirements for appropriate content.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">How We Operate</h2>
          <p>
            This educational portal is free for all users. We generate revenue through affiliate partnerships,
            promotional content, and advertising. When you click on partner links or promotional content,
            we may receive compensation that helps us maintain this free resource.
          </p>
          <p className="mt-2">
            We use tracking technologies for analytics, advertising, and affiliate marketing purposes,
            which is fully disclosed in our Privacy Policy. While we aim to provide useful educational
            information, the presence of affiliate relationships may influence which services are featured.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Compliance</h2>
          <p>
            We operate in full compliance with:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>Portuguese consumer protection laws</li>
            <li>GDPR data protection regulations</li>
            <li>Google Ads advertising policies</li>
            <li>Age verification requirements (18+)</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Editorial Standards</h2>
          <p>
            Our educational content follows these editorial standards:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-1">
            <li>All regulatory information is verified through official Portuguese authority sources</li>
            <li>Content is regularly reviewed and updated to maintain accuracy</li>
            <li>Educational materials are fact-checked against official regulatory publications</li>
            <li>Transparent disclosure of affiliate relationships and promotional content</li>
            <li>Clear attribution and sources for all factual claims</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Business Information</h2>
          <p>
            For transparency and compliance with Portuguese regulations, our business details:
          </p>
          <div className="mt-4 bg-gray-50 p-4 rounded-lg space-y-3">
            <div>
              <p className="font-semibold">Legal Entity:</p>
              <p>DepositHunter - Portal Educacional</p>
            </div>

            <div>
              <p className="font-semibold">Business Email:</p>
              <p>info@deposithunter.com</p>
            </div>

            <div>
              <p className="font-semibold">Consumer Complaints:</p>
              <p>
                Portuguese consumers can file complaints through the Livro de Reclamações or the{' '}
                <a
                  href="https://www.consumidor.gov.pt"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-portugal-blue hover:underline"
                >
                  Portal do Consumidor
                </a>
              </p>
            </div>

            <div>
              <p className="font-semibold">Regulatory Information:</p>
              <p>
                For information about Portuguese gaming regulation, visit SRIJ (listed in the footer)
              </p>
            </div>

            <div>
              <p className="font-semibold">Data Protection:</p>
              <p>
                We comply with GDPR and Portuguese data protection laws. For data protection inquiries,
                contact us at info@deposithunter.com
              </p>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact Us</h2>
          <p>
            We welcome your questions, feedback, and suggestions about our educational resources.
          </p>
          <div className="mt-4 bg-gray-50 p-4 rounded-lg">
            <p className="font-semibold">Email:</p>
            <p>info@deposithunter.com</p>

            <p className="font-semibold mt-4">Response Time:</p>
            <p>
              We aim to respond to all inquiries within 48 business hours (Monday-Friday, Portuguese time)
            </p>

            <p className="font-semibold mt-4">For Regulatory Inquiries:</p>
            <p>
              Questions about Portuguese regulations should be directed to the appropriate regulatory
              authority listed in the footer of this website.
            </p>
          </div>
        </section>
      </div>
    </LegalLayout>
  );
}
