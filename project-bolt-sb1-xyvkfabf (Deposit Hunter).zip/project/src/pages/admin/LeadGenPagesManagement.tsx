import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { LeadGenPage, PlatformCategory } from '../../types';
import { Plus, Edit, Trash2, Eye, X, Save, ExternalLink, Wand2, FileText, RefreshCw } from 'lucide-react';
import {
  DEFAULT_HERO_TITLE,
  DEFAULT_HERO_SUBTITLE,
  DEFAULT_BULLETS,
  DEFAULT_PREVIEW_TEXT,
  DEFAULT_COMPLIANCE_NOTE,
  generateSlug,
} from '../../utils/leadGenDefaults';
import { getLeadGenPageStats } from '../../utils/leadGenAnalytics';
import { generateLeadGenPagesFromCategories, generateLeadGenPagesFromArticles } from '../../utils/leadGenGenerator';
import { generatePromotionsForPage } from '../../utils/promotionGenerator';

export function LeadGenPagesManagement() {
  const [pages, setPages] = useState<LeadGenPage[]>([]);
  const [categories, setCategories] = useState<PlatformCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingPage, setEditingPage] = useState<LeadGenPage | null>(null);
  const [stats, setStats] = useState<Record<string, { pageViews: number; clicks: number }>>({});
  const [generating, setGenerating] = useState(false);
  const [generationModalOpen, setGenerationModalOpen] = useState(false);
  const [generationResult, setGenerationResult] = useState<any>(null);
  const [promotionCounts, setPromotionCounts] = useState<Record<string, number>>({});
  const [autoGeneratePromotions, setAutoGeneratePromotions] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [originalIsActive, setOriginalIsActive] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    category_id: '',
    hero_title: DEFAULT_HERO_TITLE,
    hero_subtitle: DEFAULT_HERO_SUBTITLE,
    bullets: DEFAULT_BULLETS,
    preview_text: DEFAULT_PREVIEW_TEXT,
    compliance_note: DEFAULT_COMPLIANCE_NOTE,
    iframe_embed_code: '',
    iframe_version1: '',
    iframe_visibility_mode: 'all' as const,
    display_order: 0,
    is_active: true,
    manual_hide_iframe: false,
  });

  useEffect(() => {
    fetchPages();
    fetchCategories();
  }, []);

  async function fetchPages() {
    try {
      const { data, error } = await supabase
        .from('lead_gen_pages')
        .select('*')
        .order('display_order', { ascending: true });

      if (error) throw error;

      if (data) {
        setPages(data);
        data.forEach(async (page) => {
          const pageStats = await getLeadGenPageStats(page.id);
          setStats((prev) => ({ ...prev, [page.id]: pageStats }));

          const { count } = await supabase
            .from('lead_gen_promotions')
            .select('*', { count: 'exact', head: true })
            .eq('lead_gen_page_id', page.id);

          setPromotionCounts((prev) => ({ ...prev, [page.id]: count || 0 }));
        });
      }
    } catch (error) {
      console.error('Error fetching pages:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchCategories() {
    try {
      const { data, error } = await supabase
        .from('platform_categories')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (error) throw error;
      if (data) setCategories(data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  }

  function openModal(page: LeadGenPage | null = null) {
    if (page) {
      setEditingPage(page);
      setOriginalIsActive(page.is_active);
      setAutoGeneratePromotions(!page.is_active && promotionCounts[page.id] === 0);
      setFormData({
        name: page.name,
        slug: page.slug,
        category_id: page.category_id || '',
        hero_title: page.hero_title,
        hero_subtitle: page.hero_subtitle,
        bullets: page.bullets,
        preview_text: page.preview_text,
        compliance_note: page.compliance_note,
        iframe_embed_code: page.iframe_embed_code,
        iframe_version1: page.iframe_version1 || '',
        iframe_visibility_mode: 'all' as const,
        display_order: page.display_order,
        is_active: page.is_active,
        manual_hide_iframe: page.manual_hide_iframe || false,
      });
    } else {
      setEditingPage(null);
      setOriginalIsActive(true);
      setAutoGeneratePromotions(false);
      setFormData({
        name: '',
        slug: '',
        category_id: '',
        hero_title: DEFAULT_HERO_TITLE,
        hero_subtitle: DEFAULT_HERO_SUBTITLE,
        bullets: DEFAULT_BULLETS,
        preview_text: DEFAULT_PREVIEW_TEXT,
        compliance_note: DEFAULT_COMPLIANCE_NOTE,
        iframe_embed_code: '',
        iframe_version1: '',
        iframe_visibility_mode: 'all' as const,
        display_order: pages.length,
        is_active: true,
        manual_hide_iframe: false,
      });
    }
    setModalOpen(true);
  }

  function closeModal() {
    setModalOpen(false);
    setEditingPage(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const isActivating = editingPage && !originalIsActive && formData.is_active;

    if (isActivating && autoGeneratePromotions) {
      const confirmMessage = 'This will activate the page and create 5 promotions automatically. Continue?';
      if (!confirm(confirmMessage)) {
        return;
      }
    }

    setSubmitting(true);

    try {
      const finalSlug = formData.slug || generateSlug(formData.name);

      if (editingPage) {
        const { error } = await supabase
          .from('lead_gen_pages')
          .update({ ...formData, slug: finalSlug })
          .eq('id', editingPage.id);

        if (error) throw error;

        if (isActivating && autoGeneratePromotions) {
          const existingPromotionCount = promotionCounts[editingPage.id] || 0;

          if (existingPromotionCount === 0) {
            const result = await generatePromotionsForPage(editingPage.id, 5);

            if (result.success) {
              alert(`Page activated successfully. ${result.created} promotions auto-generated.`);
            } else {
              alert(`Page activated but promotion generation failed: ${result.error || 'Unknown error'}. You can generate promotions manually from the Lead Gen Promotions page.`);
            }
          } else {
            alert('Page activated successfully. Existing promotions retained.');
          }
        } else if (isActivating) {
          alert('Page activated successfully.');
        }
      } else {
        const { error } = await supabase
          .from('lead_gen_pages')
          .insert({ ...formData, slug: finalSlug });

        if (error) throw error;
      }

      closeModal();
      fetchPages();
    } catch (error: any) {
      alert('Error saving page: ' + error.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this page? This will also delete all associated promotions.')) {
      return;
    }

    try {
      const { error } = await supabase.from('lead_gen_pages').delete().eq('id', id);

      if (error) throw error;
      fetchPages();
    } catch (error: any) {
      alert('Error deleting page: ' + error.message);
    }
  }

  async function handleGenerateFromCategories() {
    if (!confirm('This will generate Lead Gen Pages for all categories that don\'t already have pages. Continue?')) {
      return;
    }

    setGenerating(true);
    try {
      const result = await generateLeadGenPagesFromCategories();
      setGenerationResult(result);
      setGenerationModalOpen(true);
      fetchPages();
    } catch (error: any) {
      alert('Error generating pages: ' + error.message);
    } finally {
      setGenerating(false);
    }
  }

  async function handleGenerateFromArticles() {
    if (!confirm('This will generate Lead Gen Pages from articles that don\'t already have category pages. Continue?')) {
      return;
    }

    setGenerating(true);
    try {
      const result = await generateLeadGenPagesFromArticles();
      setGenerationResult(result);
      setGenerationModalOpen(true);
      fetchPages();
    } catch (error: any) {
      alert('Error generating pages: ' + error.message);
    } finally {
      setGenerating(false);
    }
  }

  if (loading) {
    return <div className="text-center py-12">Loading...</div>;
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Lead Gen Pages</h1>
          <p className="text-gray-600 mt-1">
            Manage internal landing pages for lead generation - Google Ads compliant
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleGenerateFromCategories}
            disabled={generating}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition disabled:opacity-50"
          >
            {generating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
            From Categories
          </button>
          <button
            onClick={handleGenerateFromArticles}
            disabled={generating}
            className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition disabled:opacity-50"
          >
            {generating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <FileText className="w-5 h-5" />}
            From Articles
          </button>
          <button
            onClick={() => openModal()}
            className="flex items-center gap-2 bg-educational-primary text-white px-4 py-2 rounded-lg hover:bg-educational-secondary transition"
          >
            <Plus className="w-5 h-5" />
            New Page
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Slug</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Views</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Promotions</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {pages.map((page) => {
              const category = categories.find((c) => c.id === page.category_id);
              const pageStats = stats[page.id];
              const promoCount = promotionCounts[page.id] || 0;

              return (
                <tr key={page.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{page.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <code className="text-xs bg-gray-100 px-2 py-1 rounded">/lp/{page.slug}</code>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {category?.name_pt || 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {pageStats ? pageStats.pageViews : 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        promoCount > 0 ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {promoCount > 0 ? `${promoCount} promos` : 'No promos'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        page.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {page.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-2">
                      <a
                        href={`/lp/${page.slug}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Eye className="w-4 h-4" />
                      </a>
                      <button
                        onClick={() => openModal(page)}
                        className="text-educational-primary hover:text-educational-secondary"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(page.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {modalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-lg w-full max-w-4xl my-8">
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-2xl font-bold">{editingPage ? 'Edit Page' : 'New Page'}</h2>
              <button onClick={closeModal} className="text-gray-500 hover:text-gray-700">
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Slug (auto-generated if empty)
                  </label>
                  <input
                    type="text"
                    value={formData.slug}
                    onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    placeholder="depositos-bancarios-guia"
                  />
                  {formData.slug && (
                    <p className="text-xs text-gray-500 mt-1">URL: /lp/{formData.slug}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select
                  value={formData.category_id}
                  onChange={(e) => setFormData({ ...formData, category_id: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  <option value="">None</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name_pt}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Hero Title</label>
                <input
                  type="text"
                  value={formData.hero_title}
                  onChange={(e) => setFormData({ ...formData, hero_title: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Hero Subtitle</label>
                <textarea
                  value={formData.hero_subtitle}
                  onChange={(e) => setFormData({ ...formData, hero_subtitle: e.target.value })}
                  rows={2}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Bullets (one per line)
                </label>
                <textarea
                  value={formData.bullets.join('\n')}
                  onChange={(e) =>
                    setFormData({ ...formData, bullets: e.target.value.split('\n').filter(Boolean) })
                  }
                  rows={4}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Preview Text</label>
                <textarea
                  value={formData.preview_text}
                  onChange={(e) => setFormData({ ...formData, preview_text: e.target.value })}
                  rows={3}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div className="border-t border-gray-200 pt-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Iframe Embed</h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Iframe Embed Code
                    </label>
                    <textarea
                      value={formData.iframe_version1}
                      onChange={(e) => setFormData({ ...formData, iframe_version1: e.target.value })}
                      rows={4}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 font-mono text-sm"
                      placeholder="<iframe src='...'></iframe>"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      This embed code will be shown to all visitors
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Compliance Note</label>
                <textarea
                  value={formData.compliance_note}
                  onChange={(e) => setFormData({ ...formData, compliance_note: e.target.value })}
                  rows={3}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Display Order</label>
                  <input
                    type="number"
                    value={formData.display_order}
                    onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  />
                </div>

                <div className="space-y-3 pt-7">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="is_active"
                      checked={formData.is_active}
                      onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                      className="w-4 h-4"
                    />
                    <label htmlFor="is_active" className="text-sm font-medium text-gray-700">
                      Active
                    </label>
                  </div>

                  <div className="flex items-start gap-3 bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                    <input
                      type="checkbox"
                      id="manual_hide_iframe"
                      checked={formData.manual_hide_iframe}
                      onChange={(e) => setFormData({ ...formData, manual_hide_iframe: e.target.checked })}
                      className="w-4 h-4 mt-0.5"
                    />
                    <div className="flex-1">
                      <label htmlFor="manual_hide_iframe" className="text-sm font-medium text-gray-700 cursor-pointer">
                        Manual Bot Mode (Hide iframe from all visitors)
                      </label>
                      <p className="text-xs text-gray-600 mt-1">
                        When enabled, the promotional iframe will be hidden from ALL visitors. Useful for testing or during maintenance.
                      </p>
                    </div>
                  </div>

                  {editingPage && !originalIsActive && formData.is_active && (
                    <div className="flex items-start gap-3 bg-blue-50 p-3 rounded-lg">
                      <input
                        type="checkbox"
                        id="auto_generate"
                        checked={autoGeneratePromotions}
                        onChange={(e) => setAutoGeneratePromotions(e.target.checked)}
                        className="w-4 h-4 mt-0.5"
                      />
                      <div className="flex-1">
                        <label htmlFor="auto_generate" className="text-sm font-medium text-gray-700 cursor-pointer">
                          Auto-generate promotions when activating
                        </label>
                        <p className="text-xs text-gray-600 mt-1">
                          Creates 5 promotions (50% inline cards, 30% banners, 20% text ads)
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Google Ads Compliance:</strong> All pages are internal to your domain (
                  <code>/lp/:slug</code>). Promotions can only link to these internal pages.
                </p>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={closeModal}
                  disabled={submitting}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center gap-2 bg-educational-primary text-white px-4 py-2 rounded-lg hover:bg-educational-secondary disabled:opacity-50"
                >
                  {submitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      {editingPage && !originalIsActive && formData.is_active && autoGeneratePromotions
                        ? 'Activating & Generating...'
                        : 'Saving...'}
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      Save Page
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {generationModalOpen && generationResult && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-2xl max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-2xl font-bold">Generation Results</h2>
              <button
                onClick={() => setGenerationModalOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-green-50 p-4 rounded-lg text-center">
                  <div className="text-3xl font-bold text-green-600">{generationResult.created}</div>
                  <div className="text-sm text-gray-600">Created</div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg text-center">
                  <div className="text-3xl font-bold text-yellow-600">{generationResult.skipped}</div>
                  <div className="text-sm text-gray-600">Skipped</div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg text-center">
                  <div className="text-3xl font-bold text-red-600">{generationResult.errors.length}</div>
                  <div className="text-sm text-gray-600">Errors</div>
                </div>
              </div>

              {generationResult.details.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold text-gray-900">Details:</h3>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {generationResult.details.map((detail: any, idx: number) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-lg border ${
                          detail.status === 'created'
                            ? 'bg-green-50 border-green-200'
                            : detail.status === 'skipped'
                            ? 'bg-yellow-50 border-yellow-200'
                            : 'bg-red-50 border-red-200'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="font-medium">{detail.name}</div>
                            {detail.reason && (
                              <div className="text-sm text-gray-600 mt-1">{detail.reason}</div>
                            )}
                          </div>
                          <span
                            className={`px-2 py-1 text-xs rounded-full ${
                              detail.status === 'created'
                                ? 'bg-green-100 text-green-800'
                                : detail.status === 'skipped'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {detail.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {generationResult.errors.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h3 className="font-semibold text-red-900 mb-2">Errors:</h3>
                  <ul className="list-disc list-inside text-sm text-red-800 space-y-1">
                    {generationResult.errors.map((error: string, idx: number) => (
                      <li key={idx}>{error}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Note:</strong> All generated pages are set to inactive by default. Review each page
                  and add iframe embed codes if needed before activating.
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-3 p-6 border-t">
              <button
                onClick={() => setGenerationModalOpen(false)}
                className="px-4 py-2 bg-educational-primary text-white rounded-lg hover:bg-educational-secondary"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
