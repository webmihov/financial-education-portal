import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { PlatformCategory } from '../../types';
import { Plus, Edit, Trash2, Eye, EyeOff, Save, X } from 'lucide-react';

interface CategoryFormData {
  name_pt: string;
  name_en: string;
  slug: string;
  description_pt: string;
  description_en: string;
  icon_name: string;
  regulatory_focus: string;
  display_order: number;
}

export function PlatformCategoriesManagement() {
  const [categories, setCategories] = useState<PlatformCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<CategoryFormData>({
    name_pt: '',
    name_en: '',
    slug: '',
    description_pt: '',
    description_en: '',
    icon_name: 'folder',
    regulatory_focus: '',
    display_order: 0,
  });

  const iconOptions = [
    'building', 'shopping-cart', 'gamepad-2', 'ticket', 'bitcoin',
    'briefcase', 'tv', 'folder', 'book-open', 'credit-card', 'smartphone'
  ];

  const regulatoryBodies = [
    'SRIJ', 'Banco de Portugal', 'CMVM', 'ASAE', 'Autoridade Tributária', 'Consumer Protection'
  ];

  useEffect(() => {
    fetchCategories();
  }, []);

  async function fetchCategories() {
    setLoading(true);
    const { data } = await supabase
      .from('platform_categories')
      .select('*')
      .order('display_order');

    if (data) {
      setCategories(data);
    }
    setLoading(false);
  }

  function openAddModal() {
    setEditingId(null);
    setFormData({
      name_pt: '',
      name_en: '',
      slug: '',
      description_pt: '',
      description_en: '',
      icon_name: 'folder',
      regulatory_focus: '',
      display_order: categories.length + 1,
    });
    setShowModal(true);
  }

  function openEditModal(category: PlatformCategory) {
    setEditingId(category.id);
    setFormData({
      name_pt: category.name_pt,
      name_en: category.name_en,
      slug: category.slug,
      description_pt: category.description_pt,
      description_en: category.description_en,
      icon_name: category.icon_name,
      regulatory_focus: category.regulatory_focus,
      display_order: category.display_order,
    });
    setShowModal(true);
  }

  function generateSlug(text: string) {
    return text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }

  function handleNameChange(value: string, lang: 'pt' | 'en') {
    const key = lang === 'pt' ? 'name_pt' : 'name_en';
    setFormData({ ...formData, [key]: value });
    if (!editingId && lang === 'en') {
      setFormData(prev => ({ ...prev, slug: generateSlug(value) }));
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (editingId) {
      await supabase
        .from('platform_categories')
        .update(formData)
        .eq('id', editingId);
    } else {
      await supabase.from('platform_categories').insert([formData]);
    }

    setShowModal(false);
    fetchCategories();
  }

  async function toggleActive(id: string, currentStatus: boolean) {
    await supabase
      .from('platform_categories')
      .update({ is_active: !currentStatus })
      .eq('id', id);
    fetchCategories();
  }

  async function deleteCategory(id: string) {
    if (confirm('Are you sure you want to delete this category? This may affect associated articles.')) {
      await supabase.from('platform_categories').delete().eq('id', id);
      fetchCategories();
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Platform Categories</h1>
          <p className="text-gray-600">Manage educational content categories for different service types</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center gap-2 px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
        >
          <Plus className="w-5 h-5" />
          Add Category
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-educational-primary mx-auto"></div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Order
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Category
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Slug
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Regulatory Focus
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {categories.map((category) => (
                <tr key={category.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {category.display_order}
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-semibold text-gray-900">{category.name_pt}</div>
                    <div className="text-sm text-gray-500">{category.name_en}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <code className="text-xs bg-gray-100 px-2 py-1 rounded">{category.slug}</code>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-700">{category.regulatory_focus || '-'}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {category.is_active ? (
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                        Active
                      </span>
                    ) : (
                      <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-semibold">
                        Inactive
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => toggleActive(category.id, category.is_active)}
                        className="text-educational-primary hover:text-educational-secondary"
                        title={category.is_active ? 'Deactivate' : 'Activate'}
                      >
                        {category.is_active ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                      <button
                        onClick={() => openEditModal(category)}
                        className="text-educational-secondary hover:text-educational-primary"
                      >
                        <Edit className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => deleteCategory(category.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b sticky top-0 bg-white">
              <h2 className="text-2xl font-bold text-gray-900">
                {editingId ? 'Edit Category' : 'Add New Category'}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name (Portuguese) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name_pt}
                    onChange={(e) => handleNameChange(e.target.value, 'pt')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="e.g., Plataformas de Jogos"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name (English) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name_en}
                    onChange={(e) => handleNameChange(e.target.value, 'en')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="e.g., Gaming Platforms"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Slug *
                </label>
                <input
                  type="text"
                  required
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  placeholder="e.g., gaming-platforms"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description (Portuguese)
                  </label>
                  <textarea
                    value={formData.description_pt}
                    onChange={(e) => setFormData({ ...formData, description_pt: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="Descrição breve da categoria"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description (English)
                  </label>
                  <textarea
                    value={formData.description_en}
                    onChange={(e) => setFormData({ ...formData, description_en: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="Brief category description"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Icon
                  </label>
                  <select
                    value={formData.icon_name}
                    onChange={(e) => setFormData({ ...formData, icon_name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  >
                    {iconOptions.map((icon) => (
                      <option key={icon} value={icon}>{icon}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Regulatory Focus
                  </label>
                  <select
                    value={formData.regulatory_focus}
                    onChange={(e) => setFormData({ ...formData, regulatory_focus: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  >
                    <option value="">None</option>
                    {regulatoryBodies.map((body) => (
                      <option key={body} value={body}>{body}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Display Order
                  </label>
                  <input
                    type="number"
                    value={formData.display_order}
                    onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-lg font-semibold transition"
                >
                  <X className="w-5 h-5 inline mr-2" />
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
                >
                  <Save className="w-5 h-5 inline mr-2" />
                  {editingId ? 'Update' : 'Create'} Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
