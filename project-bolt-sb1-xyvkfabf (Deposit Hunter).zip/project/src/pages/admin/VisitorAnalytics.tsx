import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { LeadGenPage } from '../../types';
import { Users, Eye, EyeOff, Bot, User, HelpCircle, TrendingUp, RefreshCw } from 'lucide-react';

interface VisitorStats {
  page_id: string;
  page_slug: string;
  page_title: string;
  total_visitors: number;
  human_visitors: number;
  bot_visitors: number;
  uncertain_visitors: number;
  saw_iframe_count: number;
  hidden_iframe_count: number;
  human_saw_iframe: number;
  bot_saw_iframe: number;
}

export function VisitorAnalytics() {
  const [stats, setStats] = useState<VisitorStats[]>([]);
  const [pages, setPages] = useState<LeadGenPage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPageId, setSelectedPageId] = useState<string>('all');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchData();
  }, [selectedPageId]);

  async function fetchData() {
    try {
      setRefreshing(true);

      const { data: pagesData } = await supabase
        .from('lead_gen_pages')
        .select('*')
        .order('name');

      if (pagesData) {
        setPages(pagesData);
      }

      const { data: statsData, error } = await supabase.rpc('get_visitor_statistics', {
        page_id_param: selectedPageId === 'all' ? null : selectedPageId,
      });

      if (error) throw error;

      if (statsData) {
        setStats(statsData);
      }
    } catch (error) {
      console.error('Error fetching visitor analytics:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  const totalStats = stats.reduce(
    (acc, stat) => ({
      total_visitors: acc.total_visitors + stat.total_visitors,
      human_visitors: acc.human_visitors + stat.human_visitors,
      bot_visitors: acc.bot_visitors + stat.bot_visitors,
      uncertain_visitors: acc.uncertain_visitors + stat.uncertain_visitors,
      saw_iframe_count: acc.saw_iframe_count + stat.saw_iframe_count,
      hidden_iframe_count: acc.hidden_iframe_count + stat.hidden_iframe_count,
    }),
    {
      total_visitors: 0,
      human_visitors: 0,
      bot_visitors: 0,
      uncertain_visitors: 0,
      saw_iframe_count: 0,
      hidden_iframe_count: 0,
    }
  );

  function calculatePercentage(value: number, total: number): string {
    if (total === 0) return '0';
    return ((value / total) * 100).toFixed(1);
  }

  if (loading) {
    return <div className="text-center py-12">Loading...</div>;
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Visitor Analytics</h1>
          <p className="text-gray-600 mt-1">
            Track visitor types and iframe visibility across lead gen pages
          </p>
        </div>
        <div className="flex gap-3">
          <select
            value={selectedPageId}
            onChange={(e) => setSelectedPageId(e.target.value)}
            className="border border-gray-300 rounded-lg px-4 py-2"
          >
            <option value="all">All Pages</option>
            {pages.map((page) => (
              <option key={page.id} value={page.id}>
                {page.name}
              </option>
            ))}
          </select>
          <button
            onClick={fetchData}
            disabled={refreshing}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-2">
            <Users className="w-8 h-8 text-blue-600" />
            <span className="text-sm text-gray-500">Total</span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{totalStats.total_visitors}</div>
          <p className="text-sm text-gray-600 mt-1">Total Visitors</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-2">
            <User className="w-8 h-8 text-green-600" />
            <span className="text-sm text-gray-500">
              {calculatePercentage(totalStats.human_visitors, totalStats.total_visitors)}%
            </span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{totalStats.human_visitors}</div>
          <p className="text-sm text-gray-600 mt-1">Human Visitors</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-2">
            <Bot className="w-8 h-8 text-red-600" />
            <span className="text-sm text-gray-500">
              {calculatePercentage(totalStats.bot_visitors, totalStats.total_visitors)}%
            </span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{totalStats.bot_visitors}</div>
          <p className="text-sm text-gray-600 mt-1">Bot Visitors</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-2">
            <HelpCircle className="w-8 h-8 text-yellow-600" />
            <span className="text-sm text-gray-500">
              {calculatePercentage(totalStats.uncertain_visitors, totalStats.total_visitors)}%
            </span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{totalStats.uncertain_visitors}</div>
          <p className="text-sm text-gray-600 mt-1">Uncertain</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Iframe Visibility
          </h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Saw Iframe</span>
                <span className="text-sm font-semibold text-gray-900">
                  {totalStats.saw_iframe_count} (
                  {calculatePercentage(totalStats.saw_iframe_count, totalStats.total_visitors)}%)
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-600 h-2 rounded-full"
                  style={{
                    width: `${calculatePercentage(totalStats.saw_iframe_count, totalStats.total_visitors)}%`,
                  }}
                ></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Hidden Iframe</span>
                <span className="text-sm font-semibold text-gray-900">
                  {totalStats.hidden_iframe_count} (
                  {calculatePercentage(totalStats.hidden_iframe_count, totalStats.total_visitors)}%)
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-red-600 h-2 rounded-full"
                  style={{
                    width: `${calculatePercentage(totalStats.hidden_iframe_count, totalStats.total_visitors)}%`,
                  }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Visitor Distribution
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <div className="flex items-center gap-2">
                <User className="w-5 h-5 text-green-600" />
                <span className="text-sm font-medium text-gray-700">Humans</span>
              </div>
              <span className="text-sm font-semibold text-gray-900">
                {calculatePercentage(totalStats.human_visitors, totalStats.total_visitors)}%
              </span>
            </div>
            <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-red-600" />
                <span className="text-sm font-medium text-gray-700">Bots</span>
              </div>
              <span className="text-sm font-semibold text-gray-900">
                {calculatePercentage(totalStats.bot_visitors, totalStats.total_visitors)}%
              </span>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-yellow-600" />
                <span className="text-sm font-medium text-gray-700">Uncertain</span>
              </div>
              <span className="text-sm font-semibold text-gray-900">
                {calculatePercentage(totalStats.uncertain_visitors, totalStats.total_visitors)}%
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Per-Page Statistics</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Page</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Humans</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Bots</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Uncertain</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Saw Iframe</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hidden</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {stats.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-8 text-center text-gray-500">
                    No visitor data available yet
                  </td>
                </tr>
              ) : (
                stats.map((stat) => (
                  <tr key={stat.page_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-gray-900">{stat.page_title}</div>
                      <div className="text-xs text-gray-500">/lp/{stat.page_slug}</div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">{stat.total_visitors}</td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-gray-900">{stat.human_visitors}</span>
                      <span className="text-xs text-gray-500 ml-1">
                        ({calculatePercentage(stat.human_visitors, stat.total_visitors)}%)
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-gray-900">{stat.bot_visitors}</span>
                      <span className="text-xs text-gray-500 ml-1">
                        ({calculatePercentage(stat.bot_visitors, stat.total_visitors)}%)
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-gray-900">{stat.uncertain_visitors}</span>
                      <span className="text-xs text-gray-500 ml-1">
                        ({calculatePercentage(stat.uncertain_visitors, stat.total_visitors)}%)
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Eye className="w-4 h-4 text-green-600" />
                        <span className="text-sm text-gray-900">{stat.saw_iframe_count}</span>
                        <span className="text-xs text-gray-500">
                          ({calculatePercentage(stat.saw_iframe_count, stat.total_visitors)}%)
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <EyeOff className="w-4 h-4 text-red-600" />
                        <span className="text-sm text-gray-900">{stat.hidden_iframe_count}</span>
                        <span className="text-xs text-gray-500">
                          ({calculatePercentage(stat.hidden_iframe_count, stat.total_visitors)}%)
                        </span>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-800">
          <strong>Note:</strong> Visitor classification is based on user agent analysis and is for analytics purposes only.
          The manual bot mode toggle in Lead Gen Pages Management allows you to hide iframes from all visitors when needed.
        </p>
      </div>
    </div>
  );
}
