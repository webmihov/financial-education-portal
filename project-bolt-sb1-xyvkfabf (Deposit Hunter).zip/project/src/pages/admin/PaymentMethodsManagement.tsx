import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { PaymentMethodPT } from '../../types';
import { Plus, Edit, Trash2, Eye, EyeOff, Save, X, CreditCard } from 'lucide-react';

interface MethodFormData {
  name_pt: string;
  name_en: string;
  method_type: string;
  description_pt: string;
  description_en: string;
  pros_pt: string[];
  pros_en: string[];
  cons_pt: string[];
  cons_en: string[];
  security_level: string;
  typical_fees_pt: string;
  typical_fees_en: string;
  processing_time_pt: string;
  processing_time_en: string;
  icon_name: string;
  display_order: number;
}

export function PaymentMethodsManagement() {
  const [methods, setMethods] = useState<PaymentMethodPT[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newPro, setNewPro] = useState({ pt: '', en: '' });
  const [newCon, setNewCon] = useState({ pt: '', en: '' });
  const [formData, setFormData] = useState<MethodFormData>({
    name_pt: '',
    name_en: '',
    method_type: 'card',
    description_pt: '',
    description_en: '',
    pros_pt: [],
    pros_en: [],
    cons_pt: [],
    cons_en: [],
    security_level: 'médio',
    typical_fees_pt: '',
    typical_fees_en: '',
    processing_time_pt: '',
    processing_time_en: '',
    icon_name: 'credit-card',
    display_order: 0,
  });

  const methodTypes = [
    'card', 'bank_transfer', 'mobile_payment', 'cash_payment', 'e_wallet', 'cryptocurrency'
  ];

  const securityLevels = ['alto', 'médio', 'baixo'];

  useEffect(() => {
    fetchMethods();
  }, []);

  async function fetchMethods() {
    setLoading(true);
    const { data } = await supabase
      .from('payment_methods_pt')
      .select('*')
      .order('display_order');

    if (data) {
      setMethods(data);
    }
    setLoading(false);
  }

  function openAddModal() {
    setEditingId(null);
    setFormData({
      name_pt: '',
      name_en: '',
      method_type: 'card',
      description_pt: '',
      description_en: '',
      pros_pt: [],
      pros_en: [],
      cons_pt: [],
      cons_en: [],
      security_level: 'médio',
      typical_fees_pt: '',
      typical_fees_en: '',
      processing_time_pt: '',
      processing_time_en: '',
      icon_name: 'credit-card',
      display_order: methods.length + 1,
    });
    setShowModal(true);
  }

  function openEditModal(method: PaymentMethodPT) {
    setEditingId(method.id);
    setFormData({
      name_pt: method.name_pt,
      name_en: method.name_en,
      method_type: method.method_type,
      description_pt: method.description_pt,
      description_en: method.description_en,
      pros_pt: method.pros_pt,
      pros_en: method.pros_en,
      cons_pt: method.cons_pt,
      cons_en: method.cons_en,
      security_level: method.security_level,
      typical_fees_pt: method.typical_fees_pt,
      typical_fees_en: method.typical_fees_en,
      processing_time_pt: method.processing_time_pt,
      processing_time_en: method.processing_time_en,
      icon_name: method.icon_name,
      display_order: method.display_order,
    });
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (editingId) {
      await supabase
        .from('payment_methods_pt')
        .update(formData)
        .eq('id', editingId);
    } else {
      await supabase.from('payment_methods_pt').insert([formData]);
    }

    setShowModal(false);
    fetchMethods();
  }

  function addPro() {
    if (newPro.pt.trim() && newPro.en.trim()) {
      setFormData({
        ...formData,
        pros_pt: [...formData.pros_pt, newPro.pt.trim()],
        pros_en: [...formData.pros_en, newPro.en.trim()]
      });
      setNewPro({ pt: '', en: '' });
    }
  }

  function addCon() {
    if (newCon.pt.trim() && newCon.en.trim()) {
      setFormData({
        ...formData,
        cons_pt: [...formData.cons_pt, newCon.pt.trim()],
        cons_en: [...formData.cons_en, newCon.en.trim()]
      });
      setNewCon({ pt: '', en: '' });
    }
  }

  function removePro(index: number) {
    setFormData({
      ...formData,
      pros_pt: formData.pros_pt.filter((_, i) => i !== index),
      pros_en: formData.pros_en.filter((_, i) => i !== index)
    });
  }

  function removeCon(index: number) {
    setFormData({
      ...formData,
      cons_pt: formData.cons_pt.filter((_, i) => i !== index),
      cons_en: formData.cons_en.filter((_, i) => i !== index)
    });
  }

  async function toggleActive(id: string, currentStatus: boolean) {
    await supabase
      .from('payment_methods_pt')
      .update({ is_active: !currentStatus })
      .eq('id', id);
    fetchMethods();
  }

  async function deleteMethod(id: string) {
    if (confirm('Are you sure you want to delete this payment method?')) {
      await supabase.from('payment_methods_pt').delete().eq('id', id);
      fetchMethods();
    }
  }

  function getSecurityColor(level: string) {
    switch (level) {
      case 'alto': return 'bg-green-100 text-green-800';
      case 'médio': return 'bg-yellow-100 text-yellow-800';
      case 'baixo': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Payment Methods</h1>
          <p className="text-gray-600">Manage Portuguese payment methods and their characteristics</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center gap-2 px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
        >
          <Plus className="w-5 h-5" />
          Add Payment Method
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-educational-primary mx-auto"></div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {methods.map((method) => (
            <div key={method.id} className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-educational-lightBlue rounded-lg flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-educational-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{method.name_pt}</h3>
                    <p className="text-xs text-gray-500">{method.name_en}</p>
                  </div>
                </div>
                {method.is_active ? (
                  <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                    Active
                  </span>
                ) : (
                  <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-semibold">
                    Inactive
                  </span>
                )}
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Type:</span>
                  <span className="font-semibold text-gray-900">{method.method_type}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Security:</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getSecurityColor(method.security_level)}`}>
                    {method.security_level}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Fees:</span>
                  <span className="font-semibold text-gray-900">{method.typical_fees_pt}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Processing:</span>
                  <span className="font-semibold text-gray-900">{method.processing_time_pt}</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t">
                <button
                  onClick={() => toggleActive(method.id, method.is_active)}
                  className="text-educational-primary hover:text-educational-secondary"
                  title={method.is_active ? 'Deactivate' : 'Activate'}
                >
                  {method.is_active ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
                <button
                  onClick={() => openEditModal(method)}
                  className="text-educational-secondary hover:text-educational-primary"
                >
                  <Edit className="w-5 h-5" />
                </button>
                <button
                  onClick={() => deleteMethod(method.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}

          {methods.length === 0 && (
            <div className="col-span-full text-center py-12 bg-white rounded-xl">
              <p className="text-gray-500">No payment methods found</p>
            </div>
          )}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full my-8">
            <div className="p-6 border-b sticky top-0 bg-white z-10">
              <h2 className="text-2xl font-bold text-gray-900">
                {editingId ? 'Edit Payment Method' : 'Add New Payment Method'}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name (Portuguese) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name_pt}
                    onChange={(e) => setFormData({ ...formData, name_pt: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name (English) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name_en}
                    onChange={(e) => setFormData({ ...formData, name_en: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Method Type *
                  </label>
                  <select
                    value={formData.method_type}
                    onChange={(e) => setFormData({ ...formData, method_type: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  >
                    {methodTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Security Level *
                  </label>
                  <select
                    value={formData.security_level}
                    onChange={(e) => setFormData({ ...formData, security_level: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  >
                    {securityLevels.map(level => (
                      <option key={level} value={level}>{level}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Typical Fees (Portuguese)
                  </label>
                  <input
                    type="text"
                    value={formData.typical_fees_pt}
                    onChange={(e) => setFormData({ ...formData, typical_fees_pt: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="e.g., €0-€5"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Typical Fees (English)
                  </label>
                  <input
                    type="text"
                    value={formData.typical_fees_en}
                    onChange={(e) => setFormData({ ...formData, typical_fees_en: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="e.g., €0-€5"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Processing Time (Portuguese)
                  </label>
                  <input
                    type="text"
                    value={formData.processing_time_pt}
                    onChange={(e) => setFormData({ ...formData, processing_time_pt: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="e.g., Instantâneo"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Processing Time (English)
                  </label>
                  <input
                    type="text"
                    value={formData.processing_time_en}
                    onChange={(e) => setFormData({ ...formData, processing_time_en: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="e.g., Instant"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pros (Add bilingual pairs)
                </label>
                <div className="grid md:grid-cols-2 gap-2 mb-2">
                  <input
                    type="text"
                    value={newPro.pt}
                    onChange={(e) => setNewPro({ ...newPro, pt: e.target.value })}
                    className="px-3 py-2 border border-gray-300 rounded-lg"
                    placeholder="Portuguese pro"
                  />
                  <input
                    type="text"
                    value={newPro.en}
                    onChange={(e) => setNewPro({ ...newPro, en: e.target.value })}
                    className="px-3 py-2 border border-gray-300 rounded-lg"
                    placeholder="English pro"
                  />
                </div>
                <button
                  type="button"
                  onClick={addPro}
                  className="mb-2 px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg text-sm"
                >
                  Add Pro
                </button>
                <div className="space-y-1">
                  {formData.pros_pt.map((_, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm bg-green-50 p-2 rounded">
                      <span className="flex-1">{formData.pros_pt[idx]}</span>
                      <span className="flex-1 text-gray-600">{formData.pros_en[idx]}</span>
                      <button
                        type="button"
                        onClick={() => removePro(idx)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cons (Add bilingual pairs)
                </label>
                <div className="grid md:grid-cols-2 gap-2 mb-2">
                  <input
                    type="text"
                    value={newCon.pt}
                    onChange={(e) => setNewCon({ ...newCon, pt: e.target.value })}
                    className="px-3 py-2 border border-gray-300 rounded-lg"
                    placeholder="Portuguese con"
                  />
                  <input
                    type="text"
                    value={newCon.en}
                    onChange={(e) => setNewCon({ ...newCon, en: e.target.value })}
                    className="px-3 py-2 border border-gray-300 rounded-lg"
                    placeholder="English con"
                  />
                </div>
                <button
                  type="button"
                  onClick={addCon}
                  className="mb-2 px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg text-sm"
                >
                  Add Con
                </button>
                <div className="space-y-1">
                  {formData.cons_pt.map((_, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm bg-red-50 p-2 rounded">
                      <span className="flex-1">{formData.cons_pt[idx]}</span>
                      <span className="flex-1 text-gray-600">{formData.cons_en[idx]}</span>
                      <button
                        type="button"
                        onClick={() => removeCon(idx)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-lg font-semibold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
                >
                  <Save className="w-5 h-5" />
                  {editingId ? 'Update' : 'Create'} Payment Method
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
