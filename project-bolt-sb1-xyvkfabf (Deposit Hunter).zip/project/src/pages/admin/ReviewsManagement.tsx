import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { EducationalTestimonial } from '../../types';
import { Check, X, ShieldCheck } from 'lucide-react';

export function EducationalTestimonialsManagement() {
  const [testimonials, setTestimonials] = useState<EducationalTestimonial[]>([]);
  const [filter, setFilter] = useState<'all' | 'active' | 'pending'>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTestimonials();
  }, [filter]);

  async function fetchTestimonials() {
    setLoading(true);
    let query = supabase.from('user_stories').select('*').order('created_at', { ascending: false });

    if (filter === 'active') {
      query = query.eq('is_active', true);
    } else if (filter === 'pending') {
      query = query.eq('is_active', false);
    }

    const { data } = await query;

    if (data) {
      setTestimonials(data);
    }
    setLoading(false);
  }

  async function approveTestimonial(id: string) {
    await supabase.from('user_stories').update({ is_active: true }).eq('id', id);
    fetchTestimonials();
  }

  async function rejectTestimonial(id: string) {
    await supabase.from('user_stories').update({ is_active: false }).eq('id', id);
    fetchTestimonials();
  }

  async function toggleVerified(id: string, currentStatus: boolean) {
    await supabase.from('user_stories').update({ is_verified: !currentStatus }).eq('id', id);
    fetchTestimonials();
  }

  async function deleteTestimonial(id: string) {
    if (confirm('Are you sure you want to delete this testimonial?')) {
      await supabase.from('user_stories').delete().eq('id', id);
      fetchTestimonials();
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Educational Testimonials</h1>
        <p className="text-gray-600">Manage user testimonials about educational value gained from the portal</p>
      </div>

      <div className="flex gap-3">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded-lg font-semibold transition ${
            filter === 'all'
              ? 'bg-educational-primary text-white'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          All Testimonials
        </button>
        <button
          onClick={() => setFilter('active')}
          className={`px-4 py-2 rounded-lg font-semibold transition ${
            filter === 'active'
              ? 'bg-educational-success text-white'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          Active
        </button>
        <button
          onClick={() => setFilter('pending')}
          className={`px-4 py-2 rounded-lg font-semibold transition ${
            filter === 'pending'
              ? 'bg-yellow-500 text-white'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          Pending Approval
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-educational-primary mx-auto"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-bold text-gray-900">{testimonial.user_name}</span>
                    <span className="text-sm text-gray-500">{testimonial.location}</span>
                    {testimonial.is_verified && (
                      <ShieldCheck className="w-4 h-4 text-educational-primary" title="Verified Learner" />
                    )}
                  </div>
                  <p className="text-gray-700 mb-3">{testimonial.review_text}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(testimonial.created_at).toLocaleDateString('pt-PT')}
                  </p>
                </div>

                <div className="flex items-center gap-2 ml-4">
                  {testimonial.is_active ? (
                    <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                      Active
                    </span>
                  ) : (
                    <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-semibold">
                      Pending
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3 pt-4 border-t">
                {!testimonial.is_active && (
                  <button
                    onClick={() => approveTestimonial(testimonial.id)}
                    className="flex items-center gap-2 px-4 py-2 bg-educational-success hover:bg-green-700 text-white rounded-lg font-semibold transition"
                  >
                    <Check className="w-4 h-4" />
                    Approve
                  </button>
                )}
                {testimonial.is_active && (
                  <button
                    onClick={() => rejectTestimonial(testimonial.id)}
                    className="flex items-center gap-2 px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg font-semibold transition"
                  >
                    <X className="w-4 h-4" />
                    Deactivate
                  </button>
                )}
                <button
                  onClick={() => toggleVerified(testimonial.id, testimonial.is_verified)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition ${
                    testimonial.is_verified
                      ? 'bg-educational-primary/20 text-educational-primary'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  {testimonial.is_verified ? 'Verified' : 'Mark Verified'}
                </button>
                <button
                  onClick={() => deleteTestimonial(testimonial.id)}
                  className="ml-auto px-4 py-2 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg font-semibold transition"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}

          {testimonials.length === 0 && (
            <div className="text-center py-12 bg-white rounded-xl">
              <p className="text-gray-500">No testimonials found</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
