import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  FolderOpen,
  FileText,
  MessageSquare,
  ShieldCheck,
  CreditCard,
  AlertTriangle,
  CheckCircle,
  Code,
  Mail,
  Target,
  LogOut,
  Menu,
  X,
  Wrench,
  Eye,
  Activity,
  Clock,
  Settings,
  Shield,
  Users,
} from 'lucide-react';
import { useState } from 'react';
import { supabase } from '../../lib/supabase';

export function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/admin');
  };

  const navItems = [
    { path: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/admin/categories', icon: FolderOpen, label: 'Categories' },
    { path: '/admin/articles', icon: FileText, label: 'Articles' },
    { path: '/admin/testimonials', icon: MessageSquare, label: 'Testimonials' },
    { path: '/admin/regulatory', icon: ShieldCheck, label: 'Regulatory Bodies' },
    { path: '/admin/payments', icon: CreditCard, label: 'Payment Methods' },
    { path: '/admin/warnings', icon: AlertTriangle, label: 'Risk Warnings' },
    { path: '/admin/compliance', icon: CheckCircle, label: 'Compliance' },
    { path: '/admin/tracking', icon: Code, label: 'Tracking Scripts' },
    { path: '/admin/lead-gen', icon: Mail, label: 'Lead Gen Pages' },
    { path: '/admin/lead-gen-promotions', icon: Target, label: 'Promotions' },
    { path: '/admin/promotion-diagnostics', icon: Wrench, label: 'Diagnostics' },
    { path: '/admin/visitor-analytics', icon: Users, label: 'Visitor Analytics' },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="flex">
        <aside
          className={`${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          } md:translate-x-0 fixed md:static inset-y-0 left-0 z-50 w-64 bg-gray-900 text-white transition-transform duration-300 flex flex-col`}
        >
          <div className="flex items-center justify-between p-6 border-b border-gray-700 flex-shrink-0">
            <h1 className="text-xl font-bold">Educational CMS</h1>
            <button
              onClick={() => setSidebarOpen(false)}
              className="md:hidden text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <nav className="flex-1 overflow-y-auto p-4 space-y-1.5 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-gray-800">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-2.5 rounded-lg transition ${
                    isActive
                      ? 'bg-educational-primary text-white'
                      : 'text-gray-300 hover:bg-gray-800'
                  }`
                }
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                <span className="truncate">{item.label}</span>
              </NavLink>
            ))}
          </nav>

          <div className="flex-shrink-0 p-4 border-t border-gray-700">
            <button
              onClick={handleLogout}
              className="flex items-center gap-3 w-full px-4 py-2.5 text-gray-300 hover:bg-gray-800 rounded-lg transition"
            >
              <LogOut className="w-5 h-5 flex-shrink-0" />
              <span className="truncate">Logout</span>
            </button>
          </div>
        </aside>

        <div className="flex-1 min-h-screen">
          <header className="bg-white shadow-sm border-b p-4 md:p-6">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setSidebarOpen(true)}
                className="md:hidden"
              >
                <Menu className="w-6 h-6" />
              </button>
              <h2 className="text-2xl font-bold text-gray-900">
                DepositHunter Educational Portal
              </h2>
              <a
                href="/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-educational-primary hover:text-educational-secondary text-sm font-semibold"
              >
                View Website →
              </a>
            </div>
          </header>

          <main className="p-4 md:p-8">
            <Outlet />
          </main>
        </div>
      </div>

      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
