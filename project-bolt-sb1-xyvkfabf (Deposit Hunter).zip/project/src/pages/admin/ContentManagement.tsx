import { FileText, Shield, AlertCircle, CheckCircle } from 'lucide-react';

export function ContentManagement() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Compliance Center</h1>
        <p className="text-gray-600">Monitor and manage educational portal compliance settings</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-3 mb-6">
            <FileText className="w-6 h-6 text-educational-primary" />
            <h3 className="text-xl font-bold text-gray-900">Content Sections</h3>
          </div>

          <div className="space-y-3">
            <div className="p-4 border border-gray-200 rounded-lg hover:border-educational-primary transition cursor-pointer">
              <h4 className="font-semibold text-gray-900 mb-1">Hero Section</h4>
              <p className="text-sm text-gray-600">Educational portal title and mission statement</p>
            </div>

            <div className="p-4 border border-gray-200 rounded-lg hover:border-educational-primary transition cursor-pointer">
              <h4 className="font-semibold text-gray-900 mb-1">Educational Disclaimers</h4>
              <p className="text-sm text-gray-600">Manage all educational purpose disclaimers</p>
            </div>

            <div className="p-4 border border-gray-200 rounded-lg hover:border-educational-primary transition cursor-pointer">
              <h4 className="font-semibold text-gray-900 mb-1">Footer Content</h4>
              <p className="text-sm text-gray-600">Legal information and regulatory body links</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-3 mb-6">
            <Shield className="w-6 h-6 text-educational-success" />
            <h3 className="text-xl font-bold text-gray-900">Educational Purpose Settings</h3>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2">No Affiliate Disclosure</h4>
              <p className="text-sm text-gray-700 mb-3">
                This portal has NO affiliate relationships with any platforms, banks, or services.
                All information is purely educational and independent.
              </p>
              <span className="text-xs text-green-700 font-semibold">STATUS: COMPLIANT</span>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2">External Links Policy</h4>
              <p className="text-sm text-gray-700 mb-3">
                Maximum 2 external links per page - only to Portuguese regulatory authorities.
                No promotional or commercial links.
              </p>
              <span className="text-xs text-blue-700 font-semibold">STATUS: VERIFIED</span>
            </div>

            <div className="p-4 bg-educational-lightBlue border border-educational-primary rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2">SRIJ Educational Focus</h4>
              <p className="text-sm text-gray-700 mb-3">
                Gaming regulation content is purely educational, explaining Portuguese laws
                and consumer protection. No promotion of any services.
              </p>
              <span className="text-xs text-educational-primary font-semibold">STATUS: COMPLIANT</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-6">
          <CheckCircle className="w-6 h-6 text-educational-success" />
          <h3 className="text-xl font-bold text-gray-900">Google Ads Compliance Checklist</h3>
        </div>

        <div className="space-y-3">
          {[
            'No affiliate links present anywhere on site',
            'Educational disclaimers on all pages',
            'Maximum 2 external links per page (regulatory bodies only)',
            'SRIJ information is purely educational',
            'Risk warnings prominently displayed',
            'No promotional language or calls-to-action',
            'Consumer protection information provided',
            'All content is factual and verifiable',
            'Bilingual content (Portuguese/English) available',
            'Schema.org EducationalWebsite markup implemented',
            'Links to official Portuguese regulatory authorities',
            'No targeting or promotion of gambling/gaming services',
          ].map((item, index) => (
            <div key={index} className="flex items-center gap-3">
              <div className="w-6 h-6 bg-educational-success rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white text-sm">✓</span>
              </div>
              <span className="text-gray-700">{item}</span>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-green-50 border-2 border-green-500 rounded-lg">
          <div className="flex items-center gap-3">
            <CheckCircle className="w-6 h-6 text-green-600" />
            <div>
              <h4 className="font-bold text-green-900">Compliance Status: APPROVED</h4>
              <p className="text-sm text-green-700">
                This educational portal meets all Google Ads requirements for gambling-related educational content.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
