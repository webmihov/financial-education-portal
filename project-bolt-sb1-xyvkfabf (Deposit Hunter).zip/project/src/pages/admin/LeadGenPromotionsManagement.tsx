import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { LeadGenPromotion, LeadGenPage, PlatformCategory, PromotionType, PlacementPosition } from '../../types';
import { Plus, Edit, Trash2, X, Save, Target, Wand2, RefreshCw, Power, PowerOff, Trash, AlertTriangle, Sparkles } from 'lucide-react';
import {
  DEFAULT_CTA_TEXT,
  DEFAULT_PROMOTION_TITLE,
  DEFAULT_PROMOTION_DESCRIPTION,
  PROMOTION_TYPE_LABELS,
  PLACEMENT_POSITION_LABELS,
  TARGET_LOCATION_LABELS,
  getValidPositionsForType,
  getRecommendedPositionForType,
  isValidPositionForType,
} from '../../utils/leadGenDefaults';
import { getPromotionStats } from '../../utils/leadGenAnalytics';
import { generatePromotionsForPages, generatePromotionsWithConfig } from '../../utils/promotionGenerator';
import { GeneratorConfigModal, PromotionDistributionConfig } from '../../components/admin/GeneratorConfigModal';

export function LeadGenPromotionsManagement() {
  const [promotions, setPromotions] = useState<LeadGenPromotion[]>([]);
  const [pages, setPages] = useState<LeadGenPage[]>([]);
  const [categories, setCategories] = useState<PlatformCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingPromotion, setEditingPromotion] = useState<LeadGenPromotion | null>(null);
  const [stats, setStats] = useState<Record<string, { clicks: number }>>({});
  const [generating, setGenerating] = useState(false);
  const [generationModalOpen, setGenerationModalOpen] = useState(false);
  const [generationResult, setGenerationResult] = useState<any>(null);
  const [configModalOpen, setConfigModalOpen] = useState(false);
  const [selectedPromotions, setSelectedPromotions] = useState<string[]>([]);
  const [migrationModalOpen, setMigrationModalOpen] = useState(false);
  const [migrationResult, setMigrationResult] = useState<any>(null);
  const [migrating, setMigrating] = useState(false);

  const [formData, setFormData] = useState({
    lead_gen_page_id: '',
    promotion_type: 'inline_card' as PromotionType,
    promotion_title: DEFAULT_PROMOTION_TITLE,
    promotion_description: DEFAULT_PROMOTION_DESCRIPTION,
    cta_text: DEFAULT_CTA_TEXT,
    target_locations: [] as string[],
    target_category_ids: [] as string[],
    placement_position: 'middle' as PlacementPosition,
    display_order: 0,
    is_active: true,
  });

  useEffect(() => {
    fetchPromotions();
    fetchPages();
    fetchCategories();
  }, []);

  async function fetchPromotions() {
    try {
      const { data, error } = await supabase
        .from('lead_gen_promotions')
        .select('*')
        .order('display_order', { ascending: true });

      if (error) throw error;

      if (data) {
        setPromotions(data);
        data.forEach(async (promo) => {
          const promoStats = await getPromotionStats(promo.id);
          setStats((prev) => ({ ...prev, [promo.id]: promoStats }));
        });
      }
    } catch (error) {
      console.error('Error fetching promotions:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchPages() {
    try {
      const { data, error } = await supabase
        .from('lead_gen_pages')
        .select('*')
        .eq('is_active', true)
        .order('name', { ascending: true });

      if (error) throw error;
      if (data) setPages(data);
    } catch (error) {
      console.error('Error fetching pages:', error);
    }
  }

  async function fetchCategories() {
    try {
      const { data, error } = await supabase
        .from('platform_categories')
        .select('*')
        .eq('is_active', true)
        .order('name_pt', { ascending: true });

      if (error) throw error;
      if (data) setCategories(data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  }

  function openModal(promotion: LeadGenPromotion | null = null) {
    if (promotion) {
      setEditingPromotion(promotion);
      setFormData({
        lead_gen_page_id: promotion.lead_gen_page_id,
        promotion_type: promotion.promotion_type,
        promotion_title: promotion.promotion_title,
        promotion_description: promotion.promotion_description,
        cta_text: promotion.cta_text,
        target_locations: promotion.target_locations,
        target_category_ids: promotion.target_category_ids,
        placement_position: promotion.placement_position,
        display_order: promotion.display_order,
        is_active: promotion.is_active,
      });
    } else {
      setEditingPromotion(null);
      setFormData({
        lead_gen_page_id: '',
        promotion_type: 'inline_card',
        promotion_title: DEFAULT_PROMOTION_TITLE,
        promotion_description: DEFAULT_PROMOTION_DESCRIPTION,
        cta_text: DEFAULT_CTA_TEXT,
        target_locations: [],
        target_category_ids: [],
        placement_position: 'middle',
        display_order: promotions.length,
        is_active: true,
      });
    }
    setModalOpen(true);
  }

  function closeModal() {
    setModalOpen(false);
    setEditingPromotion(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!formData.lead_gen_page_id) {
      alert('Please select a Lead Gen Page. This is required for Google Ads compliance.');
      return;
    }

    if (!isValidPositionForType(formData.promotion_type, formData.placement_position)) {
      const recommendedPosition = getRecommendedPositionForType(formData.promotion_type);
      alert(
        `Invalid position for ${PROMOTION_TYPE_LABELS[formData.promotion_type]}. ` +
        `${PLACEMENT_POSITION_LABELS[formData.placement_position]} is not compatible with this type. ` +
        `Recommended: ${PLACEMENT_POSITION_LABELS[recommendedPosition]}`
      );
      return;
    }

    try {
      if (editingPromotion) {
        const { error } = await supabase
          .from('lead_gen_promotions')
          .update(formData)
          .eq('id', editingPromotion.id);

        if (error) throw error;
      } else {
        const { error } = await supabase.from('lead_gen_promotions').insert(formData);

        if (error) throw error;
      }

      closeModal();
      fetchPromotions();
    } catch (error: any) {
      alert('Error saving promotion: ' + error.message);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this promotion?')) {
      return;
    }

    try {
      const { error } = await supabase.from('lead_gen_promotions').delete().eq('id', id);

      if (error) throw error;
      fetchPromotions();
    } catch (error: any) {
      alert('Error deleting promotion: ' + error.message);
    }
  }

  function toggleTargetLocation(location: string) {
    if (formData.target_locations.includes(location)) {
      setFormData({
        ...formData,
        target_locations: formData.target_locations.filter((l) => l !== location),
      });
    } else {
      setFormData({
        ...formData,
        target_locations: [...formData.target_locations, location],
      });
    }
  }

  function toggleTargetCategory(categoryId: string) {
    if (formData.target_category_ids.includes(categoryId)) {
      setFormData({
        ...formData,
        target_category_ids: formData.target_category_ids.filter((c) => c !== categoryId),
      });
    } else {
      setFormData({
        ...formData,
        target_category_ids: [...formData.target_category_ids, categoryId],
      });
    }
  }

  async function handleQuickGenerateNatural() {
    if (!confirm('This will generate 3 natural promotions (1 text_ad top, 1 inline_card middle, 1 text_ad bottom) for all pages without active promotions. Continue?')) {
      return;
    }

    setGenerating(true);
    try {
      const result = await generatePromotionsForPages(3);
      setGenerationResult(result);
      setGenerationModalOpen(true);
      fetchPromotions();
    } catch (error: any) {
      alert('Error generating promotions: ' + error.message);
    } finally {
      setGenerating(false);
    }
  }

  async function handleConfiguredGenerate(config: PromotionDistributionConfig[]) {
    setConfigModalOpen(false);
    setGenerating(true);
    try {
      const result = await generatePromotionsWithConfig(config);
      setGenerationResult(result);
      setGenerationModalOpen(true);
      fetchPromotions();
    } catch (error: any) {
      alert('Error generating promotions: ' + error.message);
    } finally {
      setGenerating(false);
    }
  }

  function toggleSelectAll() {
    if (selectedPromotions.length === promotions.length) {
      setSelectedPromotions([]);
    } else {
      setSelectedPromotions(promotions.map((p) => p.id));
    }
  }

  function toggleSelectPromotion(id: string) {
    if (selectedPromotions.includes(id)) {
      setSelectedPromotions(selectedPromotions.filter((pid) => pid !== id));
    } else {
      setSelectedPromotions([...selectedPromotions, id]);
    }
  }

  async function handleBulkActivate() {
    if (selectedPromotions.length === 0) {
      alert('Please select promotions first');
      return;
    }

    if (!confirm(`Activate ${selectedPromotions.length} selected promotions?`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('lead_gen_promotions')
        .update({ is_active: true })
        .in('id', selectedPromotions);

      if (error) throw error;
      setSelectedPromotions([]);
      fetchPromotions();
    } catch (error: any) {
      alert('Error activating promotions: ' + error.message);
    }
  }

  async function handleBulkDeactivate() {
    if (selectedPromotions.length === 0) {
      alert('Please select promotions first');
      return;
    }

    if (!confirm(`Deactivate ${selectedPromotions.length} selected promotions?`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('lead_gen_promotions')
        .update({ is_active: false })
        .in('id', selectedPromotions);

      if (error) throw error;
      setSelectedPromotions([]);
      fetchPromotions();
    } catch (error: any) {
      alert('Error deactivating promotions: ' + error.message);
    }
  }

  async function handleBulkDelete() {
    if (selectedPromotions.length === 0) {
      alert('Please select promotions first');
      return;
    }

    if (!confirm(`Delete ${selectedPromotions.length} selected promotions? This cannot be undone.`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('lead_gen_promotions')
        .delete()
        .in('id', selectedPromotions);

      if (error) throw error;
      setSelectedPromotions([]);
      fetchPromotions();
    } catch (error: any) {
      alert('Error deleting promotions: ' + error.message);
    }
  }

  function handlePromotionTypeChange(newType: PromotionType) {
    const currentPosition = formData.placement_position;
    const isCurrentPositionValid = isValidPositionForType(newType, currentPosition);

    if (isCurrentPositionValid) {
      setFormData({ ...formData, promotion_type: newType });
    } else {
      const recommendedPosition = getRecommendedPositionForType(newType);
      setFormData({
        ...formData,
        promotion_type: newType,
        placement_position: recommendedPosition as PlacementPosition
      });
    }
  }

  async function migrateInvalidPositions() {
    try {
      const { data: allPromotions, error: fetchError } = await supabase
        .from('lead_gen_promotions')
        .select('*');

      if (fetchError) throw fetchError;
      if (!allPromotions) return { fixed: 0, total: 0, details: [] };

      const invalidPromotions = allPromotions.filter(
        promo => !isValidPositionForType(promo.promotion_type, promo.placement_position)
      );

      const details = [];
      let fixedCount = 0;

      for (const promo of invalidPromotions) {
        const oldPosition = promo.placement_position;
        const newPosition = getRecommendedPositionForType(promo.promotion_type);

        const { error: updateError } = await supabase
          .from('lead_gen_promotions')
          .update({ placement_position: newPosition })
          .eq('id', promo.id);

        if (updateError) {
          details.push({
            id: promo.id,
            title: promo.promotion_title,
            type: promo.promotion_type,
            oldPosition,
            newPosition,
            status: 'error',
            error: updateError.message
          });
        } else {
          fixedCount++;
          details.push({
            id: promo.id,
            title: promo.promotion_title,
            type: promo.promotion_type,
            oldPosition,
            newPosition,
            status: 'fixed'
          });
        }
      }

      return {
        fixed: fixedCount,
        total: invalidPromotions.length,
        details
      };
    } catch (error: any) {
      throw new Error('Migration failed: ' + error.message);
    }
  }

  async function handleMigratePositions() {
    if (!confirm('This will automatically fix all invalid position combinations. Continue?')) {
      return;
    }

    setMigrating(true);
    try {
      const result = await migrateInvalidPositions();
      setMigrationResult(result);
      setMigrationModalOpen(true);
      fetchPromotions();
    } catch (error: any) {
      alert('Error during migration: ' + error.message);
    } finally {
      setMigrating(false);
    }
  }

  if (loading) {
    return <div className="text-center py-12">Loading...</div>;
  }

  return (
    <div>
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Promotions</h1>
            <p className="text-gray-600 mt-1">
              Manage promotional content - Links to internal pages only
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleMigratePositions}
              disabled={migrating}
              className="flex items-center gap-2 bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition disabled:opacity-50"
            >
              {migrating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <AlertTriangle className="w-5 h-5" />}
              Fix Invalid Positions
            </button>
            <button
              onClick={handleQuickGenerateNatural}
              disabled={generating}
              className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition disabled:opacity-50"
            >
              {generating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              Generate Natural (3)
            </button>
            <button
              onClick={() => setConfigModalOpen(true)}
              disabled={generating}
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition disabled:opacity-50"
            >
              <Wand2 className="w-5 h-5" />
              Custom Generation...
            </button>
            <button
              onClick={() => openModal()}
              className="flex items-center gap-2 bg-educational-primary text-white px-4 py-2 rounded-lg hover:bg-educational-secondary transition"
            >
              <Plus className="w-5 h-5" />
              New Promotion
            </button>
          </div>
        </div>

        {selectedPromotions.length > 0 && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="font-semibold text-blue-900">
                {selectedPromotions.length} selected
              </span>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleBulkActivate}
                className="flex items-center gap-2 bg-green-600 text-white px-3 py-1.5 rounded-lg hover:bg-green-700 transition text-sm"
              >
                <Power className="w-4 h-4" />
                Activate
              </button>
              <button
                onClick={handleBulkDeactivate}
                className="flex items-center gap-2 bg-yellow-600 text-white px-3 py-1.5 rounded-lg hover:bg-yellow-700 transition text-sm"
              >
                <PowerOff className="w-4 h-4" />
                Deactivate
              </button>
              <button
                onClick={handleBulkDelete}
                className="flex items-center gap-2 bg-red-600 text-white px-3 py-1.5 rounded-lg hover:bg-red-700 transition text-sm"
              >
                <Trash className="w-4 h-4" />
                Delete
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                <input
                  type="checkbox"
                  checked={selectedPromotions.length === promotions.length && promotions.length > 0}
                  onChange={toggleSelectAll}
                  className="w-4 h-4"
                />
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Title</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Target Page</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Position</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Clicks</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {promotions.map((promotion) => {
              const targetPage = pages.find((p) => p.id === promotion.lead_gen_page_id);
              const promoStats = stats[promotion.id];

              return (
                <tr key={promotion.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <input
                      type="checkbox"
                      checked={selectedPromotions.includes(promotion.id)}
                      onChange={() => toggleSelectPromotion(promotion.id)}
                      className="w-4 h-4"
                    />
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900">{promotion.promotion_title}</div>
                  </td>
                  <td className="px-6 py-4">
                    {targetPage ? (
                      <div>
                        <div className="text-sm text-gray-900">{targetPage.name}</div>
                        <code className="text-xs bg-gray-100 px-2 py-1 rounded">/lp/{targetPage.slug}</code>
                      </div>
                    ) : (
                      <span className="text-xs text-red-600">Page not found</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {PROMOTION_TYPE_LABELS[promotion.promotion_type]}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {PLACEMENT_POSITION_LABELS[promotion.placement_position]}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {promoStats ? promoStats.clicks : 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        promotion.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {promotion.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openModal(promotion)}
                        className="text-educational-primary hover:text-educational-secondary"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(promotion.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {modalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-lg w-full max-w-3xl my-8">
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-2xl font-bold">
                {editingPromotion ? 'Edit Promotion' : 'New Promotion'}
              </h2>
              <button onClick={closeModal} className="text-gray-500 hover:text-gray-700">
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Target className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-blue-900 mb-1">Google Ads Compliance</p>
                    <p className="text-sm text-blue-800">
                      All promotions MUST link to internal Lead Gen Pages. Cannot link to external URLs.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Target Lead Gen Page * <span className="text-red-600">(Required)</span>
                </label>
                <select
                  required
                  value={formData.lead_gen_page_id}
                  onChange={(e) => setFormData({ ...formData, lead_gen_page_id: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  <option value="">-- Select a Page --</option>
                  {pages.map((page) => (
                    <option key={page.id} value={page.id}>
                      {page.name} (/lp/{page.slug})
                    </option>
                  ))}
                </select>
                {formData.lead_gen_page_id && (
                  <p className="text-xs text-green-600 mt-1">
                    ✓ Will link to: /lp/{pages.find((p) => p.id === formData.lead_gen_page_id)?.slug}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Promotion Type</label>
                <select
                  value={formData.promotion_type}
                  onChange={(e) => handlePromotionTypeChange(e.target.value as PromotionType)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  {Object.entries(PROMOTION_TYPE_LABELS).map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                <input
                  type="text"
                  value={formData.promotion_title}
                  onChange={(e) => setFormData({ ...formData, promotion_title: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  value={formData.promotion_description}
                  onChange={(e) => setFormData({ ...formData, promotion_description: e.target.value })}
                  rows={3}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">CTA Text</label>
                <input
                  type="text"
                  value={formData.cta_text}
                  onChange={(e) => setFormData({ ...formData, cta_text: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Target Locations</label>
                <div className="space-y-2">
                  {Object.entries(TARGET_LOCATION_LABELS).map(([value, label]) => (
                    <label key={value} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={formData.target_locations.includes(value)}
                        onChange={() => toggleTargetLocation(value)}
                        className="w-4 h-4"
                      />
                      <span className="text-sm text-gray-700">{label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Target Categories (optional - filters within locations)
                </label>
                <div className="space-y-2 max-h-40 overflow-y-auto border border-gray-200 rounded-lg p-3">
                  {categories.map((cat) => (
                    <label key={cat.id} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={formData.target_category_ids.includes(cat.id)}
                        onChange={() => toggleTargetCategory(cat.id)}
                        className="w-4 h-4"
                      />
                      <span className="text-sm text-gray-700">{cat.name_pt}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Placement Position</label>
                <select
                  value={formData.placement_position}
                  onChange={(e) =>
                    setFormData({ ...formData, placement_position: e.target.value as PlacementPosition })
                  }
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  {Object.entries(PLACEMENT_POSITION_LABELS)
                    .filter(([value]) => getValidPositionsForType(formData.promotion_type).includes(value))
                    .map(([value, label]) => {
                      const isRecommended = getRecommendedPositionForType(formData.promotion_type) === value;
                      return (
                        <option key={value} value={value}>
                          {isRecommended ? '✓ ' : ''}{label}{isRecommended ? ' (Recommended)' : ''}
                        </option>
                      );
                    })}
                </select>
                <p className="text-xs text-gray-500 mt-1">
                  Recommended for {PROMOTION_TYPE_LABELS[formData.promotion_type]}: {PLACEMENT_POSITION_LABELS[getRecommendedPositionForType(formData.promotion_type)]}
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Display Order</label>
                  <input
                    type="number"
                    value={formData.display_order}
                    onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  />
                </div>

                <div className="flex items-center gap-3 pt-7">
                  <input
                    type="checkbox"
                    id="is_active_promo"
                    checked={formData.is_active}
                    onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                    className="w-4 h-4"
                  />
                  <label htmlFor="is_active_promo" className="text-sm font-medium text-gray-700">
                    Active
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 bg-educational-primary text-white px-4 py-2 rounded-lg hover:bg-educational-secondary"
                >
                  <Save className="w-4 h-4" />
                  Save Promotion
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {generationModalOpen && generationResult && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-2xl max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-2xl font-bold">Generation Results</h2>
              <button
                onClick={() => setGenerationModalOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-green-50 p-4 rounded-lg text-center">
                  <div className="text-3xl font-bold text-green-600">{generationResult.created}</div>
                  <div className="text-sm text-gray-600">Promotions Created</div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg text-center">
                  <div className="text-3xl font-bold text-yellow-600">{generationResult.skipped}</div>
                  <div className="text-sm text-gray-600">Pages Skipped</div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg text-center">
                  <div className="text-3xl font-bold text-red-600">{generationResult.errors.length}</div>
                  <div className="text-sm text-gray-600">Errors</div>
                </div>
              </div>

              {generationResult.details.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold text-gray-900">Details:</h3>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {generationResult.details.map((detail: any, idx: number) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-lg border ${
                          detail.status === 'created'
                            ? 'bg-green-50 border-green-200'
                            : detail.status === 'skipped'
                            ? 'bg-yellow-50 border-yellow-200'
                            : 'bg-red-50 border-red-200'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="font-medium">{detail.pageName}</div>
                            {detail.promotionsCreated > 0 && (
                              <div className="text-sm text-gray-600 mt-1">
                                {detail.promotionsCreated} promotions created
                              </div>
                            )}
                            {detail.reason && (
                              <div className="text-sm text-gray-600 mt-1">{detail.reason}</div>
                            )}
                          </div>
                          <span
                            className={`px-2 py-1 text-xs rounded-full ${
                              detail.status === 'created'
                                ? 'bg-green-100 text-green-800'
                                : detail.status === 'skipped'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {detail.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {generationResult.errors.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h3 className="font-semibold text-red-900 mb-2">Errors:</h3>
                  <ul className="list-disc list-inside text-sm text-red-800 space-y-1">
                    {generationResult.errors.map((error: string, idx: number) => (
                      <li key={idx}>{error}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Natural Distribution:</strong> Generated promotions follow a curated pattern for professional appearance.
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-3 p-6 border-t">
              <button
                onClick={() => setGenerationModalOpen(false)}
                className="px-4 py-2 bg-educational-primary text-white rounded-lg hover:bg-educational-secondary"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {migrationModalOpen && migrationResult && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-2xl max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-2xl font-bold">Migration Results</h2>
              <button
                onClick={() => setMigrationModalOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-50 p-4 rounded-lg text-center">
                  <div className="text-3xl font-bold text-green-600">{migrationResult.fixed}</div>
                  <div className="text-sm text-gray-600">Positions Fixed</div>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg text-center">
                  <div className="text-3xl font-bold text-blue-600">{migrationResult.total}</div>
                  <div className="text-sm text-gray-600">Total Invalid</div>
                </div>
              </div>

              {migrationResult.total === 0 ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                  <p className="text-green-800 font-semibold">All promotions have valid positions!</p>
                  <p className="text-sm text-green-600 mt-1">No migrations needed.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <h3 className="font-semibold text-gray-900">Details:</h3>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {migrationResult.details.map((detail: any, idx: number) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-lg border ${
                          detail.status === 'fixed'
                            ? 'bg-green-50 border-green-200'
                            : 'bg-red-50 border-red-200'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="font-medium">{detail.title}</div>
                            <div className="text-sm text-gray-600 mt-1">
                              Type: {PROMOTION_TYPE_LABELS[detail.type]}
                            </div>
                            <div className="text-sm text-gray-600">
                              Position: {PLACEMENT_POSITION_LABELS[detail.oldPosition]} → {PLACEMENT_POSITION_LABELS[detail.newPosition]}
                            </div>
                            {detail.error && (
                              <div className="text-sm text-red-600 mt-1">{detail.error}</div>
                            )}
                          </div>
                          <span
                            className={`px-2 py-1 text-xs rounded-full ${
                              detail.status === 'fixed'
                                ? 'bg-green-100 text-green-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {detail.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Smart Migration:</strong> Invalid positions were automatically corrected to the recommended position for each promotion type.
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-3 p-6 border-t">
              <button
                onClick={() => setMigrationModalOpen(false)}
                className="px-4 py-2 bg-educational-primary text-white rounded-lg hover:bg-educational-secondary"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      <GeneratorConfigModal
        isOpen={configModalOpen}
        onClose={() => setConfigModalOpen(false)}
        onGenerate={handleConfiguredGenerate}
        isGenerating={generating}
      />
    </div>
  );
}
