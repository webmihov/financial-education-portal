import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { RegulatoryBody } from '../../types';
import { Plus, Edit, Trash2, Eye, EyeOff, Save, X, ExternalLink } from 'lucide-react';

interface BodyFormData {
  name_pt: string;
  name_en: string;
  acronym: string;
  description_pt: string;
  description_en: string;
  jurisdiction: string;
  oversight_areas: string[];
  website_url: string;
  verification_url: string;
  complaint_url: string;
  display_order: number;
}

export function RegulatoryBodiesManagement() {
  const [bodies, setBodies] = useState<RegulatoryBody[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newOversightArea, setNewOversightArea] = useState('');
  const [formData, setFormData] = useState<BodyFormData>({
    name_pt: '',
    name_en: '',
    acronym: '',
    description_pt: '',
    description_en: '',
    jurisdiction: 'Portugal',
    oversight_areas: [],
    website_url: '',
    verification_url: '',
    complaint_url: '',
    display_order: 0,
  });

  useEffect(() => {
    fetchBodies();
  }, []);

  async function fetchBodies() {
    setLoading(true);
    const { data } = await supabase
      .from('regulatory_bodies')
      .select('*')
      .order('display_order');

    if (data) {
      setBodies(data);
    }
    setLoading(false);
  }

  function openAddModal() {
    setEditingId(null);
    setFormData({
      name_pt: '',
      name_en: '',
      acronym: '',
      description_pt: '',
      description_en: '',
      jurisdiction: 'Portugal',
      oversight_areas: [],
      website_url: '',
      verification_url: '',
      complaint_url: '',
      display_order: bodies.length + 1,
    });
    setShowModal(true);
  }

  function openEditModal(body: RegulatoryBody) {
    setEditingId(body.id);
    setFormData({
      name_pt: body.name_pt,
      name_en: body.name_en,
      acronym: body.acronym,
      description_pt: body.description_pt,
      description_en: body.description_en,
      jurisdiction: body.jurisdiction,
      oversight_areas: body.oversight_areas,
      website_url: body.website_url,
      verification_url: body.verification_url,
      complaint_url: body.complaint_url,
      display_order: body.display_order,
    });
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (editingId) {
      await supabase
        .from('regulatory_bodies')
        .update(formData)
        .eq('id', editingId);
    } else {
      await supabase.from('regulatory_bodies').insert([formData]);
    }

    setShowModal(false);
    fetchBodies();
  }

  function addOversightArea() {
    if (newOversightArea.trim() && !formData.oversight_areas.includes(newOversightArea.trim())) {
      setFormData({
        ...formData,
        oversight_areas: [...formData.oversight_areas, newOversightArea.trim()]
      });
      setNewOversightArea('');
    }
  }

  function removeOversightArea(area: string) {
    setFormData({
      ...formData,
      oversight_areas: formData.oversight_areas.filter(a => a !== area)
    });
  }

  async function toggleActive(id: string, currentStatus: boolean) {
    await supabase
      .from('regulatory_bodies')
      .update({ is_active: !currentStatus })
      .eq('id', id);
    fetchBodies();
  }

  async function deleteBody(id: string) {
    if (confirm('Are you sure you want to delete this regulatory body?')) {
      await supabase.from('regulatory_bodies').delete().eq('id', id);
      fetchBodies();
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Regulatory Bodies</h1>
          <p className="text-gray-600">Manage Portuguese regulatory authorities and oversight organizations</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center gap-2 px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
        >
          <Plus className="w-5 h-5" />
          Add Regulatory Body
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-educational-primary mx-auto"></div>
        </div>
      ) : (
        <div className="grid gap-6">
          {bodies.map((body) => (
            <div key={body.id} className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="px-3 py-1 bg-educational-primary/10 text-educational-primary font-bold rounded-lg">
                      {body.acronym}
                    </span>
                    {body.is_active ? (
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                        Active
                      </span>
                    ) : (
                      <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-semibold">
                        Inactive
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-gray-900 text-lg mb-1">{body.name_pt}</h3>
                  <p className="text-gray-600 mb-3">{body.name_en}</p>
                  <p className="text-sm text-gray-700 mb-3">{body.description_pt}</p>

                  {body.oversight_areas.length > 0 && (
                    <div className="mb-3">
                      <span className="text-xs font-semibold text-gray-600 uppercase">Oversight Areas:</span>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {body.oversight_areas.map((area, idx) => (
                          <span key={idx} className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
                            {area}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-3 text-sm">
                    {body.website_url && (
                      <a
                        href={body.website_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-educational-primary hover:underline flex items-center gap-1"
                      >
                        Website
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                    {body.verification_url && (
                      <a
                        href={body.verification_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-educational-primary hover:underline flex items-center gap-1"
                      >
                        Verification
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                    {body.complaint_url && (
                      <a
                        href={body.complaint_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-educational-primary hover:underline flex items-center gap-1"
                      >
                        Complaints
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 ml-4">
                  <button
                    onClick={() => toggleActive(body.id, body.is_active)}
                    className="text-educational-primary hover:text-educational-secondary"
                    title={body.is_active ? 'Deactivate' : 'Activate'}
                  >
                    {body.is_active ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                  <button
                    onClick={() => openEditModal(body)}
                    className="text-educational-secondary hover:text-educational-primary"
                  >
                    <Edit className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => deleteBody(body.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {bodies.length === 0 && (
            <div className="text-center py-12 bg-white rounded-xl">
              <p className="text-gray-500">No regulatory bodies found</p>
            </div>
          )}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b sticky top-0 bg-white">
              <h2 className="text-2xl font-bold text-gray-900">
                {editingId ? 'Edit Regulatory Body' : 'Add New Regulatory Body'}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="md:col-span-1">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Acronym *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.acronym}
                    onChange={(e) => setFormData({ ...formData, acronym: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="SRIJ"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Jurisdiction
                  </label>
                  <input
                    type="text"
                    value={formData.jurisdiction}
                    onChange={(e) => setFormData({ ...formData, jurisdiction: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name (Portuguese) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name_pt}
                    onChange={(e) => setFormData({ ...formData, name_pt: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name (English) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name_en}
                    onChange={(e) => setFormData({ ...formData, name_en: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description (Portuguese)
                  </label>
                  <textarea
                    value={formData.description_pt}
                    onChange={(e) => setFormData({ ...formData, description_pt: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description (English)
                  </label>
                  <textarea
                    value={formData.description_en}
                    onChange={(e) => setFormData({ ...formData, description_en: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Oversight Areas
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={newOversightArea}
                    onChange={(e) => setNewOversightArea(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addOversightArea())}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="e.g., jogos online"
                  />
                  <button
                    type="button"
                    onClick={addOversightArea}
                    className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.oversight_areas.map((area, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-educational-primary/10 text-educational-primary rounded-lg text-sm flex items-center gap-2"
                    >
                      {area}
                      <button
                        type="button"
                        onClick={() => removeOversightArea(area)}
                        className="hover:text-red-600"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Website URL
                  </label>
                  <input
                    type="url"
                    value={formData.website_url}
                    onChange={(e) => setFormData({ ...formData, website_url: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="https://..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Verification URL
                  </label>
                  <input
                    type="url"
                    value={formData.verification_url}
                    onChange={(e) => setFormData({ ...formData, verification_url: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="https://..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Complaint URL
                  </label>
                  <input
                    type="url"
                    value={formData.complaint_url}
                    onChange={(e) => setFormData({ ...formData, complaint_url: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="https://..."
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Display Order
                </label>
                <input
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-lg font-semibold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
                >
                  <Save className="w-5 h-5" />
                  {editingId ? 'Update' : 'Create'} Regulatory Body
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
