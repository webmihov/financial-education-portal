import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { TrendingUp, Users, MousePointerClick, RotateCw } from 'lucide-react';

export function AnalyticsDashboard() {
  const [analytics, setAnalytics] = useState({
    totalInteractions: 0,
    spinPlays: 0,
    ctaClicks: 0,
    uniqueVisitors: 0,
    recentInteractions: [] as any[],
  });

  useEffect(() => {
    fetchAnalytics();
  }, []);

  async function fetchAnalytics() {
    const { data: interactions } = await supabase
      .from('user_interactions')
      .select('*')
      .order('timestamp', { ascending: false });

    if (interactions) {
      const spinPlays = interactions.filter((i) => i.action_type === 'spin_game_result').length;
      const ctaClicks = interactions.filter((i) => i.action_type === 'cta_click').length;
      const uniqueIPs = new Set(interactions.map((i) => i.ip_hash)).size;

      setAnalytics({
        totalInteractions: interactions.length,
        spinPlays,
        ctaClicks,
        uniqueVisitors: uniqueIPs,
        recentInteractions: interactions.slice(0, 10),
      });
    }
  }

  const statCards = [
    {
      title: 'Total Interactions',
      value: analytics.totalInteractions,
      icon: TrendingUp,
      color: 'bg-portugal-blue',
    },
    {
      title: 'Spin Game Plays',
      value: analytics.spinPlays,
      icon: RotateCw,
      color: 'bg-portugal-green',
    },
    {
      title: 'CTA Clicks',
      value: analytics.ctaClicks,
      icon: MousePointerClick,
      color: 'bg-portugal-lightBlue',
    },
    {
      title: 'Unique Visitors',
      value: analytics.uniqueVisitors,
      icon: Users,
      color: 'bg-portugal-gold',
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics Dashboard</h1>
        <p className="text-gray-600">Monitor user interactions and engagement</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, index) => (
          <div
            key={index}
            className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 ${card.color} rounded-lg flex items-center justify-center`}>
                <card.icon className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">{card.value}</div>
            <div className="text-sm text-gray-600">{card.title}</div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Recent Interactions</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Action Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Timestamp
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  User Agent
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {analytics.recentInteractions.map((interaction, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        interaction.action_type === 'spin_game_result'
                          ? 'bg-portugal-green/20 text-portugal-green'
                          : 'bg-portugal-blue/20 text-portugal-blue'
                      }`}
                    >
                      {interaction.action_type}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                    {new Date(interaction.timestamp).toLocaleString('pt-PT')}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                    {interaction.user_agent}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
        <h3 className="font-bold text-gray-900 mb-2">Privacy Notice</h3>
        <p className="text-sm text-gray-700">
          All user data is anonymized. IP addresses are hashed for privacy compliance with GDPR.
          No personally identifiable information is stored.
        </p>
      </div>
    </div>
  );
}
