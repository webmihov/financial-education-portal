import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { RiskWarning } from '../../types';
import { Plus, Edit, Trash2, Eye, EyeOff, Save, X, AlertTriangle } from 'lucide-react';

interface WarningFormData {
  warning_key: string;
  title_pt: string;
  title_en: string;
  content_pt: string;
  content_en: string;
  severity_level: string;
  applies_to: string[];
  display_order: number;
}

export function RiskWarningsManagement() {
  const [warnings, setWarnings] = useState<RiskWarning[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newCategory, setNewCategory] = useState('');
  const [formData, setFormData] = useState<WarningFormData>({
    warning_key: '',
    title_pt: '',
    title_en: '',
    content_pt: '',
    content_en: '',
    severity_level: 'medium',
    applies_to: [],
    display_order: 0,
  });

  const severityLevels = ['high', 'medium', 'low'];

  useEffect(() => {
    fetchWarnings();
  }, []);

  async function fetchWarnings() {
    setLoading(true);
    const { data } = await supabase
      .from('risk_warnings')
      .select('*')
      .order('display_order');

    if (data) {
      setWarnings(data);
    }
    setLoading(false);
  }

  function openAddModal() {
    setEditingId(null);
    setFormData({
      warning_key: '',
      title_pt: '',
      title_en: '',
      content_pt: '',
      content_en: '',
      severity_level: 'medium',
      applies_to: [],
      display_order: warnings.length + 1,
    });
    setShowModal(true);
  }

  function openEditModal(warning: RiskWarning) {
    setEditingId(warning.id);
    setFormData({
      warning_key: warning.warning_key,
      title_pt: warning.title_pt,
      title_en: warning.title_en,
      content_pt: warning.content_pt,
      content_en: warning.content_en,
      severity_level: warning.severity_level,
      applies_to: warning.applies_to,
      display_order: warning.display_order,
    });
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (editingId) {
      await supabase
        .from('risk_warnings')
        .update(formData)
        .eq('id', editingId);
    } else {
      await supabase.from('risk_warnings').insert([formData]);
    }

    setShowModal(false);
    fetchWarnings();
  }

  function generateKey(title: string) {
    return title
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/(^_|_$)/g, '');
  }

  function addCategory() {
    if (newCategory.trim() && !formData.applies_to.includes(newCategory.trim())) {
      setFormData({
        ...formData,
        applies_to: [...formData.applies_to, newCategory.trim()]
      });
      setNewCategory('');
    }
  }

  function removeCategory(category: string) {
    setFormData({
      ...formData,
      applies_to: formData.applies_to.filter(c => c !== category)
    });
  }

  async function toggleActive(id: string, currentStatus: boolean) {
    await supabase
      .from('risk_warnings')
      .update({ is_active: !currentStatus })
      .eq('id', id);
    fetchWarnings();
  }

  async function deleteWarning(id: string) {
    if (confirm('Are you sure you want to delete this risk warning?')) {
      await supabase.from('risk_warnings').delete().eq('id', id);
      fetchWarnings();
    }
  }

  function getSeverityColor(level: string) {
    switch (level) {
      case 'high': return 'bg-red-100 text-red-800 border-red-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  }

  function getSeverityIcon(level: string) {
    switch (level) {
      case 'high': return 'text-red-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Risk Warnings</h1>
          <p className="text-gray-600">Manage standardized risk warning templates for educational content</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center gap-2 px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
        >
          <Plus className="w-5 h-5" />
          Add Risk Warning
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-educational-primary mx-auto"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {warnings.map((warning) => (
            <div key={warning.id} className={`border-2 rounded-xl p-6 ${getSeverityColor(warning.severity_level)}`}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <AlertTriangle className={`w-6 h-6 ${getSeverityIcon(warning.severity_level)}`} />
                    <div>
                      <h3 className="font-bold text-gray-900 text-lg">{warning.title_pt}</h3>
                      <p className="text-sm text-gray-600">{warning.title_en}</p>
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4 mt-3">
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-1">Portuguese:</p>
                      <p className="text-sm text-gray-800">{warning.content_pt}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-1">English:</p>
                      <p className="text-sm text-gray-800">{warning.content_en}</p>
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center gap-3">
                    <div>
                      <span className="text-xs font-semibold text-gray-600 uppercase">Key:</span>
                      <code className="ml-2 px-2 py-1 bg-gray-900/10 rounded text-xs">{warning.warning_key}</code>
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-gray-600 uppercase">Severity:</span>
                      <span className="ml-2 px-2 py-1 bg-gray-900/10 rounded text-xs font-semibold uppercase">
                        {warning.severity_level}
                      </span>
                    </div>
                    {warning.is_active ? (
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                        Active
                      </span>
                    ) : (
                      <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-semibold">
                        Inactive
                      </span>
                    )}
                  </div>

                  {warning.applies_to.length > 0 && (
                    <div className="mt-3">
                      <span className="text-xs font-semibold text-gray-600 uppercase">Applies to:</span>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {warning.applies_to.map((category, idx) => (
                          <span key={idx} className="px-2 py-1 bg-gray-900/10 rounded text-xs">
                            {category}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 ml-4">
                  <button
                    onClick={() => toggleActive(warning.id, warning.is_active)}
                    className="text-educational-primary hover:text-educational-secondary"
                    title={warning.is_active ? 'Deactivate' : 'Activate'}
                  >
                    {warning.is_active ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                  <button
                    onClick={() => openEditModal(warning)}
                    className="text-educational-secondary hover:text-educational-primary"
                  >
                    <Edit className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => deleteWarning(warning.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {warnings.length === 0 && (
            <div className="text-center py-12 bg-white rounded-xl">
              <p className="text-gray-500">No risk warnings found</p>
            </div>
          )}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b sticky top-0 bg-white">
              <h2 className="text-2xl font-bold text-gray-900">
                {editingId ? 'Edit Risk Warning' : 'Add New Risk Warning'}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Warning Key *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.warning_key}
                    onChange={(e) => setFormData({ ...formData, warning_key: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="e.g., deposit_risk"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Severity Level *
                  </label>
                  <select
                    value={formData.severity_level}
                    onChange={(e) => setFormData({ ...formData, severity_level: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  >
                    {severityLevels.map(level => (
                      <option key={level} value={level}>{level}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Title (Portuguese) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title_pt}
                    onChange={(e) => setFormData({ ...formData, title_pt: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Title (English) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title_en}
                    onChange={(e) => {
                      const value = e.target.value;
                      setFormData({
                        ...formData,
                        title_en: value,
                        warning_key: editingId ? formData.warning_key : generateKey(value)
                      });
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Content (Portuguese) *
                  </label>
                  <textarea
                    required
                    value={formData.content_pt}
                    onChange={(e) => setFormData({ ...formData, content_pt: e.target.value })}
                    rows={5}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Content (English) *
                  </label>
                  <textarea
                    required
                    value={formData.content_en}
                    onChange={(e) => setFormData({ ...formData, content_en: e.target.value })}
                    rows={5}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Applies To Categories
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCategory())}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                    placeholder="e.g., all, jogos-srij, criptomoedas"
                  />
                  <button
                    type="button"
                    onClick={addCategory}
                    className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.applies_to.map((category, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-educational-primary/10 text-educational-primary rounded-lg text-sm flex items-center gap-2"
                    >
                      {category}
                      <button
                        type="button"
                        onClick={() => removeCategory(category)}
                        className="hover:text-red-600"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Display Order
                </label>
                <input
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-lg font-semibold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
                >
                  <Save className="w-5 h-5" />
                  {editingId ? 'Update' : 'Create'} Risk Warning
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
