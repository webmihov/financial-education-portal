import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { EducationalArticle, PlatformCategory } from '../../types';
import { Plus, Edit, Trash2, Eye, EyeOff, Save, X, BookOpen, AlertCircle, Wand2 } from 'lucide-react';
import { generateArticleFromCategory } from '../../utils/articleGenerator';

interface ArticleFormData {
  title_pt: string;
  title_en: string;
  slug: string;
  category_id: string | null;
  intro_pt: string;
  intro_en: string;
  how_it_works_pt: string;
  how_it_works_en: string;
  regulatory_status_pt: string;
  regulatory_status_en: string;
  risks_pt: string;
  risks_en: string;
  security_pt: string;
  security_en: string;
  red_flags_pt: string;
  red_flags_en: string;
  consumer_protection_pt: string;
  consumer_protection_en: string;
  disclaimer_pt: string;
  disclaimer_en: string;
  author: string;
  display_order: number;
}

export function EducationalArticlesManagement() {
  const [articles, setArticles] = useState<EducationalArticle[]>([]);
  const [categories, setCategories] = useState<PlatformCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [currentSection, setCurrentSection] = useState<'basic' | 'content'>('basic');
  const [generating, setGenerating] = useState(false);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [categoriesWithoutArticles, setCategoriesWithoutArticles] = useState<PlatformCategory[]>([]);
  const [formData, setFormData] = useState<ArticleFormData>({
    title_pt: '',
    title_en: '',
    slug: '',
    category_id: null,
    intro_pt: '',
    intro_en: '',
    how_it_works_pt: '',
    how_it_works_en: '',
    regulatory_status_pt: '',
    regulatory_status_en: '',
    risks_pt: '',
    risks_en: '',
    security_pt: '',
    security_en: '',
    red_flags_pt: '',
    red_flags_en: '',
    consumer_protection_pt: '',
    consumer_protection_en: '',
    disclaimer_pt: '',
    disclaimer_en: '',
    author: 'DepositHunter Editorial Team',
    display_order: 0,
  });

  useEffect(() => {
    fetchArticles();
    fetchCategories();
  }, []);

  async function fetchCategories() {
    const { data } = await supabase
      .from('platform_categories')
      .select('*')
      .eq('is_active', true)
      .order('display_order');
    if (data) {
      setCategories(data);
    }
  }

  async function fetchArticles() {
    setLoading(true);
    const { data } = await supabase
      .from('educational_articles')
      .select('*, platform_categories(name_pt)')
      .order('display_order');

    if (data) {
      setArticles(data as any);
    }
    setLoading(false);
  }

  function generateSlug(text: string) {
    return text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }

  function openAddModal() {
    setEditingId(null);
    setCurrentSection('basic');
    setFormData({
      title_pt: '',
      title_en: '',
      slug: '',
      category_id: categories.length > 0 ? categories[0].id : null,
      intro_pt: '',
      intro_en: '',
      how_it_works_pt: '',
      how_it_works_en: '',
      regulatory_status_pt: '',
      regulatory_status_en: '',
      risks_pt: '',
      risks_en: '',
      security_pt: '',
      security_en: '',
      red_flags_pt: '',
      red_flags_en: '',
      consumer_protection_pt: '',
      consumer_protection_en: '',
      disclaimer_pt: '',
      disclaimer_en: '',
      author: 'DepositHunter Editorial Team',
      display_order: articles.length + 1,
    });
    setShowModal(true);
  }

  function openEditModal(article: EducationalArticle) {
    setEditingId(article.id);
    setCurrentSection('basic');
    setFormData({
      title_pt: article.title_pt,
      title_en: article.title_en,
      slug: article.slug,
      category_id: article.category_id,
      intro_pt: article.intro_pt,
      intro_en: article.intro_en,
      how_it_works_pt: article.how_it_works_pt,
      how_it_works_en: article.how_it_works_en,
      regulatory_status_pt: article.regulatory_status_pt,
      regulatory_status_en: article.regulatory_status_en,
      risks_pt: article.risks_pt,
      risks_en: article.risks_en,
      security_pt: article.security_pt,
      security_en: article.security_en,
      red_flags_pt: article.red_flags_pt,
      red_flags_en: article.red_flags_en,
      consumer_protection_pt: article.consumer_protection_pt,
      consumer_protection_en: article.consumer_protection_en,
      disclaimer_pt: article.disclaimer_pt,
      disclaimer_en: article.disclaimer_en,
      author: article.author,
      display_order: article.display_order,
    });
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const dataToSave = {
      ...formData,
      last_reviewed: new Date().toISOString(),
    };

    if (editingId) {
      await supabase
        .from('educational_articles')
        .update(dataToSave)
        .eq('id', editingId);
    } else {
      await supabase.from('educational_articles').insert([dataToSave]);
    }

    setShowModal(false);
    fetchArticles();
  }

  async function toggleActive(id: string, currentStatus: boolean) {
    await supabase
      .from('educational_articles')
      .update({ is_active: !currentStatus })
      .eq('id', id);
    fetchArticles();
  }

  async function deleteArticle(id: string) {
    if (confirm('Are you sure you want to delete this article?')) {
      await supabase.from('educational_articles').delete().eq('id', id);
      fetchArticles();
    }
  }

  function getCompletionPercentage(data: ArticleFormData): number {
    const fields = [
      data.title_pt, data.title_en, data.intro_pt, data.intro_en,
      data.how_it_works_pt, data.how_it_works_en, data.regulatory_status_pt,
      data.regulatory_status_en, data.risks_pt, data.risks_en,
      data.security_pt, data.security_en, data.red_flags_pt, data.red_flags_en,
      data.consumer_protection_pt, data.consumer_protection_en,
      data.disclaimer_pt, data.disclaimer_en
    ];
    const filledFields = fields.filter(f => f && f.trim().length > 0).length;
    return Math.round((filledFields / fields.length) * 100);
  }

  async function checkCategoriesWithoutArticles() {
    const { data: existingArticles } = await supabase
      .from('educational_articles')
      .select('category_id');

    const categoryIdsWithArticles = new Set(
      existingArticles?.map(article => article.category_id).filter(Boolean)
    );

    const categoriesNeedingArticles = categories.filter(
      category => !categoryIdsWithArticles.has(category.id)
    );

    setCategoriesWithoutArticles(categoriesNeedingArticles);

    if (categoriesNeedingArticles.length > 0) {
      setShowGenerateModal(true);
    }
  }

  async function generateMissingArticles() {
    setGenerating(true);

    try {
      for (const category of categoriesWithoutArticles) {
        const articleData = generateArticleFromCategory(category);

        await supabase.from('educational_articles').insert([{
          ...articleData,
          last_reviewed: new Date().toISOString(),
        }]);
      }

      setShowGenerateModal(false);
      setCategoriesWithoutArticles([]);
      await fetchArticles();
    } catch (error) {
      console.error('Error generating articles:', error);
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Educational Articles</h1>
          <p className="text-gray-600">Create and manage comprehensive educational content for each platform category</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={checkCategoriesWithoutArticles}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-semibold transition"
          >
            <Wand2 className="w-5 h-5" />
            Generate Missing
          </button>
          <button
            onClick={openAddModal}
            className="flex items-center gap-2 px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
          >
            <Plus className="w-5 h-5" />
            Add Article
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-educational-primary mx-auto"></div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Article
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Category
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Reviewed
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {articles.map((article) => (
                <tr key={article.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="font-semibold text-gray-900">{article.title_pt}</div>
                    <div className="text-sm text-gray-500">{article.title_en}</div>
                    <code className="text-xs bg-gray-100 px-2 py-1 rounded mt-1 inline-block">{article.slug}</code>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-700">
                      {(article as any).platform_categories?.name_pt || '-'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(article.last_reviewed).toLocaleDateString('pt-PT')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {article.is_active ? (
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                        Active
                      </span>
                    ) : (
                      <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-semibold">
                        Draft
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => toggleActive(article.id, article.is_active)}
                        className="text-educational-primary hover:text-educational-secondary"
                        title={article.is_active ? 'Deactivate' : 'Activate'}
                      >
                        {article.is_active ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                      <button
                        onClick={() => openEditModal(article)}
                        className="text-educational-secondary hover:text-educational-primary"
                      >
                        <Edit className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => deleteArticle(article.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {articles.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                    No articles yet. Create your first educational article!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-xl max-w-5xl w-full my-8">
            <div className="p-6 border-b sticky top-0 bg-white z-10 rounded-t-xl">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-gray-900">
                  {editingId ? 'Edit Article' : 'Create New Article'}
                </h2>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setCurrentSection('basic')}
                  className={`px-4 py-2 rounded-lg font-semibold transition ${
                    currentSection === 'basic'
                      ? 'bg-educational-primary text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Basic Info
                </button>
                <button
                  onClick={() => setCurrentSection('content')}
                  className={`px-4 py-2 rounded-lg font-semibold transition ${
                    currentSection === 'content'
                      ? 'bg-educational-primary text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Content Sections
                </button>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <AlertCircle className="w-4 h-4 text-educational-info" />
                <span className="text-gray-600">
                  Completion: <span className="font-semibold">{getCompletionPercentage(formData)}%</span>
                </span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              {currentSection === 'basic' && (
                <>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Title (Portuguese) *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.title_pt}
                        onChange={(e) => setFormData({ ...formData, title_pt: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Title (English) *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.title_en}
                        onChange={(e) => {
                          const value = e.target.value;
                          setFormData({
                            ...formData,
                            title_en: value,
                            slug: editingId ? formData.slug : generateSlug(value)
                          });
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Slug *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.slug}
                        onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Category
                      </label>
                      <select
                        value={formData.category_id || ''}
                        onChange={(e) => setFormData({ ...formData, category_id: e.target.value || null })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                      >
                        <option value="">No category</option>
                        {categories.map((cat) => (
                          <option key={cat.id} value={cat.id}>
                            {cat.name_pt} / {cat.name_en}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Author
                      </label>
                      <input
                        type="text"
                        value={formData.author}
                        onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Display Order
                      </label>
                      <input
                        type="number"
                        value={formData.display_order}
                        onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent"
                      />
                    </div>
                  </div>
                </>
              )}

              {currentSection === 'content' && (
                <div className="space-y-6">
                  {[
                    { label: 'Introduction', pt: 'intro_pt', en: 'intro_en' },
                    { label: 'How It Works', pt: 'how_it_works_pt', en: 'how_it_works_en' },
                    { label: 'Regulatory Status', pt: 'regulatory_status_pt', en: 'regulatory_status_en' },
                    { label: 'Risks', pt: 'risks_pt', en: 'risks_en' },
                    { label: 'Security', pt: 'security_pt', en: 'security_en' },
                    { label: 'Red Flags', pt: 'red_flags_pt', en: 'red_flags_en' },
                    { label: 'Consumer Protection', pt: 'consumer_protection_pt', en: 'consumer_protection_en' },
                    { label: 'Disclaimer', pt: 'disclaimer_pt', en: 'disclaimer_en' },
                  ].map((section) => (
                    <div key={section.label} className="border border-gray-200 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                        <BookOpen className="w-4 h-4" />
                        {section.label}
                      </h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">
                            Portuguese
                          </label>
                          <textarea
                            value={formData[section.pt as keyof ArticleFormData] as string}
                            onChange={(e) => setFormData({ ...formData, [section.pt]: e.target.value })}
                            rows={4}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent text-sm"
                            placeholder={`${section.label} em português...`}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">
                            English
                          </label>
                          <textarea
                            value={formData[section.en as keyof ArticleFormData] as string}
                            onChange={(e) => setFormData({ ...formData, [section.en]: e.target.value })}
                            rows={4}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-educational-primary focus:border-transparent text-sm"
                            placeholder={`${section.label} in English...`}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-4 border-t sticky bottom-0 bg-white">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-lg font-semibold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-4 py-2 bg-educational-primary hover:bg-educational-secondary text-white rounded-lg font-semibold transition"
                >
                  <Save className="w-5 h-5" />
                  {editingId ? 'Update' : 'Create'} Article
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showGenerateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full p-6">
            <div className="flex items-start gap-3 mb-4">
              <Wand2 className="w-6 h-6 text-purple-600 flex-shrink-0 mt-1" />
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  Generate Educational Articles
                </h2>
                <p className="text-gray-600 mb-4">
                  {categoriesWithoutArticles.length > 0 ? (
                    <>
                      Found {categoriesWithoutArticles.length} {categoriesWithoutArticles.length === 1 ? 'category' : 'categories'} without articles.
                      Generate simplified educational content for the following:
                    </>
                  ) : (
                    'All categories already have articles. No generation needed!'
                  )}
                </p>
              </div>
            </div>

            {categoriesWithoutArticles.length > 0 && (
              <div className="mb-6 max-h-60 overflow-y-auto">
                <div className="space-y-2">
                  {categoriesWithoutArticles.map((category) => (
                    <div key={category.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-semibold text-gray-900">{category.name_pt}</div>
                        <div className="text-sm text-gray-500">{category.name_en}</div>
                      </div>
                      <span className="text-xs font-medium px-2 py-1 bg-purple-100 text-purple-700 rounded">
                        {category.regulatory_focus}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-blue-900">
                  <p className="font-semibold mb-1">About Generated Articles:</p>
                  <ul className="list-disc list-inside space-y-1 text-blue-800">
                    <li>Content is simplified and consumer-friendly</li>
                    <li>Based on category type and regulatory focus</li>
                    <li>All articles start as drafts for review</li>
                    <li>You can edit them after generation</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => {
                  setShowGenerateModal(false);
                  setCategoriesWithoutArticles([]);
                }}
                disabled={generating}
                className="px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-lg font-semibold transition disabled:opacity-50"
              >
                Cancel
              </button>
              {categoriesWithoutArticles.length > 0 && (
                <button
                  onClick={generateMissingArticles}
                  disabled={generating}
                  className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-semibold transition disabled:opacity-50"
                >
                  {generating ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      Generating...
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-5 h-5" />
                      Generate {categoriesWithoutArticles.length} {categoriesWithoutArticles.length === 1 ? 'Article' : 'Articles'}
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
