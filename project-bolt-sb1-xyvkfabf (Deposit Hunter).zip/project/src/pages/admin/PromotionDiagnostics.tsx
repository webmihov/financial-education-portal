import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { LeadGenPromotion, LeadGenPage, PlatformCategory } from '../../types';
import { AlertCircle, CheckCircle, XCircle, Search, RefreshCw, Users, Bot, Eye, EyeOff } from 'lucide-react';

interface PromotionWithRelations extends LeadGenPromotion {
  lead_gen_pages: LeadGenPage & {
    platform_categories: PlatformCategory | null;
  };
}

interface DiagnosticResult {
  promotion: PromotionWithRelations;
  checks: {
    isActive: { pass: boolean; message: string };
    hasLeadGenPage: { pass: boolean; message: string };
    leadGenPageActive: { pass: boolean; message: string };
    hasTargetLocations: { pass: boolean; message: string };
    hasValidPosition: { pass: boolean; message: string };
    categoryMatch: { pass: boolean; message: string };
  };
  overallStatus: 'healthy' | 'warning' | 'error';
  issues: string[];
  suggestions: string[];
}

interface VisitorStats {
  page_id: string;
  total_visitors: number;
  human_visitors: number;
  bot_visitors: number;
  saw_iframe_count: number;
  hidden_iframe_count: number;
}

export default function PromotionDiagnostics() {
  const [promotions, setPromotions] = useState<PromotionWithRelations[]>([]);
  const [diagnostics, setDiagnostics] = useState<DiagnosticResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'healthy' | 'warning' | 'error'>('all');
  const [visitorStats, setVisitorStats] = useState<Record<string, VisitorStats>>({});

  useEffect(() => {
    fetchPromotions();
    fetchVisitorStats();
  }, []);

  async function fetchPromotions() {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('lead_gen_promotions')
        .select(`
          *,
          lead_gen_pages(
            *,
            platform_categories(*)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const promotionsData = data as PromotionWithRelations[];
      setPromotions(promotionsData);
      runDiagnostics(promotionsData);
    } catch (error) {
      console.error('Error fetching promotions:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchVisitorStats() {
    try {
      const { data, error } = await supabase.rpc('get_visitor_statistics');

      if (error) throw error;

      if (data) {
        const statsMap: Record<string, VisitorStats> = {};
        data.forEach((stat: any) => {
          statsMap[stat.page_id] = {
            page_id: stat.page_id,
            total_visitors: stat.total_visitors,
            human_visitors: stat.human_visitors,
            bot_visitors: stat.bot_visitors,
            saw_iframe_count: stat.saw_iframe_count,
            hidden_iframe_count: stat.hidden_iframe_count,
          };
        });
        setVisitorStats(statsMap);
      }
    } catch (error) {
      console.error('Error fetching visitor stats:', error);
    }
  }

  function runDiagnostics(promotionsData: PromotionWithRelations[]) {
    const results: DiagnosticResult[] = promotionsData.map((promo) => {
      const checks = {
        isActive: {
          pass: promo.is_active,
          message: promo.is_active ? 'Promotion is active' : 'Promotion is inactive',
        },
        hasLeadGenPage: {
          pass: !!promo.lead_gen_pages,
          message: promo.lead_gen_pages
            ? 'Lead Gen Page exists'
            : 'Lead Gen Page missing (orphaned promotion)',
        },
        leadGenPageActive: {
          pass: promo.lead_gen_pages?.is_active || false,
          message: promo.lead_gen_pages?.is_active
            ? 'Lead Gen Page is active'
            : 'Lead Gen Page is inactive',
        },
        hasTargetLocations: {
          pass: promo.target_locations && promo.target_locations.length > 0,
          message:
            promo.target_locations && promo.target_locations.length > 0
              ? `Targets: ${promo.target_locations.join(', ')}`
              : 'No target locations set',
        },
        hasValidPosition: {
          pass: ['top', 'middle', 'bottom', 'sidebar'].includes(promo.placement_position),
          message: `Position: ${promo.placement_position}`,
        },
        categoryMatch: {
          pass: true,
          message: promo.target_category_ids.length > 0
            ? `Targets ${promo.target_category_ids.length} categories`
            : 'No category restrictions (shows on all)',
        },
      };

      const issues: string[] = [];
      const suggestions: string[] = [];

      if (!checks.isActive.pass) {
        issues.push('Promotion is inactive');
        suggestions.push('Activate the promotion to make it visible');
      }

      if (!checks.hasLeadGenPage.pass) {
        issues.push('Orphaned promotion - Lead Gen Page deleted');
        suggestions.push('Delete this promotion or reassign to a valid page');
      }

      if (!checks.leadGenPageActive.pass && checks.hasLeadGenPage.pass) {
        issues.push('Lead Gen Page is inactive');
        suggestions.push('Activate the Lead Gen Page to show this promotion');
      }

      if (!checks.hasTargetLocations.pass) {
        issues.push('No target locations configured');
        suggestions.push('Add at least one target location (landing, article, or category)');
      }

      if (promo.target_category_ids.length > 0 && promo.lead_gen_pages?.category_id) {
        const pageCategory = promo.lead_gen_pages.category_id;
        if (!promo.target_category_ids.includes(pageCategory)) {
          issues.push('Promotion does not target its own page category');
          suggestions.push('Consider adding the page category to target_category_ids');
        }
      }

      let overallStatus: 'healthy' | 'warning' | 'error' = 'healthy';
      if (issues.length > 0) {
        overallStatus = issues.some(i => i.includes('Orphaned') || i.includes('No target')) ? 'error' : 'warning';
      }

      return {
        promotion: promo,
        checks,
        overallStatus,
        issues,
        suggestions,
      };
    });

    setDiagnostics(results);
  }

  const filteredDiagnostics = diagnostics.filter((diag) => {
    const matchesSearch = diag.promotion.promotion_title
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || diag.overallStatus === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const stats = {
    total: diagnostics.length,
    healthy: diagnostics.filter((d) => d.overallStatus === 'healthy').length,
    warning: diagnostics.filter((d) => d.overallStatus === 'warning').length,
    error: diagnostics.filter((d) => d.overallStatus === 'error').length,
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center">
          <RefreshCw className="animate-spin h-8 w-8 text-blue-600" />
          <span className="ml-3 text-lg">Running diagnostics...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Promotion Diagnostics</h1>
        <p className="text-gray-600">Troubleshoot why promotions may not be displaying correctly</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white p-6 rounded-lg shadow border-l-4 border-gray-400">
          <div className="text-3xl font-bold text-gray-900">{stats.total}</div>
          <div className="text-gray-600 text-sm">Total Promotions</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow border-l-4 border-green-500">
          <div className="text-3xl font-bold text-green-600">{stats.healthy}</div>
          <div className="text-gray-600 text-sm">Healthy</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow border-l-4 border-yellow-500">
          <div className="text-3xl font-bold text-yellow-600">{stats.warning}</div>
          <div className="text-gray-600 text-sm">Warnings</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow border-l-4 border-red-500">
          <div className="text-3xl font-bold text-red-600">{stats.error}</div>
          <div className="text-gray-600 text-sm">Errors</div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search promotions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-4 py-2 rounded-lg ${
                filterStatus === 'all'
                  ? 'bg-gray-900 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterStatus('healthy')}
              className={`px-4 py-2 rounded-lg ${
                filterStatus === 'healthy'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Healthy
            </button>
            <button
              onClick={() => setFilterStatus('warning')}
              className={`px-4 py-2 rounded-lg ${
                filterStatus === 'warning'
                  ? 'bg-yellow-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Warning
            </button>
            <button
              onClick={() => setFilterStatus('error')}
              className={`px-4 py-2 rounded-lg ${
                filterStatus === 'error'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Error
            </button>
          </div>
          <button
            onClick={fetchPromotions}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <RefreshCw className="h-4 w-4" />
            Refresh
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {filteredDiagnostics.map((diag) => (
          <div
            key={diag.promotion.id}
            className={`bg-white rounded-lg shadow p-6 border-l-4 ${
              diag.overallStatus === 'healthy'
                ? 'border-green-500'
                : diag.overallStatus === 'warning'
                ? 'border-yellow-500'
                : 'border-red-500'
            }`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-1">
                  {diag.promotion.promotion_title}
                </h3>
                <p className="text-sm text-gray-600">
                  Type: {diag.promotion.promotion_type} | Position: {diag.promotion.placement_position}
                </p>
                {diag.promotion.lead_gen_pages && (
                  <p className="text-sm text-gray-600">
                    Page: {diag.promotion.lead_gen_pages.name}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-2">
                {diag.overallStatus === 'healthy' && (
                  <CheckCircle className="h-6 w-6 text-green-500" />
                )}
                {diag.overallStatus === 'warning' && (
                  <AlertCircle className="h-6 w-6 text-yellow-500" />
                )}
                {diag.overallStatus === 'error' && (
                  <XCircle className="h-6 w-6 text-red-500" />
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
              {Object.entries(diag.checks).map(([key, check]) => (
                <div key={key} className="flex items-start gap-2">
                  {check.pass ? (
                    <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="text-sm">
                    <span className={check.pass ? 'text-gray-700' : 'text-red-700'}>
                      {check.message}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {diag.issues.length > 0 && (
              <div className="mb-4 p-4 bg-red-50 rounded-lg">
                <h4 className="font-semibold text-red-900 mb-2">Issues Found:</h4>
                <ul className="list-disc list-inside text-sm text-red-800 space-y-1">
                  {diag.issues.map((issue, idx) => (
                    <li key={idx}>{issue}</li>
                  ))}
                </ul>
              </div>
            )}

            {diag.suggestions.length > 0 && (
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">Suggestions:</h4>
                <ul className="list-disc list-inside text-sm text-blue-800 space-y-1">
                  {diag.suggestions.map((suggestion, idx) => (
                    <li key={idx}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            )}

            {diag.promotion.lead_gen_pages && visitorStats[diag.promotion.lead_gen_page_id] && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Visitor Statistics for This Page
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">
                      {visitorStats[diag.promotion.lead_gen_page_id].total_visitors}
                    </div>
                    <div className="text-xs text-gray-600">Total Visitors</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {visitorStats[diag.promotion.lead_gen_page_id].human_visitors}
                    </div>
                    <div className="text-xs text-gray-600">Humans</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-600">
                      {visitorStats[diag.promotion.lead_gen_page_id].bot_visitors}
                    </div>
                    <div className="text-xs text-gray-600">Bots</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600 flex items-center justify-center gap-1">
                      <Eye className="w-4 h-4" />
                      {visitorStats[diag.promotion.lead_gen_page_id].saw_iframe_count}
                    </div>
                    <div className="text-xs text-gray-600">Saw Iframe</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-600 flex items-center justify-center gap-1">
                      <EyeOff className="w-4 h-4" />
                      {visitorStats[diag.promotion.lead_gen_page_id].hidden_iframe_count}
                    </div>
                    <div className="text-xs text-gray-600">Hidden</div>
                  </div>
                </div>
                {diag.promotion.lead_gen_pages.manual_hide_iframe && (
                  <div className="mt-3 p-2 bg-yellow-100 border border-yellow-300 rounded text-xs text-yellow-800">
                    <strong>Note:</strong> Manual Bot Mode is enabled - iframe hidden from all visitors
                  </div>
                )}
              </div>
            )}

            <div className="mt-4 text-xs text-gray-500">
              ID: {diag.promotion.id}
            </div>
          </div>
        ))}
      </div>

      {filteredDiagnostics.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <Search className="h-12 w-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-600">No promotions found matching your criteria</p>
        </div>
      )}
    </div>
  );
}
