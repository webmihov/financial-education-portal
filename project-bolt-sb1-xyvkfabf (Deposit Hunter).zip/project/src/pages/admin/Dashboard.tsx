import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { FolderOpen, FileText, MessageSquare, ShieldCheck, Mail, Target, BarChart3 } from 'lucide-react';

export function Dashboard() {
  const [stats, setStats] = useState({
    totalCategories: 0,
    totalArticles: 0,
    activeTestimonials: 0,
    regulatoryBodies: 0,
    leadGenPages: 0,
    activePromotions: 0,
    totalPageViews: 0,
    totalPromotionClicks: 0,
  });

  useEffect(() => {
    fetchStats();
  }, []);

  async function fetchStats() {
    const [categories, articles, testimonials, regulatory, leadPages, promotions, pageViews, promoClicks] = await Promise.all([
      supabase.from('platform_categories').select('*', { count: 'exact' }),
      supabase.from('educational_articles').select('*', { count: 'exact' }),
      supabase.from('user_stories').select('*', { count: 'exact' }).eq('is_active', true),
      supabase.from('regulatory_bodies').select('*', { count: 'exact' }).eq('is_active', true),
      supabase.from('lead_gen_pages').select('*', { count: 'exact' }).eq('is_active', true),
      supabase.from('lead_gen_promotions').select('*', { count: 'exact' }).eq('is_active', true),
      supabase.from('lead_gen_analytics').select('id', { count: 'exact' }).eq('event_type', 'page_view'),
      supabase.from('lead_gen_analytics').select('id', { count: 'exact' }).eq('event_type', 'promotion_click'),
    ]);

    setStats({
      totalCategories: categories.count || 0,
      totalArticles: articles.count || 0,
      activeTestimonials: testimonials.count || 0,
      regulatoryBodies: regulatory.count || 0,
      leadGenPages: leadPages.count || 0,
      activePromotions: promotions.count || 0,
      totalPageViews: pageViews.count || 0,
      totalPromotionClicks: promoClicks.count || 0,
    });
  }

  const contentStats = [
    {
      title: 'Platform Categories',
      value: stats.totalCategories,
      icon: FolderOpen,
      color: 'bg-educational-primary',
    },
    {
      title: 'Educational Articles',
      value: stats.totalArticles,
      icon: FileText,
      color: 'bg-educational-secondary',
    },
    {
      title: 'Active Testimonials',
      value: stats.activeTestimonials,
      icon: MessageSquare,
      color: 'bg-educational-success',
    },
    {
      title: 'Regulatory Bodies',
      value: stats.regulatoryBodies,
      icon: ShieldCheck,
      color: 'bg-educational-info',
    },
  ];

  const leadGenStats = [
    {
      title: 'Lead Gen Pages',
      value: stats.leadGenPages,
      icon: Mail,
      color: 'bg-blue-600',
    },
    {
      title: 'Active Promotions',
      value: stats.activePromotions,
      icon: Target,
      color: 'bg-purple-600',
    },
    {
      title: 'Total Page Views',
      value: stats.totalPageViews,
      icon: BarChart3,
      color: 'bg-green-600',
    },
    {
      title: 'Promotion Clicks',
      value: stats.totalPromotionClicks,
      icon: BarChart3,
      color: 'bg-orange-600',
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard Overview</h1>
        <p className="text-gray-600">Welcome to the DepositHunter Educational Portal CMS</p>
      </div>

      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Content Statistics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {contentStats.map((card, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${card.color} rounded-lg flex items-center justify-center`}>
                  <card.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{card.value}</div>
              <div className="text-sm text-gray-600">{card.title}</div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Lead Generation Analytics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {leadGenStats.map((card, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${card.color} rounded-lg flex items-center justify-center`}>
                  <card.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{card.value}</div>
              <div className="text-sm text-gray-600">{card.title}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <a
              href="/admin/categories"
              className="block px-4 py-3 bg-educational-primary/10 hover:bg-educational-primary/20 text-educational-primary rounded-lg transition font-semibold"
            >
              Manage Categories
            </a>
            <a
              href="/admin/articles"
              className="block px-4 py-3 bg-educational-secondary/10 hover:bg-educational-secondary/20 text-educational-secondary rounded-lg transition font-semibold"
            >
              Manage Articles
            </a>
            <a
              href="/admin/testimonials"
              className="block px-4 py-3 bg-educational-success/10 hover:bg-educational-success/20 text-educational-success rounded-lg transition font-semibold"
            >
              Moderate Testimonials
            </a>
            <a
              href="/admin/compliance"
              className="block px-4 py-3 bg-educational-info/10 hover:bg-educational-info/20 text-educational-info rounded-lg transition font-semibold"
            >
              Compliance Center
            </a>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Compliance Status</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-700">No Affiliate Links</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                Compliant
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Educational Content Only</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                Verified
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-700">SRIJ Information Accurate</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                Updated
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Google Ads Compliant</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                Ready
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
