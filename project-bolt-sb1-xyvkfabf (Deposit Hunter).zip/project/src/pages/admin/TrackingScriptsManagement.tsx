import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Plus, Save, Trash2, Code, AlertCircle } from 'lucide-react';

interface TrackingScript {
  id: string;
  name: string;
  script_type: 'google_analytics' | 'remarketing' | 'custom';
  content: string;
  placement: 'head' | 'body';
  priority: number;
  is_active: boolean;
  requires_consent: boolean;
  consent_category: 'analytics' | 'marketing' | 'preferences' | null;
  created_at: string;
  updated_at: string;
}

export default function TrackingScriptsManagement() {
  const [scripts, setScripts] = useState<TrackingScript[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingScript, setEditingScript] = useState<Partial<TrackingScript> | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetchScripts();
  }, []);

  const fetchScripts = async () => {
    try {
      const { data, error } = await supabase
        .from('tracking_scripts')
        .select('*')
        .order('priority', { ascending: true });

      if (error) throw error;
      setScripts(data || []);
    } catch (error) {
      console.error('Error fetching scripts:', error);
      setMessage({ type: 'error', text: 'Failed to load tracking scripts' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!editingScript) return;

    try {
      if (editingScript.id) {
        const { error } = await supabase
          .from('tracking_scripts')
          .update({
            name: editingScript.name,
            script_type: editingScript.script_type,
            content: editingScript.content,
            placement: editingScript.placement,
            priority: editingScript.priority,
            is_active: editingScript.is_active,
            requires_consent: editingScript.requires_consent,
            consent_category: editingScript.consent_category,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingScript.id);

        if (error) throw error;
        setMessage({ type: 'success', text: 'Script updated successfully' });
      } else {
        const { error } = await supabase
          .from('tracking_scripts')
          .insert([{
            name: editingScript.name,
            script_type: editingScript.script_type,
            content: editingScript.content,
            placement: editingScript.placement || 'head',
            priority: editingScript.priority || 100,
            is_active: editingScript.is_active || false,
            requires_consent: editingScript.requires_consent !== false,
            consent_category: editingScript.consent_category || 'analytics',
          }]);

        if (error) throw error;
        setMessage({ type: 'success', text: 'Script created successfully' });
      }

      setEditingScript(null);
      fetchScripts();
    } catch (error) {
      console.error('Error saving script:', error);
      setMessage({ type: 'error', text: 'Failed to save script' });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this tracking script?')) return;

    try {
      const { error } = await supabase
        .from('tracking_scripts')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setMessage({ type: 'success', text: 'Script deleted successfully' });
      fetchScripts();
    } catch (error) {
      console.error('Error deleting script:', error);
      setMessage({ type: 'error', text: 'Failed to delete script' });
    }
  };

  const handleToggleActive = async (script: TrackingScript) => {
    try {
      const { error } = await supabase
        .from('tracking_scripts')
        .update({ is_active: !script.is_active })
        .eq('id', script.id);

      if (error) throw error;
      setMessage({ type: 'success', text: `Script ${!script.is_active ? 'activated' : 'deactivated'}` });
      fetchScripts();
    } catch (error) {
      console.error('Error toggling script:', error);
      setMessage({ type: 'error', text: 'Failed to update script status' });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-gray-600">Loading tracking scripts...</div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Tracking Scripts</h1>
            <p className="text-gray-600 mt-2">Manage analytics and marketing tracking scripts</p>
          </div>
          <button
            onClick={() => setEditingScript({
              name: '',
              script_type: 'custom',
              content: '',
              placement: 'head',
              priority: 100,
              is_active: false,
              requires_consent: true,
              consent_category: 'analytics',
            })}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <Plus size={20} />
            Add Script
          </button>
        </div>

        {message && (
          <div className={`mb-6 p-4 rounded-lg ${message.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
            <div className="flex items-center gap-2">
              <AlertCircle size={20} />
              {message.text}
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Placement</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {scripts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-4 text-center text-gray-500">
                    No tracking scripts configured yet
                  </td>
                </tr>
              ) : (
                scripts.map((script) => (
                  <tr key={script.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <Code size={16} className="text-gray-400" />
                        <span className="text-sm font-medium text-gray-900">{script.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                        {script.script_type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {script.placement}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {script.priority}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => handleToggleActive(script)}
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          script.is_active
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {script.is_active ? 'Active' : 'Inactive'}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => setEditingScript(script)}
                        className="text-blue-600 hover:text-blue-900 mr-4"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(script.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {editingScript && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">
                  {editingScript.id ? 'Edit Script' : 'Add New Script'}
                </h2>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Script Name
                    </label>
                    <input
                      type="text"
                      value={editingScript.name || ''}
                      onChange={(e) => setEditingScript({ ...editingScript, name: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="e.g., Google Analytics, Facebook Pixel"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Script Type
                    </label>
                    <select
                      value={editingScript.script_type || 'custom'}
                      onChange={(e) => setEditingScript({ ...editingScript, script_type: e.target.value as any })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="google_analytics">Google Analytics</option>
                      <option value="remarketing">Remarketing</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Script Content
                    </label>
                    <textarea
                      value={editingScript.content || ''}
                      onChange={(e) => setEditingScript({ ...editingScript, content: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                      rows={10}
                      placeholder="Paste your tracking script here..."
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Placement
                      </label>
                      <select
                        value={editingScript.placement || 'head'}
                        onChange={(e) => setEditingScript({ ...editingScript, placement: e.target.value as any })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="head">Head</option>
                        <option value="body">Body</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Priority
                      </label>
                      <input
                        type="number"
                        value={editingScript.priority || 100}
                        onChange={(e) => setEditingScript({ ...editingScript, priority: parseInt(e.target.value) })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        min="1"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Consent Category
                    </label>
                    <select
                      value={editingScript.consent_category || 'analytics'}
                      onChange={(e) => setEditingScript({ ...editingScript, consent_category: e.target.value as any })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="analytics">Analytics</option>
                      <option value="marketing">Marketing</option>
                      <option value="preferences">Preferences</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={editingScript.is_active || false}
                        onChange={(e) => setEditingScript({ ...editingScript, is_active: e.target.checked })}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm font-medium text-gray-700">Active</span>
                    </label>

                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={editingScript.requires_consent !== false}
                        onChange={(e) => setEditingScript({ ...editingScript, requires_consent: e.target.checked })}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm font-medium text-gray-700">Requires Consent</span>
                    </label>
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    onClick={handleSave}
                    className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2"
                  >
                    <Save size={20} />
                    Save Script
                  </button>
                  <button
                    onClick={() => setEditingScript(null)}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
