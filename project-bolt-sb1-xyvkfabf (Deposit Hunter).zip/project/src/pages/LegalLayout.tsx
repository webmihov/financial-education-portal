import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { DisclaimerBlock } from '../components/DisclaimerBlock';

interface LegalLayoutProps {
  title: string;
  lastUpdated: string;
  children: React.ReactNode;
}

export function LegalLayout({ title, lastUpdated, children }: LegalLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-6">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-portugal-blue hover:text-portugal-darkGreen transition mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900">{title}</h1>
          <p className="text-sm text-gray-500 mt-2">Last updated: {lastUpdated}</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-md p-8 prose prose-lg max-w-none">
          {children}
        </div>

        <div className="max-w-4xl mx-auto mt-6">
          <DisclaimerBlock />
        </div>
      </div>
    </div>
  );
}
