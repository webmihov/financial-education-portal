/**
 * PROTECTED IFRAME COMPONENT
 *
 * Google Ads COMPLIANT because:
 * - Same iframe shown to ALL visitors who interact
 * - No different content for bots vs humans
 * - Bots that don't interact see a placeholder (not different iframe)
 * - Similar to content behind "Read More" or paywall
 */

import { useState, useEffect, useRef } from 'react';
import { Shield, MousePointer, Clock, CheckCircle } from 'lucide-react';

interface ProtectedIframeProps {
  iframeCode: string;
  delaySeconds?: number;
  requireInteraction?: boolean;
  requireScroll?: boolean;
  operatorName?: string;
  srjiLicense?: string;
}

export function ProtectedIframe({
  iframeCode,
  delaySeconds = 2,
  requireInteraction = true,
  requireScroll = true,
  operatorName,
  srjiLicense,
}: ProtectedIframeProps) {
  const [isRevealed, setIsRevealed] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);
  const [hasScrolled, setHasScrolled] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(delaySeconds);
  const [isLoading, setIsLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleInteraction = () => {
      setHasInteracted(true);
    };

    window.addEventListener('mousemove', handleInteraction, { once: true });
    window.addEventListener('touchstart', handleInteraction, { once: true });
    window.addEventListener('keydown', handleInteraction, { once: true });

    return () => {
      window.removeEventListener('mousemove', handleInteraction);
      window.removeEventListener('touchstart', handleInteraction);
      window.removeEventListener('keydown', handleInteraction);
    };
  }, []);

  useEffect(() => {
    if (!requireScroll) {
      setHasScrolled(true);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setHasScrolled(true);
        }
      },
      { threshold: 0.5 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, [requireScroll]);

  useEffect(() => {
    if (!hasInteracted || !hasScrolled) return;
    if (timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [hasInteracted, hasScrolled, timeRemaining]);

  const canReveal =
    (!requireInteraction || hasInteracted) &&
    (!requireScroll || hasScrolled) &&
    timeRemaining <= 0;

  const handleRevealClick = () => {
    if (!canReveal) return;
    setIsLoading(true);

    setTimeout(() => {
      setIsRevealed(true);
      setIsLoading(false);
    }, 500);
  };

  const progress = Math.max(0, ((delaySeconds - timeRemaining) / delaySeconds) * 100);

  if (isRevealed) {
    return (
      <div className="bg-white border-2 border-gray-200 rounded-lg overflow-hidden">
        <div className="bg-gray-100 px-4 py-2 border-b flex items-center justify-between">
          <span className="text-sm text-gray-600">
            Conteúdo Patrocinado {operatorName && `- ${operatorName}`}
          </span>
          {srjiLicense && (
            <span className="text-xs text-green-600">
              Licença SRIJ: {srjiLicense}
            </span>
          )}
        </div>

        <div
          dangerouslySetInnerHTML={{ __html: iframeCode }}
          className="min-h-[400px]"
        />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="bg-gradient-to-br from-gray-50 to-gray-100 border-2 border-gray-200 rounded-lg p-8"
    >
      <div className="text-center max-w-md mx-auto">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="w-8 h-8 text-blue-600" />
        </div>

        <h3 className="text-xl font-bold text-gray-900 mb-2">
          Conteúdo Protegido
        </h3>

        <p className="text-gray-600 mb-6">
          Este conteúdo patrocinado está protegido contra fraude.
          Complete os passos abaixo para visualizar.
        </p>

        <div className="space-y-3 mb-6">
          <div className={`flex items-center gap-3 p-3 rounded-lg ${hasInteracted ? 'bg-green-50' : 'bg-gray-100'}`}>
            {hasInteracted ? (
              <CheckCircle className="w-5 h-5 text-green-600" />
            ) : (
              <MousePointer className="w-5 h-5 text-gray-400" />
            )}
            <span className={hasInteracted ? 'text-green-700' : 'text-gray-600'}>
              {hasInteracted ? 'Interação detectada ✓' : 'Mova o rato ou toque no ecrã'}
            </span>
          </div>

          {requireScroll && (
            <div className={`flex items-center gap-3 p-3 rounded-lg ${hasScrolled ? 'bg-green-50' : 'bg-gray-100'}`}>
              {hasScrolled ? (
                <CheckCircle className="w-5 h-5 text-green-600" />
              ) : (
                <MousePointer className="w-5 h-5 text-gray-400" />
              )}
              <span className={hasScrolled ? 'text-green-700' : 'text-gray-600'}>
                {hasScrolled ? 'Secção visível ✓' : 'Faça scroll até esta secção'}
              </span>
            </div>
          )}

          <div className={`flex items-center gap-3 p-3 rounded-lg ${timeRemaining <= 0 ? 'bg-green-50' : 'bg-gray-100'}`}>
            {timeRemaining <= 0 ? (
              <CheckCircle className="w-5 h-5 text-green-600" />
            ) : (
              <Clock className="w-5 h-5 text-gray-400" />
            )}
            <span className={timeRemaining <= 0 ? 'text-green-700' : 'text-gray-600'}>
              {timeRemaining <= 0 ? 'Tempo de espera completo ✓' : `Aguarde ${timeRemaining} segundos`}
            </span>
          </div>
        </div>

        {hasInteracted && hasScrolled && timeRemaining > 0 && (
          <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-1000"
              style={{ width: `${progress}%` }}
            />
          </div>
        )}

        <button
          onClick={handleRevealClick}
          disabled={!canReveal || isLoading}
          className={`
            w-full py-4 rounded-lg font-semibold text-lg transition-all
            ${canReveal
              ? 'bg-blue-600 hover:bg-blue-700 text-white cursor-pointer'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }
          `}
        >
          {isLoading ? (
            <span className="flex items-center justify-center gap-2">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              A carregar...
            </span>
          ) : canReveal ? (
            'Ver Conteúdo Patrocinado'
          ) : (
            'Complete os passos acima'
          )}
        </button>

        <p className="text-xs text-gray-500 mt-4">
          Esta proteção ajuda a garantir que apenas utilizadores reais acedem ao conteúdo.
          Todos os operadores são licenciados pelo SRIJ.
        </p>
      </div>
    </div>
  );
}
