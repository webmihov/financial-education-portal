import { useState, useMemo } from 'react';
import { X, Wand2, RotateCcw, Sparkles, AlertCircle } from 'lucide-react';
import { PromotionType, PlacementPosition } from '../../types';
import {
  PROMOTION_TYPE_LABELS,
  PLACEMENT_POSITION_LABELS,
  isValidPositionForType,
  VALID_POSITIONS_BY_TYPE,
} from '../../utils/leadGenDefaults';

export interface PromotionDistributionConfig {
  type: PromotionType;
  position: PlacementPosition;
  count: number;
}

interface GeneratorConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (config: PromotionDistributionConfig[]) => void;
  isGenerating: boolean;
}

const VISUAL_WEIGHT: Record<PromotionType, 'small' | 'standard' | 'large'> = {
  text_ad: 'small',
  button: 'small',
  inline_card: 'standard',
  banner: 'large',
};

const NATURAL_DEFAULTS: PromotionDistributionConfig[] = [
  { type: 'text_ad', position: 'top', count: 1 },
  { type: 'inline_card', position: 'middle', count: 1 },
  { type: 'text_ad', position: 'bottom', count: 1 },
];

const PRESET_CONFIGS = {
  minimal: [
    { type: 'inline_card' as PromotionType, position: 'middle' as PlacementPosition, count: 1 },
    { type: 'text_ad' as PromotionType, position: 'bottom' as PlacementPosition, count: 1 },
  ],
  balanced: [
    { type: 'text_ad' as PromotionType, position: 'top' as PlacementPosition, count: 1 },
    { type: 'inline_card' as PromotionType, position: 'middle' as PlacementPosition, count: 2 },
    { type: 'text_ad' as PromotionType, position: 'bottom' as PlacementPosition, count: 1 },
  ],
  aggressive: [
    { type: 'banner' as PromotionType, position: 'top' as PlacementPosition, count: 1 },
    { type: 'inline_card' as PromotionType, position: 'middle' as PlacementPosition, count: 2 },
    { type: 'button' as PromotionType, position: 'middle' as PlacementPosition, count: 1 },
    { type: 'text_ad' as PromotionType, position: 'bottom' as PlacementPosition, count: 2 },
  ],
};

export function GeneratorConfigModal({
  isOpen,
  onClose,
  onGenerate,
  isGenerating,
}: GeneratorConfigModalProps) {
  const [config, setConfig] = useState<Map<string, number>>(() => {
    const map = new Map<string, number>();
    NATURAL_DEFAULTS.forEach(item => {
      const key = `${item.type}-${item.position}`;
      map.set(key, item.count);
    });
    return map;
  });

  const allValidCombinations = useMemo(() => {
    const combinations: Array<{ type: PromotionType; position: PlacementPosition }> = [];
    const types: PromotionType[] = ['banner', 'inline_card', 'text_ad', 'button'];
    const positions: PlacementPosition[] = ['top', 'middle', 'bottom', 'sidebar'];

    types.forEach(type => {
      positions.forEach(position => {
        if (isValidPositionForType(type, position)) {
          combinations.push({ type, position });
        }
      });
    });

    return combinations;
  }, []);

  const totalCount = useMemo(() => {
    return Array.from(config.values()).reduce((sum, count) => sum + count, 0);
  }, [config]);

  const warnings = useMemo(() => {
    const warns: string[] = [];
    const bannerCount = Array.from(config.entries())
      .filter(([key]) => key.startsWith('banner-'))
      .reduce((sum, [, count]) => sum + count, 0);

    if (bannerCount > 1) {
      warns.push('Multiple banners may overwhelm the page visually');
    }

    if (totalCount > 10) {
      warns.push('More than 10 promotions per page may reduce effectiveness');
    }

    const positionCounts = new Map<PlacementPosition, number>();
    config.forEach((count, key) => {
      const position = key.split('-')[1] as PlacementPosition;
      positionCounts.set(position, (positionCounts.get(position) || 0) + count);
    });

    positionCounts.forEach((count, position) => {
      if (count > 3) {
        warns.push(`${PLACEMENT_POSITION_LABELS[position]} has ${count} promotions (recommended max: 3)`);
      }
    });

    return warns;
  }, [config, totalCount]);

  const getCount = (type: PromotionType, position: PlacementPosition): number => {
    const key = `${type}-${position}`;
    return config.get(key) || 0;
  };

  const setCount = (type: PromotionType, position: PlacementPosition, count: number) => {
    const key = `${type}-${position}`;
    const newConfig = new Map(config);
    if (count === 0) {
      newConfig.delete(key);
    } else {
      newConfig.set(key, count);
    }
    setConfig(newConfig);
  };

  const applyPreset = (preset: 'natural' | 'minimal' | 'balanced' | 'aggressive') => {
    const newConfig = new Map<string, number>();
    const presetData = preset === 'natural' ? NATURAL_DEFAULTS : PRESET_CONFIGS[preset];

    presetData.forEach(item => {
      const key = `${item.type}-${item.position}`;
      newConfig.set(key, item.count);
    });

    setConfig(newConfig);
  };

  const handleGenerate = () => {
    const distributionConfig: PromotionDistributionConfig[] = [];

    config.forEach((count, key) => {
      const [type, position] = key.split('-') as [PromotionType, PlacementPosition];
      distributionConfig.push({ type, position, count });
    });

    onGenerate(distributionConfig);
  };

  if (!isOpen) return null;

  const positionGroups: Record<PlacementPosition, Array<{ type: PromotionType; position: PlacementPosition }>> = {
    top: [],
    middle: [],
    bottom: [],
    sidebar: [],
  };

  allValidCombinations.forEach(combo => {
    positionGroups[combo.position].push(combo);
  });

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-lg w-full max-w-5xl my-8">
        <div className="flex justify-between items-center p-6 border-b">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Configure Promotion Generator</h2>
            <p className="text-sm text-gray-600 mt-1">
              Choose how many promotions to create for each type and position
            </p>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-6 flex flex-wrap gap-2">
            <button
              onClick={() => applyPreset('natural')}
              className="flex items-center gap-2 px-4 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition"
            >
              <Sparkles className="w-4 h-4" />
              Natural (3)
            </button>
            <button
              onClick={() => applyPreset('minimal')}
              className="flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition"
            >
              <RotateCcw className="w-4 h-4" />
              Minimal (2)
            </button>
            <button
              onClick={() => applyPreset('balanced')}
              className="flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition"
            >
              <Wand2 className="w-4 h-4" />
              Balanced (4)
            </button>
            <button
              onClick={() => applyPreset('aggressive')}
              className="flex items-center gap-2 px-4 py-2 bg-orange-100 text-orange-800 rounded-lg hover:bg-orange-200 transition"
            >
              <Wand2 className="w-4 h-4" />
              Aggressive (6)
            </button>
          </div>

          <div className="grid lg:grid-cols-3 gap-6 mb-6">
            <div className="lg:col-span-2 space-y-6">
              {(['top', 'middle', 'bottom', 'sidebar'] as PlacementPosition[]).map(position => {
                const combos = positionGroups[position];
                if (combos.length === 0) return null;

                return (
                  <div key={position} className="border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-4">
                      {PLACEMENT_POSITION_LABELS[position]}
                    </h3>
                    <div className="space-y-4">
                      {combos.map(({ type, position }) => {
                        const count = getCount(type, position);
                        const weight = VISUAL_WEIGHT[type];
                        const isManualOnly = type === 'banner' && position === 'top';

                        return (
                          <div key={`${type}-${position}`} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <span className="text-sm font-medium text-gray-700">
                                  {PROMOTION_TYPE_LABELS[type]}
                                </span>
                                <span
                                  className={`text-xs px-2 py-1 rounded-full ${
                                    weight === 'small'
                                      ? 'bg-green-100 text-green-800'
                                      : weight === 'standard'
                                      ? 'bg-blue-100 text-blue-800'
                                      : 'bg-orange-100 text-orange-800'
                                  }`}
                                >
                                  {weight}
                                </span>
                                {isManualOnly && (
                                  <span className="text-xs px-2 py-1 rounded-full bg-yellow-100 text-yellow-800">
                                    Consider manual
                                  </span>
                                )}
                              </div>
                              <span className="text-sm font-semibold text-gray-900 w-8 text-right">
                                {count}
                              </span>
                            </div>
                            <input
                              type="range"
                              min="0"
                              max="5"
                              value={count}
                              onChange={(e) => setCount(type, position, parseInt(e.target.value))}
                              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-educational-primary"
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="space-y-4">
              <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <h3 className="font-semibold text-gray-900 mb-3">Summary</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Total Promotions</span>
                    <span className="text-2xl font-bold text-educational-primary">{totalCount}</span>
                  </div>
                  <div className="pt-3 border-t border-gray-200 space-y-2">
                    {(['top', 'middle', 'bottom', 'sidebar'] as PlacementPosition[]).map(position => {
                      const positionCount = Array.from(config.entries())
                        .filter(([key]) => key.endsWith(`-${position}`))
                        .reduce((sum, [, count]) => sum + count, 0);

                      if (positionCount === 0) return null;

                      return (
                        <div key={position} className="flex justify-between text-sm">
                          <span className="text-gray-600">{PLACEMENT_POSITION_LABELS[position]}</span>
                          <span className="font-medium text-gray-900">{positionCount}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {warnings.length > 0 && (
                <div className="border border-yellow-200 rounded-lg p-4 bg-yellow-50">
                  <div className="flex items-start gap-2 mb-2">
                    <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <h3 className="font-semibold text-yellow-900">Warnings</h3>
                  </div>
                  <ul className="space-y-1">
                    {warnings.map((warning, idx) => (
                      <li key={idx} className="text-sm text-yellow-800">
                        {warning}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="border border-blue-200 rounded-lg p-4 bg-blue-50">
                <h3 className="font-semibold text-blue-900 mb-2 text-sm">Quick Guide</h3>
                <ul className="text-xs text-blue-800 space-y-1">
                  <li>• Small: Subtle, text-based promotions</li>
                  <li>• Standard: Engaging card-style promotions</li>
                  <li>• Large: High-impact banner promotions</li>
                  <li>• Recommended max: 3 per position</li>
                  <li>• Natural preset creates curated look</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center pt-4 border-t">
            <div className="text-sm text-gray-600">
              {totalCount === 0 ? (
                <span className="text-red-600 font-medium">Select at least one promotion to generate</span>
              ) : (
                <span>
                  Ready to generate <strong>{totalCount}</strong> promotion{totalCount !== 1 ? 's' : ''} per page
                </span>
              )}
            </div>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={onClose}
                disabled={isGenerating}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleGenerate}
                disabled={isGenerating || totalCount === 0}
                className="flex items-center gap-2 bg-educational-primary text-white px-6 py-2 rounded-lg hover:bg-educational-secondary transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isGenerating ? (
                  <>
                    <Wand2 className="w-5 h-5 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-5 h-5" />
                    Generate Promotions
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
