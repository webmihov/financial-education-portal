export function DisclaimerBlock() {
  return (
    <div className="bg-yellow-500/90 text-gray-900 py-4 px-6 rounded-lg">
      <div className="max-w-5xl mx-auto">
        <p className="font-bold text-sm mb-2">
          <span className="font-extrabold">PT:</span> Este é um portal estritamente informativo e educacional. Não oferecemos serviços de jogos de azar nem temos parcerias com operadores. O jogo pode causar dependência - jogue com responsabilidade. +18 anos.
        </p>
        <p className="font-bold text-sm">
          <span className="font-extrabold">EN:</span> This is a strictly informational and educational portal. We do not offer gambling services nor hold partnerships with operators. Gambling can be addictive - please gamble responsibly. 18+ only.
        </p>
      </div>
    </div>
  );
}
