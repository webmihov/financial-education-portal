import { BookOpen, Shield, AlertTriangle } from 'lucide-react';

export function Hero() {
  return (
    <section className="bg-gradient-to-br from-educational-lightBlue to-white py-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap items-center justify-center gap-8 mb-12">
          <div className="w-20 h-20 rounded-full bg-educational-primary/10 flex items-center justify-center">
            <BookOpen className="w-10 h-10 text-educational-primary" />
          </div>
          <div className="w-20 h-20 rounded-full bg-educational-success/10 flex items-center justify-center">
            <Shield className="w-10 h-10 text-educational-success" />
          </div>
          <div className="w-20 h-20 rounded-full bg-educational-warning/10 flex items-center justify-center">
            <AlertTriangle className="w-10 h-10 text-educational-warning" />
          </div>
        </div>

        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Depósitos e Levantamentos: Guia Educacional
          </h1>
          <p className="text-xl text-gray-600 mb-4">
            Aprenda a usar instrumentos financeiros com segurança em serviços online
          </p>
          <p className="text-lg text-gray-600 mb-8">
            Portal educacional sobre bancos, e-commerce, jogos licenciados SRIJ,
            criptomoedas e outros serviços - com foco em proteção do consumidor português
          </p>

          <div className="bg-yellow-50 border-2 border-educational-warning rounded-lg p-6 mb-8">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-educational-warning flex-shrink-0 mt-1" />
              <div className="text-left">
                <h3 className="font-bold text-gray-900 mb-2">
                  Divulgação Importante
                </h3>
                <p className="text-gray-700 text-sm">
                  Este site é um recurso educacional. Não somos consultores financeiros.
                  Podemos receber comissões de afiliados quando clica em links de parceiros.
                  O conteúdo é apenas informativo e não constitui aconselhamento financeiro.
                </p>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4 text-center">
            <div className="bg-white rounded-lg p-4 shadow-md">
              <div className="text-educational-primary font-bold text-2xl mb-2">PT</div>
              <div className="text-sm text-gray-600">Foco em Portugal</div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-md">
              <div className="text-educational-primary font-bold text-2xl mb-2">24/7</div>
              <div className="text-sm text-gray-600">Conteúdo Educacional</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
