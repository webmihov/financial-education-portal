import { useState, useEffect } from 'react';
import { Website } from '../../types';
import { supabase } from '../../lib/supabase';
import { Star, ChevronDown, BookOpen, Shield, CheckCircle } from 'lucide-react';
import { trackInteraction } from '../../utils/analytics';

export function SpinGame() {
  const [websites, setWebsites] = useState<Website[]>([]);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<Website | null>(null);
  const [slots, setSlots] = useState([0, 0, 0]);

  useEffect(() => {
    fetchWebsites();
  }, []);

  async function fetchWebsites() {
    const { data } = await supabase
      .from('websites')
      .select('*')
      .eq('is_active', true)
      .order('display_order');

    if (data) {
      setWebsites(data);
    }
  }


  const handleSpin = async () => {
    if (spinning || websites.length === 0) return;

    setSpinning(true);
    setResult(null);
    trackInteraction('educational_showcase_start');

    const spinDuration = 2000;
    const intervalTime = 100;
    let elapsed = 0;

    const interval = setInterval(() => {
      setSlots([
        Math.floor(Math.random() * websites.length),
        Math.floor(Math.random() * websites.length),
        Math.floor(Math.random() * websites.length),
      ]);

      elapsed += intervalTime;

      if (elapsed >= spinDuration) {
        clearInterval(interval);
        const finalIndex = Math.floor(Math.random() * websites.length);
        setSlots([finalIndex, finalIndex, finalIndex]);
        setResult(websites[finalIndex]);
        setSpinning(false);
        trackInteraction('educational_showcase_result', websites[finalIndex].id);
      }
    }, intervalTime);
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 mb-4 px-4 py-2 bg-educational-primary/10 border border-educational-primary/30 rounded-lg">
              <BookOpen className="w-5 h-5 text-educational-accent" />
              <span className="text-sm font-semibold text-educational-accent">Interactive Learning Tool</span>
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Educational Showcase: Portuguese Licensed Platforms
            </h2>
            <p className="text-gray-600">
              Learn about SRIJ-licensed platforms through interactive demonstration
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Educational demonstration - not a game of chance
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="flex justify-center gap-4 mb-8">
              {slots.map((_, i) => (
                <div
                  key={i}
                  className={`w-24 h-24 bg-gradient-to-br from-educational-primary to-educational-accent rounded-lg flex items-center justify-center ${
                    spinning ? 'animate-pulse' : ''
                  }`}
                >
                  {i === 0 && <BookOpen className="w-12 h-12 text-white" />}
                  {i === 1 && <Shield className="w-12 h-12 text-white" />}
                  {i === 2 && <CheckCircle className="w-12 h-12 text-white" />}
                </div>
              ))}
            </div>

            <div className="text-center mb-6">
              <button
                onClick={handleSpin}
                disabled={spinning}
                className={`px-12 py-4 rounded-lg font-bold text-lg transition-all ${
                  spinning
                    ? 'bg-gray-300 cursor-not-allowed'
                    : 'bg-educational-accent hover:bg-educational-accent/90 text-white shadow-lg hover:shadow-xl'
                }`}
              >
                {spinning ? 'Loading Educational Content...' : 'Show Random Licensed Platform'}
              </button>
            </div>

            {result && (
              <div className="mt-8 p-6 bg-gradient-to-br from-educational-primary/5 to-white rounded-lg border-2 border-educational-primary">
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="w-5 h-5 text-educational-accent" />
                  <span className="text-xs font-semibold text-educational-accent uppercase">SRIJ Licensed Platform</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{result.name}</h3>
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < Math.floor(result.rating)
                            ? 'fill-educational-accent text-educational-accent'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="font-semibold text-gray-700">{result.rating}/5</span>
                </div>
                <div className="mb-4 p-3 bg-gray-50 rounded">
                  <p className="text-sm text-gray-700"><strong>Regulatory Status:</strong> {result.status_badge}</p>
                  <p className="text-xs text-gray-600 mt-1">This platform is officially licensed and regulated by SRIJ (Serviço de Regulação e Inspeção de Jogos)</p>
                </div>
                <a
                  href="#comparison"
                  className="inline-flex items-center gap-2 text-educational-accent hover:text-educational-accent/80 font-semibold"
                >
                  View Complete Educational Comparison
                  <ChevronDown className="w-4 h-4" />
                </a>
              </div>
            )}

            <div className="mt-6 p-4 bg-educational-primary/10 border border-educational-primary/30 rounded-lg">
              <p className="text-sm text-gray-700 text-center">
                <strong>Educational Disclaimer:</strong> This interactive tool randomly showcases SRIJ-licensed platforms
                for educational purposes only. It is not a game of chance and does not constitute an endorsement or
                recommendation. Visit the comparison table below for complete factual information about all licensed platforms.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
