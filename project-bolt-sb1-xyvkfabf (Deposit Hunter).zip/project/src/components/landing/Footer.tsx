import { BookOpen, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';
import { DisclaimerBlock } from '../DisclaimerBlock';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <BookOpen className="w-6 h-6 text-educational-accent" />
              <span className="font-bold text-white">Depósitos e Levantamentos</span>
            </div>
            <p className="text-sm">
              Portal educacional sobre segurança financeira e proteção do consumidor
              em serviços online.
            </p>
            <p className="text-xs mt-3 text-gray-400">
              Pode conter links de afiliados
            </p>
          </div>

          <div>
            <h3 className="font-bold text-white mb-4">Legal</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/terms" className="hover:text-educational-accent transition">
                  Termos e Condições
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-educational-accent transition">
                  Política de Privacidade
                </Link>
              </li>
              <li>
                <Link to="/cookie-policy" className="hover:text-educational-accent transition">
                  Política de Cookies
                </Link>
              </li>
              <li>
                <Link to="/disclaimer" className="hover:text-educational-accent transition">
                  Aviso Legal
                </Link>
              </li>
              <li>
                <Link to="/affiliate-disclosure" className="hover:text-educational-accent transition">
                  Divulgação de Afiliados
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-educational-accent transition">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link to="/editorial-standards" className="hover:text-educational-accent transition">
                  Normas Editoriais
                </Link>
              </li>
              <li>
                <Link to="/accessibility" className="hover:text-educational-accent transition">
                  Acessibilidade
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-white mb-4">Autoridades Portuguesas</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="https://www.srij.turismodeportugal.pt"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-educational-accent hover:text-educational-accent/80 transition"
                >
                  SRIJ - Regulação de Jogos
                </a>
              </li>
              <li>
                <span className="text-gray-400">Banco de Portugal</span>
              </li>
              <li>
                <span className="text-gray-400">CMVM</span>
              </li>
              <li>
                <a
                  href="https://www.consumidor.gov.pt"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-educational-accent hover:text-educational-accent/80 transition"
                >
                  Portal do Consumidor
                </a>
              </li>
              <li>
                <span className="text-gray-400">Livro de Reclamações</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-white mb-4">Contacto</h3>
            <p className="text-sm mb-2 flex items-center gap-2">
              <Mail className="w-4 h-4" />
              info@deposithunter.com
            </p>
            <p className="text-sm">
              Para questões sobre este recurso educacional.
            </p>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8">
          <div className="bg-educational-primary/10 border border-educational-primary/30 rounded-lg p-4 mb-6">
            <p className="text-sm text-educational-accent font-semibold mb-2">
              Divulgação de Afiliados
            </p>
            <p className="text-sm text-gray-300">
              Este é um portal educacional. Podemos receber comissões quando clica em links de
              parceiros. Todo o conteúdo é puramente informativo e não constitui aconselhamento
              financeiro. Para decisões financeiras, consulte sempre profissionais qualificados.
            </p>
          </div>

          <div className="bg-red-900/20 border-2 border-red-600/50 rounded-lg p-6 mb-6">
            <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
              <span className="text-2xl">⚠️</span> Jogo Responsável
            </h3>
            <div className="space-y-3 text-sm text-gray-200">
              <p className="font-semibold text-red-400">
                O jogo pode causar dependência. Jogue com moderação.
              </p>
              <p className="font-medium">
                Se precisar de ajuda: <span className="font-bold text-white">Linha Vida - 808 200 204</span>
              </p>
              <p className="font-medium">
                Apenas para maiores de 18 anos.
              </p>
              <div className="border-t border-red-600/30 pt-3 mt-3">
                <p className="font-bold text-white mb-1 text-base">
                  +18 | Este site é destinado a maiores de 18 anos
                </p>
              </div>
              <div className="border-t border-red-600/30 pt-3 mt-3">
                <p className="text-gray-300">
                  Regulado pelo SRIJ - Serviço de Regulação e Inspeção de Jogos
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
            <div className="flex items-center gap-4">
              <span>© 2024 DepositHunter - Portal Educacional</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-xs text-gray-400">
                Portal educacional
              </span>
              <Link to="/admin" className="text-xs text-gray-500 hover:text-gray-400">
                Admin
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <DisclaimerBlock />
        </div>
      </div>
    </footer>
  );
}
