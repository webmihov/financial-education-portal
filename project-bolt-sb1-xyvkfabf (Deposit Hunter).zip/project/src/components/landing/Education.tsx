import { BookOpen, AlertCircle, ExternalLink, HelpCircle, Shield } from 'lucide-react';
import { useState } from 'react';

export function Education() {
  const [openFAQ, setOpenFAQ] = useState<number | null>(0);

  const tips = [
    'Verifique sempre se a plataforma tem licença das autoridades portuguesas competentes',
    'Para jogos online, confirme o registo no SRIJ antes de qualquer depósito',
    'Leia atentamente os termos e condições, especialmente sobre levantamentos',
    'Nunca deposite mais do que pode perder sem comprometer suas finanças',
    'Use métodos de pagamento seguros e rastreáveis (Multibanco, MB WAY, SEPA)',
    'Guarde sempre comprovantes de todas as transações',
  ];

  const faqs = [
    {
      question: 'O que é o SRIJ e porque é importante?',
      answer:
        'O SRIJ (Serviço de Regulação e Inspeção de Jogos) é a entidade portuguesa responsável pela regulação do jogo online em Portugal. Qualquer plataforma de jogos online legal em Portugal deve estar licenciada pelo SRIJ. Pode verificar o registo público no site oficial do SRIJ.',
    },
    {
      question: 'Como posso verificar se uma plataforma é legal em Portugal?',
      answer:
        'Para jogos online, aceda ao registo público do SRIJ (www.srij.turismodeportugal.pt). Para bancos, consulte a lista do Banco de Portugal. Para investimentos, verifique no CMVM. Nunca confie apenas nas informações do próprio site da plataforma.',
    },
    {
      question: 'Que riscos existem ao fazer depósitos online?',
      answer:
        'Os principais riscos incluem: perda total ou parcial dos fundos depositados, plataformas não licenciadas ou fraudulentas, dificuldades em fazer levantamentos, falta de proteção legal em plataformas internacionais não autorizadas, e problemas com métodos de pagamento inseguros.',
    },
    {
      question: 'Onde posso fazer uma reclamação se tiver problemas?',
      answer:
        'Para plataformas licenciadas em Portugal, pode usar o Livro de Reclamações Online (www.livroreclamacoes.pt). Para questões bancárias, contacte o Banco de Portugal. Para jogos online, pode reclamar ao SRIJ. Para outros serviços, o Portal do Consumidor pode orientar sobre os seus direitos.',
    },
  ];

  return (
    <section id="education" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Como Proteger-se ao Fazer Depósitos Online
            </h2>
            <p className="text-gray-600">
              Informação essencial para tomar decisões seguras e informadas
            </p>
          </div>

          <div className="bg-educational-lightBlue rounded-xl p-8 mb-12">
            <div className="flex items-start gap-3 mb-4">
              <BookOpen className="w-6 h-6 text-educational-primary flex-shrink-0 mt-1" />
              <h3 className="text-xl font-bold text-gray-900">Dicas de Segurança Essenciais</h3>
            </div>
            <ul className="space-y-3">
              {tips.map((tip, index) => (
                <li key={index} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-educational-success text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </span>
                  <span className="text-gray-700">{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="mb-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
              <HelpCircle className="w-6 h-6 text-educational-primary" />
              Perguntas Frequentes
            </h3>
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <div
                  key={index}
                  className="border border-gray-200 rounded-lg overflow-hidden"
                >
                  <button
                    onClick={() => setOpenFAQ(openFAQ === index ? null : index)}
                    className="w-full px-6 py-4 text-left font-semibold text-gray-900 hover:bg-gray-50 transition flex items-center justify-between"
                  >
                    {faq.question}
                    <span className={`transform transition-transform ${openFAQ === index ? 'rotate-180' : ''}`}>
                      ▼
                    </span>
                  </button>
                  {openFAQ === index && (
                    <div className="px-6 py-4 bg-gray-50 text-gray-700">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 border-2 border-educational-primary rounded-xl p-6 mb-8">
            <div className="flex items-start gap-3">
              <Shield className="w-6 h-6 text-educational-primary flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-gray-900 mb-2">
                  Autoridades Reguladoras Portuguesas
                </h3>
                <p className="text-gray-700 mb-3">
                  Estas são as entidades oficiais que regulam e fiscalizam serviços online em Portugal.
                  Verifique sempre a licença antes de depositar.
                </p>
                <ul className="space-y-2">
                  <li>
                    <a
                      href="https://www.srij.turismodeportugal.pt"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-educational-primary hover:underline flex items-center gap-1"
                    >
                      <strong>SRIJ</strong> - Regulação de Jogos Online
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </li>
                  <li>
                    <span className="text-gray-700">
                      <strong>Banco de Portugal</strong> - Supervisão Bancária
                    </span>
                  </li>
                  <li>
                    <span className="text-gray-700">
                      <strong>CMVM</strong> - Mercados de Capitais
                    </span>
                  </li>
                  <li>
                    <a
                      href="https://www.consumidor.gov.pt"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-educational-primary hover:underline flex items-center gap-1"
                    >
                      <strong>Portal do Consumidor</strong> - Proteção ao Consumidor
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </li>
                  <li>
                    <span className="text-gray-700">
                      <strong>Livro de Reclamações</strong> - Sistema de Reclamações
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-educational-warning rounded-xl p-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-6 h-6 text-educational-warning flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-gray-900 mb-2">
                  Aviso Importante
                </h3>
                <p className="text-gray-700 text-sm">
                  Este site é um recurso educacional independente. Não promovemos nem recomendamos
                  nenhuma plataforma específica. Sempre faça sua própria pesquisa e consulte
                  profissionais qualificados antes de tomar decisões financeiras. Depósitos em
                  plataformas online sempre comportam riscos de perda.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
