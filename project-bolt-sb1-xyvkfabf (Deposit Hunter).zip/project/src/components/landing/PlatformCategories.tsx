import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlatformCategory } from '../../types';
import { supabase } from '../../lib/supabase';
import {
  Building,
  ShoppingCart,
  Gamepad2,
  Ticket,
  Bitcoin,
  Briefcase,
  Tv,
  BookOpen
} from 'lucide-react';

const iconMap: Record<string, any> = {
  'building': Building,
  'shopping-cart': ShoppingCart,
  'gamepad-2': Gamepad2,
  'ticket': Ticket,
  'bitcoin': Bitcoin,
  'briefcase': Briefcase,
  'tv': Tv,
};

export function PlatformCategories() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState<PlatformCategory[]>([]);
  const [articleMap, setArticleMap] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchCategoriesAndArticles();
  }, []);

  async function fetchCategoriesAndArticles() {
    const { data: categoriesData } = await supabase
      .from('platform_categories')
      .select('*')
      .eq('is_active', true)
      .order('display_order');

    if (categoriesData) {
      setCategories(categoriesData);

      const { data: articlesData } = await supabase
        .from('educational_articles')
        .select('category_id, slug')
        .eq('is_active', true);

      if (articlesData) {
        const mapping: Record<string, string> = {};
        articlesData.forEach((article) => {
          if (article.category_id) {
            mapping[article.category_id] = article.slug;
          }
        });
        setArticleMap(mapping);
      }
    }
  }

  const handleLearnMore = (categoryId: string) => {
    const articleSlug = articleMap[categoryId];
    if (articleSlug) {
      navigate(`/guia/${articleSlug}`);
    }
  };

  const getIcon = (iconName: string) => {
    const Icon = iconMap[iconName] || BookOpen;
    return Icon;
  };

  return (
    <section id="categories" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Categorias de Serviços Online
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Aprenda sobre depósitos e levantamentos em diferentes tipos de plataformas online.
            Cada categoria inclui informação sobre regulação, segurança e proteção do consumidor.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto mb-12">
          {categories.map((category) => {
            const Icon = getIcon(category.icon_name);
            return (
              <div
                key={category.id}
                className="bg-white border-2 border-gray-200 rounded-xl p-6 hover:border-educational-primary hover:shadow-xl transition-all"
              >
                <div className="text-center mb-4">
                  <div className="w-16 h-16 mx-auto bg-educational-lightBlue rounded-full flex items-center justify-center mb-3">
                    <Icon className="w-8 h-8 text-educational-primary" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{category.name_pt}</h3>
                  <p className="text-sm text-gray-500 mb-3">{category.name_en}</p>
                </div>

                <p className="text-sm text-gray-700 mb-4 text-center">
                  {category.description_pt}
                </p>

                {category.regulatory_focus && (
                  <div className="mt-4 p-3 bg-educational-lightBlue rounded-lg">
                    <p className="text-xs font-semibold text-educational-darkBlue text-center">
                      Regulação: {category.regulatory_focus}
                    </p>
                  </div>
                )}

                <div className="mt-4 text-center">
                  <button
                    onClick={() => handleLearnMore(category.id)}
                    disabled={!articleMap[category.id]}
                    className={`font-semibold text-sm inline-flex items-center gap-1 transition-colors ${
                      articleMap[category.id]
                        ? 'text-educational-primary hover:text-educational-secondary cursor-pointer'
                        : 'text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    <BookOpen className="w-4 h-4" />
                    Aprender Mais
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-blue-50 border-2 border-educational-primary rounded-xl p-6 max-w-4xl mx-auto">
          <div className="flex items-start gap-3">
            <BookOpen className="w-6 h-6 text-educational-primary flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-bold text-gray-900 mb-2">
                Informação Puramente Educacional
              </h3>
              <p className="text-gray-700 text-sm mb-3">
                Este portal não promove nem recomenda nenhum serviço específico. Fornecemos apenas
                informação educacional sobre como funcionam diferentes tipos de depósitos e
                levantamentos, com foco na regulação portuguesa e proteção do consumidor.
              </p>
              <div className="flex flex-wrap gap-4 text-sm">
                <span className="text-gray-700">
                  SRIJ - Regulação de Jogos
                </span>
                <span className="text-gray-700">
                  Banco de Portugal
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
