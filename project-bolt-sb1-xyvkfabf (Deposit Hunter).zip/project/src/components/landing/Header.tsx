import { BookOpen, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      <div className="bg-educational-primary text-white py-2 px-4 text-center text-sm">
        <span className="font-semibold">Portal Educacional Independente</span>
        <span className="mx-2">|</span>
        <span>Sem Afiliações Comerciais</span>
      </div>

      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <BookOpen className="w-8 h-8 text-educational-primary" />
            <div>
              <h1 className="text-xl font-bold text-gray-900">Depósitos e Levantamentos</h1>
              <p className="text-sm text-gray-600">Guia Educacional</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-6">
            <a href="#categories" className="text-gray-700 hover:text-educational-primary transition">
              Categorias
            </a>
            <a href="#education" className="text-gray-700 hover:text-educational-primary transition">
              Educação
            </a>
            <Link to="/about" className="text-gray-700 hover:text-educational-primary transition">
              Sobre
            </Link>
            <Link to="/disclaimer" className="text-gray-700 hover:text-educational-primary transition">
              Aviso Legal
            </Link>
          </nav>

          <button
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-3">
            <a href="#categories" className="block text-gray-700 hover:text-educational-primary transition">
              Categorias
            </a>
            <a href="#education" className="block text-gray-700 hover:text-educational-primary transition">
              Educação
            </a>
            <Link to="/about" className="block text-gray-700 hover:text-educational-primary transition">
              Sobre
            </Link>
            <Link to="/disclaimer" className="block text-gray-700 hover:text-educational-primary transition">
              Aviso Legal
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
}
