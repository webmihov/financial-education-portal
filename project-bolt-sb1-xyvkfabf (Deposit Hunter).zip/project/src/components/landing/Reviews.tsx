import { useState, useEffect } from 'react';
import { Review } from '../../types';
import { supabase } from '../../lib/supabase';
import { Quote, ShieldCheck, MapPin } from 'lucide-react';

export function Reviews() {
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    fetchReviews();
  }, []);

  async function fetchReviews() {
    const { data } = await supabase
      .from('reviews')
      .select('*')
      .eq('is_active', true)
      .order('display_order');

    if (data) {
      setReviews(data);
    }
  }

  return (
    <section id="reviews" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            What Portuguese Users Say
          </h2>
          <p className="text-gray-600">
            Real reviews from users across Portugal
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {reviews.map((review) => (
            <div
              key={review.id}
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition"
            >
              <Quote className="w-10 h-10 text-portugal-lightBlue mb-4" />

              <p className="text-gray-700 mb-6 italic">
                "{review.review_text}"
              </p>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 flex items-center gap-2">
                    {review.user_name}
                    {review.is_verified && (
                      <ShieldCheck className="w-4 h-4 text-portugal-blue" title="Verified Reviewer" />
                    )}
                  </p>
                  <p className="text-sm text-gray-500 flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {review.location}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-gray-600">
            Reviews are moderated for authenticity
          </p>
        </div>
      </div>
    </section>
  );
}
