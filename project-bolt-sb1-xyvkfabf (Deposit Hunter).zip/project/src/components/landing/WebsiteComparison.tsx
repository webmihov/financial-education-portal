import { useState, useEffect } from 'react';
import { Website } from '../../types';
import { supabase } from '../../lib/supabase';
import { Shield, Info } from 'lucide-react';

export function WebsiteComparison() {
  const [websites, setWebsites] = useState<Website[]>([]);

  useEffect(() => {
    fetchWebsites();
  }, []);

  async function fetchWebsites() {
    const { data } = await supabase
      .from('websites')
      .select('*')
      .eq('is_active', true)
      .order('display_order');

    if (data) {
      setWebsites(data);
    }
  }

  return (
    <section id="comparison" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Regulatory Licensing Information
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Educational overview of platforms registered with Portuguese regulatory bodies
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {websites.map((website) => (
            <div
              key={website.id}
              className="bg-white border-2 border-gray-200 rounded-xl p-6"
            >
              <div className="text-center mb-4">
                <div className="w-16 h-16 mx-auto bg-educational-primary/10 rounded-full flex items-center justify-center mb-3">
                  <Shield className="w-8 h-8 text-educational-primary" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{website.name}</h3>
              </div>

              <div className="mb-4">
                <span className="inline-block bg-educational-success/10 text-educational-success text-xs font-semibold px-3 py-1 rounded-full">
                  {website.status_badge}
                </span>
              </div>

              <div className="mb-4">
                <h4 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <Info className="w-4 h-4 text-educational-primary" />
                  Regulatory Information
                </h4>
                <div className="space-y-2 text-sm text-gray-700">
                  <p><span className="font-medium">Platform Type:</span> {website.category}</p>
                  <p><span className="font-medium">Licensing Status:</span> {website.status_badge}</p>
                  <p className="text-xs text-gray-500 mt-2">
                    This information is for educational purposes only and does not constitute an endorsement.
                  </p>
                </div>
              </div>

              <p className="text-xs text-gray-400 text-center mt-4">
                Last updated: {new Date(website.updated_at).toLocaleDateString('pt-PT')}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
