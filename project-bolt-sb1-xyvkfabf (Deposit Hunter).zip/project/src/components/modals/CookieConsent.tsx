import { Cookie } from 'lucide-react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useState } from 'react';

export function CookieConsent() {
  const [cookieConsent, setCookieConsent] = useLocalStorage('cookie_consent', null);
  const [showSettings, setShowSettings] = useState(false);
  const [preferences, setPreferences] = useState({
    essential: true,
    tracking: true,
    analytics: true,
    remarketing: true,
    marketing: false,
    advertising: false,
  });

  if (cookieConsent !== null) {
    return null;
  }

  const handleAcceptAll = () => {
    setCookieConsent({
      essential: true,
      tracking: true,
      analytics: true,
      remarketing: true,
      marketing: true,
      advertising: true,
    });
  };

  const handleRejectOptional = () => {
    setCookieConsent({
      essential: true,
      tracking: true,
      analytics: true,
      remarketing: true,
      marketing: false,
      advertising: false,
    });
  };

  const handleSavePreferences = () => {
    setCookieConsent({
      ...preferences,
      essential: true,
      tracking: true,
      analytics: true,
      remarketing: true,
    });
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t-2 border-gray-200 shadow-2xl z-50 p-6">
      <div className="container mx-auto max-w-6xl">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="flex-shrink-0">
            <Cookie className="w-12 h-12 text-portugal-blue" />
          </div>

          <div className="flex-1">
            <h3 className="font-bold text-gray-900 mb-2">Cookie Notice</h3>
            {!showSettings ? (
              <>
                <p className="text-sm text-gray-700 mb-3">
                  This website uses essential cookies for functionality, as well as analytics, tracking,
                  and remarketing cookies (required) to improve your experience, understand how you use our
                  site, and deliver personalized content and advertisements.
                </p>
                <p className="text-xs text-gray-600">
                  By clicking "Accept All", you agree to the storing of all cookies on your device.
                  For more information, please review our Privacy Policy and Terms of Service.
                </p>
              </>
            ) : (
              <div className="space-y-3 mt-4">
                <label className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={preferences.essential}
                    disabled
                    className="mt-1"
                  />
                  <div>
                    <div className="font-semibold text-sm">Essential Cookies (Required)</div>
                    <div className="text-xs text-gray-600">
                      Necessary for the website to function properly
                    </div>
                  </div>
                </label>

                <label className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={preferences.tracking}
                    disabled
                    className="mt-1"
                  />
                  <div>
                    <div className="font-semibold text-sm">Tracking Cookies (Required)</div>
                    <div className="text-xs text-gray-600">
                      Required for tracking user interactions and behavior
                    </div>
                  </div>
                </label>

                <label className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={preferences.analytics}
                    disabled
                    className="mt-1"
                  />
                  <div>
                    <div className="font-semibold text-sm">Analytics Cookies (Required)</div>
                    <div className="text-xs text-gray-600">
                      Required to understand how visitors interact with our website
                    </div>
                  </div>
                </label>

                <label className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={preferences.remarketing}
                    disabled
                    className="mt-1"
                  />
                  <div>
                    <div className="font-semibold text-sm">Remarketing Cookies (Required)</div>
                    <div className="text-xs text-gray-600">
                      Required for remarketing and retargeting campaigns
                    </div>
                  </div>
                </label>

                <label className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={preferences.marketing}
                    onChange={(e) =>
                      setPreferences({ ...preferences, marketing: e.target.checked })
                    }
                    className="mt-1"
                  />
                  <div>
                    <div className="font-semibold text-sm">Marketing Cookies (Optional)</div>
                    <div className="text-xs text-gray-600">
                      Used to deliver personalized marketing content
                    </div>
                  </div>
                </label>

                <label className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={preferences.advertising}
                    onChange={(e) =>
                      setPreferences({ ...preferences, advertising: e.target.checked })
                    }
                    className="mt-1"
                  />
                  <div>
                    <div className="font-semibold text-sm">Advertising Cookies (Optional)</div>
                    <div className="text-xs text-gray-600">
                      Used to deliver relevant advertisements and measure campaign effectiveness
                    </div>
                  </div>
                </label>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-2 w-full md:w-auto min-w-[200px]">
            {!showSettings ? (
              <>
                <button
                  onClick={handleAcceptAll}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-base shadow-lg hover:shadow-xl transition-all whitespace-nowrap"
                >
                  Accept All
                </button>
                <button
                  onClick={() => setShowSettings(true)}
                  className="px-6 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-semibold transition-all whitespace-nowrap"
                >
                  Options
                </button>
                <button
                  onClick={handleRejectOptional}
                  className="px-6 py-2.5 bg-white hover:bg-gray-50 text-gray-700 border-2 border-gray-300 rounded-lg font-semibold transition-all whitespace-nowrap"
                >
                  Reject Optional
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={handleSavePreferences}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold transition-all whitespace-nowrap"
                >
                  Save Preferences
                </button>
                <button
                  onClick={() => setShowSettings(false)}
                  className="px-6 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-semibold transition-all whitespace-nowrap"
                >
                  Back
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
