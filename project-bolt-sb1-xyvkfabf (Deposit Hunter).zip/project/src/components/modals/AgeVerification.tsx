import { AlertCircle } from 'lucide-react';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface AgeVerificationProps {
  onVerified: () => void;
}

export function AgeVerification({ onVerified }: AgeVerificationProps) {
  const [ageVerified, setAgeVerified] = useLocalStorage('age_verified', false);

  if (ageVerified) {
    return null;
  }

  const handleVerify = () => {
    setAgeVerified(true);
    onVerified();
  };

  const handleDecline = () => {
    window.location.href = 'https://www.google.com';
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full p-8">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-portugal-red/10 rounded-full flex items-center justify-center">
            <AlertCircle className="w-10 h-10 text-portugal-red" />
          </div>
        </div>

        <h2 className="text-2xl font-bold text-gray-900 text-center mb-4">
          Age Verification Required
        </h2>

        <p className="text-gray-700 text-center mb-6">
          You must be 18 years or older to access this website. This site compares websites that
          require age verification according to Portuguese law.
        </p>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <p className="text-sm text-gray-700">
            By clicking "I am 18 or older", you confirm that you meet the minimum age requirement
            and agree to our Terms & Conditions.
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <button
            onClick={handleVerify}
            className="w-full bg-portugal-green hover:bg-portugal-darkGreen text-white py-3 rounded-lg font-semibold transition"
          >
            I am 18 or older
          </button>
          <button
            onClick={handleDecline}
            className="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold transition"
          >
            I am under 18
          </button>
        </div>
      </div>
    </div>
  );
}
