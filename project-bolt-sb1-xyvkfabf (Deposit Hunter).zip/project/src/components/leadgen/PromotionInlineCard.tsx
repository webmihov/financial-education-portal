import { Link } from 'react-router-dom';
import { ArrowRight, FileText } from 'lucide-react';

interface PromotionInlineCardProps {
  title: string;
  description: string;
  ctaText: string;
  targetUrl: string;
  onClick: () => void;
}

export function PromotionInlineCard({
  title,
  description,
  ctaText,
  targetUrl,
  onClick,
}: PromotionInlineCardProps) {
  return (
    <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border-2 border-blue-200 rounded-xl p-6 md:p-8 shadow-sm hover:shadow-md transition-all my-8">
      <div className="flex items-start gap-4 mb-4">
        <div className="p-3 bg-educational-primary rounded-lg">
          <FileText className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
          <p className="text-gray-600 leading-relaxed">{description}</p>
        </div>
      </div>
      <Link
        to={targetUrl}
        onClick={onClick}
        className="inline-flex items-center gap-2 px-6 py-3 bg-educational-primary text-white font-semibold rounded-lg hover:bg-educational-secondary transition-all hover:scale-105"
      >
        {ctaText}
        <ArrowRight className="w-5 h-5" />
      </Link>
    </div>
  );
}
