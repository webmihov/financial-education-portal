import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

interface PromotionBannerProps {
  title: string;
  description: string;
  ctaText: string;
  targetUrl: string;
  onClick: () => void;
}

export function PromotionBanner({
  title,
  description,
  ctaText,
  targetUrl,
  onClick,
}: PromotionBannerProps) {
  return (
    <div className="w-full bg-gradient-to-r from-educational-primary to-educational-secondary rounded-xl shadow-lg overflow-hidden my-8">
      <div className="px-6 py-8 md:px-12 md:py-10">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="flex-1">
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-3">
              {title}
            </h3>
            <p className="text-lg text-white/90 leading-relaxed">
              {description}
            </p>
          </div>
          <div className="flex-shrink-0">
            <Link
              to={targetUrl}
              onClick={onClick}
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-educational-primary font-semibold rounded-lg hover:bg-gray-50 transition-all hover:scale-105 shadow-md"
            >
              {ctaText}
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
