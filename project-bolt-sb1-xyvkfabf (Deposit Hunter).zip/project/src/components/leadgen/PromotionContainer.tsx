import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { LeadGenPromotion, LeadGenPage, TargetLocation, PlacementPosition } from '../../types';
import { trackPromotionClick } from '../../utils/leadGenAnalytics';
import { PromotionBanner } from './PromotionBanner';
import { PromotionButton } from './PromotionButton';
import { PromotionInlineCard } from './PromotionInlineCard';
import { PromotionTextAd } from './PromotionTextAd';

interface PromotionContainerProps {
  currentPage: TargetLocation;
  position: PlacementPosition;
  categoryId?: string;
}

interface PromotionWithPage extends LeadGenPromotion {
  lead_gen_pages: LeadGenPage;
}

export function PromotionContainer({
  currentPage,
  position,
  categoryId,
}: PromotionContainerProps) {
  const [promotions, setPromotions] = useState<PromotionWithPage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchPromotions() {
      try {
        console.log('[PromotionContainer] Fetching promotions with params:', {
          currentPage,
          position,
          categoryId,
        });

        let query = supabase
          .from('lead_gen_promotions')
          .select(`
            *,
            lead_gen_pages(*)
          `)
          .eq('is_active', true)
          .eq('placement_position', position)
          .order('display_order', { ascending: true });

        const { data, error } = await query;

        if (error) {
          console.error('[PromotionContainer] Query error:', error);
          throw error;
        }

        console.log('[PromotionContainer] Raw query results:', data?.length || 0, 'promotions');

        const filtered = (data as PromotionWithPage[]).filter((promo, index) => {
          console.log(`[PromotionContainer] Filtering promo ${index + 1}:`, {
            id: promo.id,
            title: promo.promotion_title,
            type: promo.promotion_type,
            hasLeadGenPage: !!promo.lead_gen_pages,
            leadGenPageActive: promo.lead_gen_pages?.is_active,
            targetLocations: promo.target_locations,
            targetCategoryIds: promo.target_category_ids,
          });

          if (!promo.lead_gen_pages || !promo.lead_gen_pages.is_active) {
            console.log(`[PromotionContainer] ❌ Promo ${index + 1} filtered out: lead_gen_page missing or inactive`);
            return false;
          }

          const matchesLocation = promo.target_locations.includes(currentPage);
          console.log(`[PromotionContainer] Promo ${index + 1} location match:`, matchesLocation);

          if (categoryId && promo.target_category_ids.length > 0) {
            const matchesCategory = promo.target_category_ids.includes(categoryId);
            console.log(`[PromotionContainer] Promo ${index + 1} category match:`, matchesCategory);
            const passes = matchesLocation && matchesCategory;
            console.log(`[PromotionContainer] ${passes ? '✅' : '❌'} Promo ${index + 1} final result:`, passes);
            return passes;
          }

          console.log(`[PromotionContainer] ${matchesLocation ? '✅' : '❌'} Promo ${index + 1} final result:`, matchesLocation);
          return matchesLocation;
        });

        console.log('[PromotionContainer] Final filtered promotions:', filtered.length);
        setPromotions(filtered);
      } catch (error) {
        console.error('[PromotionContainer] Failed to fetch promotions:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchPromotions();

    const channel = supabase
      .channel('promotions_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'lead_gen_promotions',
        },
        (payload) => {
          console.log('[PromotionContainer] Real-time update received:', payload);
          fetchPromotions();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'lead_gen_pages',
        },
        (payload) => {
          console.log('[PromotionContainer] Lead gen page updated:', payload);
          fetchPromotions();
        }
      )
      .subscribe((status) => {
        console.log('[PromotionContainer] Subscription status:', status);
      });

    return () => {
      console.log('[PromotionContainer] Cleaning up subscription');
      supabase.removeChannel(channel);
    };
  }, [currentPage, position, categoryId]);

  if (loading || promotions.length === 0) {
    return null;
  }

  return (
    <div className="w-full">
      {promotions.map((promotion) => {
        const targetUrl = `/lp/${promotion.lead_gen_pages.slug}`;
        const handleClick = () => {
          trackPromotionClick(
            promotion.id,
            promotion.lead_gen_page_id,
            window.location.pathname
          );
        };

        switch (promotion.promotion_type) {
          case 'banner':
            return (
              <PromotionBanner
                key={promotion.id}
                title={promotion.promotion_title}
                description={promotion.promotion_description}
                ctaText={promotion.cta_text}
                targetUrl={targetUrl}
                onClick={handleClick}
              />
            );

          case 'button':
            return (
              <PromotionButton
                key={promotion.id}
                title={promotion.promotion_title}
                ctaText={promotion.cta_text}
                targetUrl={targetUrl}
                onClick={handleClick}
              />
            );

          case 'inline_card':
            return (
              <PromotionInlineCard
                key={promotion.id}
                title={promotion.promotion_title}
                description={promotion.promotion_description}
                ctaText={promotion.cta_text}
                targetUrl={targetUrl}
                onClick={handleClick}
              />
            );

          case 'text_ad':
            return (
              <PromotionTextAd
                key={promotion.id}
                title={promotion.promotion_title}
                description={promotion.promotion_description}
                ctaText={promotion.cta_text}
                targetUrl={targetUrl}
                onClick={handleClick}
              />
            );

          default:
            return null;
        }
      })}
    </div>
  );
}
