import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

interface PromotionButtonProps {
  title: string;
  ctaText: string;
  targetUrl: string;
  onClick: () => void;
}

export function PromotionButton({
  title,
  ctaText,
  targetUrl,
  onClick,
}: PromotionButtonProps) {
  return (
    <div className="inline-flex items-center gap-4 bg-gray-50 border border-gray-200 rounded-lg px-6 py-4 my-4 hover:border-educational-primary transition-all">
      <span className="text-gray-700 font-medium">{title}</span>
      <Link
        to={targetUrl}
        onClick={onClick}
        className="inline-flex items-center gap-2 px-5 py-2 bg-educational-primary text-white font-semibold rounded-lg hover:bg-educational-secondary transition-all"
      >
        {ctaText}
        <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
}
