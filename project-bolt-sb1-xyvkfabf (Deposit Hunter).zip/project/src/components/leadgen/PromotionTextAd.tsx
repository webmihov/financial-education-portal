import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

interface PromotionTextAdProps {
  title: string;
  description: string;
  ctaText: string;
  targetUrl: string;
  onClick: () => void;
}

export function PromotionTextAd({
  title,
  description,
  ctaText,
  targetUrl,
  onClick,
}: PromotionTextAdProps) {
  return (
    <div className="border-l-4 border-educational-primary bg-gray-50 pl-6 py-4 my-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex-1">
          <h4 className="font-bold text-gray-900 mb-1">{title}</h4>
          <p className="text-sm text-gray-600">{description}</p>
        </div>
        <Link
          to={targetUrl}
          onClick={onClick}
          className="inline-flex items-center gap-2 text-educational-primary hover:text-educational-secondary font-semibold transition-colors whitespace-nowrap"
        >
          {ctaText}
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
