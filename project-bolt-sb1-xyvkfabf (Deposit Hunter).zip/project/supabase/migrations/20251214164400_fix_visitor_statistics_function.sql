/*
  # Fix Visitor Statistics Function

  1. Changes
    - Update `get_visitor_statistics` function to use correct column name
    - Replace `lgp.title` with `lgp.name` (the actual column in lead_gen_pages table)
    - Fix both SELECT clause and GROUP BY clause

  2. Impact
    - Resolves 400 error in visitor analytics dashboard
    - Allows proper display of visitor statistics per page
*/

-- Drop and recreate the function with correct column references
DROP FUNCTION IF EXISTS get_visitor_statistics(uuid);

CREATE OR REPLACE FUNCTION get_visitor_statistics(page_id_param uuid DEFAULT NULL)
RETURNS TABLE (
  page_id uuid,
  page_slug text,
  page_title text,
  total_visitors bigint,
  human_visitors bigint,
  bot_visitors bigint,
  uncertain_visitors bigint,
  saw_iframe_count bigint,
  hidden_iframe_count bigint,
  human_saw_iframe bigint,
  bot_saw_iframe bigint
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    va.page_id,
    lgp.slug as page_slug,
    lgp.name as page_title,
    COUNT(*) as total_visitors,
    COUNT(*) FILTER (WHERE va.visitor_type = 'human') as human_visitors,
    COUNT(*) FILTER (WHERE va.visitor_type = 'bot') as bot_visitors,
    COUNT(*) FILTER (WHERE va.visitor_type = 'uncertain') as uncertain_visitors,
    COUNT(*) FILTER (WHERE va.saw_iframe = true) as saw_iframe_count,
    COUNT(*) FILTER (WHERE va.saw_iframe = false) as hidden_iframe_count,
    COUNT(*) FILTER (WHERE va.visitor_type = 'human' AND va.saw_iframe = true) as human_saw_iframe,
    COUNT(*) FILTER (WHERE va.visitor_type = 'bot' AND va.saw_iframe = true) as bot_saw_iframe
  FROM visitor_analytics va
  JOIN lead_gen_pages lgp ON va.page_id = lgp.id
  WHERE page_id_param IS NULL OR va.page_id = page_id_param
  GROUP BY va.page_id, lgp.slug, lgp.name;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;