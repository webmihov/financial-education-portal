/*
  # Fraud Protection Settings

  ## Overview
  Adds fraud protection configuration to VDS global settings for Google Ads compliant bot blocking.

  ## Changes
  - Inserts default fraud protection settings into vds_global_settings table

  ## Configuration
  - Provider: none (default), clickcease, trafficguard, lunio, cheq
  - Block threshold: 80% fraud score
  - Delayed loading: enabled (2 seconds)
  - Require interaction: enabled
  - Require scroll: enabled

  ## Compliance
  This configuration is Google Ads compliant because:
  - Bots are blocked entirely (not shown different content)
  - Human visitors must interact to see iframes
  - Same content shown to all who complete requirements
  - No cloaking or content substitution
*/

-- Insert fraud protection settings
INSERT INTO vds_global_settings (setting_key, setting_value, description, is_active)
VALUES (
  'fraud_protection',
  '{
    "provider": "none",
    "apiKey": "",
    "blockThreshold": 80,
    "enableDelayedLoading": true,
    "delaySeconds": 2,
    "requireInteraction": true,
    "requireScroll": true
  }'::jsonb,
  'Fraud protection configuration for affiliate iframes - Google Ads compliant bot blocking',
  true
)
ON CONFLICT (setting_key) DO UPDATE
SET
  setting_value = EXCLUDED.setting_value,
  description = EXCLUDED.description,
  updated_at = now();