/*
  # Visitor Detection System Enhancement - Visitor Logs & Global Configuration

  ## Overview
  Enhances the Visitor Detection System with detailed visitor logging, iframe version tracking,
  and global VDS configuration management.

  ## Changes

  ### 1. Lead Gen Analytics Enhancement
  - Add `iframe_version_shown` column to track which iframe was displayed ('version1', 'version2', 'none', 'pending')
  - Add `detection_reason` column to store why a specific classification was made
  - Add `page_url` column to track full page path
  - Add indexes for efficient querying by iframe version

  ### 2. VDS Global Settings Table
  - New `vds_global_settings` table for centralized VDS configuration
  - Stores detection method preferences, thresholds, API keys, and service configurations
  - Settings can be overridden per-page in lead_gen_pages table

  ### 3. VDS Service Integrations Table
  - New `vds_service_integrations` table for external service configuration
  - Tracks API providers (MaxMind, IPQualityScore, IPHub, etc.)
  - Stores health status, quota usage, and performance metrics

  ### 4. VDS Detection Rules Table
  - New `vds_detection_rules` table for custom detection rules
  - Allows whitelisting/blacklisting IP ranges, user agents, ASNs
  - Supports custom scoring adjustments

  ## Security
  - Enable RLS on all new tables
  - Only authenticated admins can read/write settings
  - API keys are stored as text (consider using Vault in production)
*/

-- Add columns to lead_gen_analytics for iframe tracking
ALTER TABLE lead_gen_analytics 
  ADD COLUMN IF NOT EXISTS iframe_version_shown text CHECK (iframe_version_shown IN ('version1', 'version2', 'none', 'pending')),
  ADD COLUMN IF NOT EXISTS detection_reason text,
  ADD COLUMN IF NOT EXISTS page_url text;

-- Add index for iframe version queries
CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_iframe_version 
  ON lead_gen_analytics(iframe_version_shown, timestamp DESC)
  WHERE iframe_version_shown IS NOT NULL;

-- Create VDS Global Settings table
CREATE TABLE IF NOT EXISTS vds_global_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value jsonb NOT NULL DEFAULT '{}',
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert default VDS settings
INSERT INTO vds_global_settings (setting_key, setting_value, description) VALUES
  ('detection_method', '{"default": "simple", "fallback": "simple"}', 'Primary and fallback detection methods'),
  ('detection_thresholds', '{"human_min_score": 70, "bot_max_score": 30, "uncertain_range": [31, 69]}', 'Confidence score thresholds for classification'),
  ('cache_settings', '{"enabled": true, "duration_hours": 24, "max_entries": 10000}', 'Visitor detection cache configuration'),
  ('fingerprint_config', '{"enable_mouse_tracking": true, "enable_keyboard_timing": true, "enable_canvas_fingerprint": false, "behavior_weight": 0.6, "tech_weight": 0.4}', 'Fingerprint detection method configuration'),
  ('ip_classification', '{"datacenter_score_penalty": -30, "vpn_score_penalty": -20, "residential_score_bonus": 10, "mobile_score_bonus": 15}', 'IP type scoring adjustments'),
  ('data_retention', '{"analytics_days": 90, "cache_days": 30, "auto_cleanup": true}', 'Data retention and cleanup policies'),
  ('compliance_settings', '{"anonymize_ips": true, "gdpr_mode": false, "log_user_agents": true}', 'Privacy and compliance configuration')
ON CONFLICT (setting_key) DO NOTHING;

-- Create VDS Service Integrations table
CREATE TABLE IF NOT EXISTS vds_service_integrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_name text NOT NULL,
  service_type text NOT NULL CHECK (service_type IN ('ip_detection', 'fraud_detection', 'geo_lookup', 'custom')),
  api_endpoint text,
  api_key text,
  api_key_encrypted text,
  is_active boolean DEFAULT false,
  is_primary boolean DEFAULT false,
  priority_order integer DEFAULT 100,
  rate_limit_per_day integer,
  current_usage_count integer DEFAULT 0,
  usage_reset_at timestamptz DEFAULT now() + interval '1 day',
  last_health_check timestamptz,
  health_status text CHECK (health_status IN ('healthy', 'degraded', 'unhealthy', 'unknown')) DEFAULT 'unknown',
  average_latency_ms integer,
  success_rate_percent numeric(5,2),
  config_json jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert default service integrations (inactive by default)
INSERT INTO vds_service_integrations (service_name, service_type, priority_order, config_json) VALUES
  ('MaxMind GeoLite2', 'geo_lookup', 1, '{"requires_license_key": true, "database_type": "GeoLite2-City", "update_frequency": "weekly"}'),
  ('IPQualityScore', 'fraud_detection', 2, '{"supports_real_time": true, "features": ["vpn", "proxy", "datacenter", "fraud_score"]}'),
  ('IPHub', 'ip_detection', 3, '{"supports_real_time": true, "features": ["datacenter", "proxy"]}'),
  ('IPInfo', 'geo_lookup', 4, '{"supports_real_time": true, "features": ["asn", "company", "carrier"]}'),
  ('Built-in Detection', 'ip_detection', 999, '{"method": "user_agent_analysis", "always_available": true}')
ON CONFLICT DO NOTHING;

-- Create VDS Detection Rules table
CREATE TABLE IF NOT EXISTS vds_detection_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_name text NOT NULL,
  rule_type text NOT NULL CHECK (rule_type IN ('ip_range', 'user_agent_pattern', 'asn', 'country', 'custom')),
  rule_action text NOT NULL CHECK (rule_action IN ('classify_human', 'classify_bot', 'adjust_score', 'block')),
  rule_value text NOT NULL,
  score_adjustment integer DEFAULT 0,
  priority integer DEFAULT 100,
  is_active boolean DEFAULT true,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert example detection rules
INSERT INTO vds_detection_rules (rule_name, rule_type, rule_action, rule_value, score_adjustment, description) VALUES
  ('Common Bot User Agents', 'user_agent_pattern', 'classify_bot', 'bot|crawler|spider|scraper|headless', -50, 'Automatically classify common bot user agents'),
  ('Googlebot Whitelist', 'user_agent_pattern', 'classify_bot', 'Googlebot', 0, 'Allow legitimate Googlebot'),
  ('AWS IP Range', 'asn', 'adjust_score', '16509', -20, 'AWS IPs get negative score adjustment'),
  ('Google Cloud IPs', 'asn', 'adjust_score', '15169', -15, 'Google Cloud IPs get slight penalty'),
  ('Residential ISPs Bonus', 'asn', 'adjust_score', 'residential_carriers', 10, 'Residential ISP IPs get bonus points')
ON CONFLICT DO NOTHING;

-- Enable RLS on new tables
ALTER TABLE vds_global_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE vds_service_integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE vds_detection_rules ENABLE ROW LEVEL SECURITY;

-- RLS Policies for vds_global_settings
CREATE POLICY "Authenticated users can read VDS global settings"
  ON vds_global_settings FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can update VDS global settings"
  ON vds_global_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can insert VDS global settings"
  ON vds_global_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for vds_service_integrations
CREATE POLICY "Authenticated users can read service integrations"
  ON vds_service_integrations FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage service integrations"
  ON vds_service_integrations FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for vds_detection_rules
CREATE POLICY "Authenticated users can read detection rules"
  ON vds_detection_rules FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage detection rules"
  ON vds_detection_rules FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add comments for documentation
COMMENT ON TABLE vds_global_settings IS 'Global configuration settings for the Visitor Detection System';
COMMENT ON TABLE vds_service_integrations IS 'External service integrations for enhanced visitor detection';
COMMENT ON TABLE vds_detection_rules IS 'Custom detection rules for IP ranges, user agents, and classifications';
COMMENT ON COLUMN lead_gen_analytics.iframe_version_shown IS 'Tracks which iframe version was displayed to the visitor';
COMMENT ON COLUMN lead_gen_analytics.detection_reason IS 'Explanation of why the visitor received their classification';
COMMENT ON COLUMN lead_gen_analytics.page_url IS 'Full URL path of the page viewed';