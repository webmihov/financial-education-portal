/*
  # Transform to Educational Financial Portal - Portuguese Market Focus

  ## Overview
  This migration expands the database to support a comprehensive educational portal
  about deposits and withdrawals across multiple online service categories, with
  focus on Portuguese market and SRIJ (gaming) regulation.

  ## Security
  - All tables have RLS enabled
  - Public read access for educational content
  - Admin-only write access
*/

-- Add Portuguese regulatory fields to deposit_types
ALTER TABLE deposit_types ADD COLUMN IF NOT EXISTS srij_license_required boolean DEFAULT false;
ALTER TABLE deposit_types ADD COLUMN IF NOT EXISTS regulatory_body_pt text DEFAULT '';
ALTER TABLE deposit_types ADD COLUMN IF NOT EXISTS license_verification_url text DEFAULT '';
ALTER TABLE deposit_types ADD COLUMN IF NOT EXISTS risk_level_pt text DEFAULT 'médio';
ALTER TABLE deposit_types ADD COLUMN IF NOT EXISTS legal_status_pt text DEFAULT '';

-- Create platform_categories table
CREATE TABLE IF NOT EXISTS platform_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_pt text NOT NULL,
  name_en text NOT NULL,
  slug text UNIQUE NOT NULL,
  description_pt text DEFAULT '',
  description_en text DEFAULT '',
  icon_name text DEFAULT 'folder',
  regulatory_focus text DEFAULT '',
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create educational_articles table
CREATE TABLE IF NOT EXISTS educational_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title_pt text NOT NULL,
  title_en text NOT NULL,
  slug text UNIQUE NOT NULL,
  category_id uuid REFERENCES platform_categories(id) ON DELETE SET NULL,
  intro_pt text DEFAULT '',
  intro_en text DEFAULT '',
  how_it_works_pt text DEFAULT '',
  how_it_works_en text DEFAULT '',
  regulatory_status_pt text DEFAULT '',
  regulatory_status_en text DEFAULT '',
  risks_pt text DEFAULT '',
  risks_en text DEFAULT '',
  security_pt text DEFAULT '',
  security_en text DEFAULT '',
  red_flags_pt text DEFAULT '',
  red_flags_en text DEFAULT '',
  consumer_protection_pt text DEFAULT '',
  consumer_protection_en text DEFAULT '',
  disclaimer_pt text DEFAULT '',
  disclaimer_en text DEFAULT '',
  author text DEFAULT 'DepositHunter Editorial Team',
  last_reviewed timestamptz DEFAULT now(),
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create regulatory_bodies table
CREATE TABLE IF NOT EXISTS regulatory_bodies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_pt text NOT NULL,
  name_en text NOT NULL,
  acronym text UNIQUE NOT NULL,
  description_pt text DEFAULT '',
  description_en text DEFAULT '',
  jurisdiction text DEFAULT 'Portugal',
  oversight_areas text[] DEFAULT '{}',
  website_url text DEFAULT '',
  verification_url text DEFAULT '',
  complaint_url text DEFAULT '',
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create payment_methods_pt table
CREATE TABLE IF NOT EXISTS payment_methods_pt (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_pt text UNIQUE NOT NULL,
  name_en text NOT NULL,
  method_type text NOT NULL,
  description_pt text DEFAULT '',
  description_en text DEFAULT '',
  pros_pt text[] DEFAULT '{}',
  pros_en text[] DEFAULT '{}',
  cons_pt text[] DEFAULT '{}',
  cons_en text[] DEFAULT '{}',
  security_level text DEFAULT 'médio',
  typical_fees_pt text DEFAULT '',
  typical_fees_en text DEFAULT '',
  processing_time_pt text DEFAULT '',
  processing_time_en text DEFAULT '',
  icon_name text DEFAULT 'credit-card',
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create risk_warnings table
CREATE TABLE IF NOT EXISTS risk_warnings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  warning_key text UNIQUE NOT NULL,
  title_pt text NOT NULL,
  title_en text NOT NULL,
  content_pt text NOT NULL,
  content_en text NOT NULL,
  severity_level text DEFAULT 'medium',
  applies_to text[] DEFAULT '{}',
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on new tables
ALTER TABLE platform_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE educational_articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE regulatory_bodies ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_methods_pt ENABLE ROW LEVEL SECURITY;
ALTER TABLE risk_warnings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for platform_categories
CREATE POLICY "Public can view active platform categories"
  ON platform_categories FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage platform categories"
  ON platform_categories FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for educational_articles
CREATE POLICY "Public can view active educational articles"
  ON educational_articles FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage educational articles"
  ON educational_articles FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for regulatory_bodies
CREATE POLICY "Public can view active regulatory bodies"
  ON regulatory_bodies FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage regulatory bodies"
  ON regulatory_bodies FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for payment_methods_pt
CREATE POLICY "Public can view active payment methods"
  ON payment_methods_pt FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage payment methods"
  ON payment_methods_pt FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for risk_warnings
CREATE POLICY "Public can view active risk warnings"
  ON risk_warnings FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage risk warnings"
  ON risk_warnings FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_platform_categories_slug ON platform_categories(slug);
CREATE INDEX IF NOT EXISTS idx_platform_categories_display_order ON platform_categories(display_order);
CREATE INDEX IF NOT EXISTS idx_educational_articles_slug ON educational_articles(slug);
CREATE INDEX IF NOT EXISTS idx_educational_articles_category_id ON educational_articles(category_id);
CREATE INDEX IF NOT EXISTS idx_regulatory_bodies_acronym ON regulatory_bodies(acronym);
CREATE INDEX IF NOT EXISTS idx_payment_methods_pt_method_type ON payment_methods_pt(method_type);

-- Insert platform categories
INSERT INTO platform_categories (name_pt, name_en, slug, description_pt, description_en, icon_name, regulatory_focus, display_order, is_active)
VALUES
  ('Bancos e Instituições Financeiras', 'Banks & Financial Institutions', 'bancos', 'Aprenda sobre depósitos bancários, contas poupança, e serviços financeiros regulados em Portugal', 'Learn about bank deposits, savings accounts, and regulated financial services in Portugal', 'building', 'Banco de Portugal', 1, true),
  ('Plataformas de E-commerce', 'E-commerce Platforms', 'e-commerce', 'Entenda como funcionam os depósitos e pagamentos em marketplaces e lojas online', 'Understand how deposits and payments work in marketplaces and online stores', 'shopping-cart', 'ASAE', 2, true),
  ('Plataformas de Jogos (SRIJ)', 'Gaming Platforms (SRIJ)', 'jogos-srij', 'Informação educacional sobre regulação de jogos em Portugal e licenciamento SRIJ', 'Educational information about gaming regulation in Portugal and SRIJ licensing', 'gamepad-2', 'SRIJ', 3, true),
  ('Lotarias e Jogos de Sorte', 'Lotteries & Games of Chance', 'lotarias', 'Entenda como funcionam lotarias legais e os riscos associados', 'Understand how legal lotteries work and associated risks', 'ticket', 'SRIJ', 4, true),
  ('Exchanges de Criptomoedas', 'Cryptocurrency Exchanges', 'criptomoedas', 'Aprenda sobre depósitos em criptomoedas, riscos e regulação em Portugal', 'Learn about cryptocurrency deposits, risks and regulation in Portugal', 'bitcoin', 'Banco de Portugal', 5, true),
  ('Plataformas de Freelance', 'Freelance Platforms', 'freelance', 'Entenda como funcionam pagamentos e levantamentos em plataformas de trabalho freelance', 'Understand how payments and withdrawals work on freelance work platforms', 'briefcase', 'Autoridade Tributária', 6, true),
  ('Serviços de Streaming', 'Streaming Services', 'streaming', 'Aprenda sobre subscrições, depósitos recorrentes e políticas de reembolso', 'Learn about subscriptions, recurring deposits and refund policies', 'tv', 'Consumer Protection', 7, true)
ON CONFLICT (slug) DO NOTHING;

-- Insert Portuguese regulatory bodies
INSERT INTO regulatory_bodies (name_pt, name_en, acronym, description_pt, description_en, jurisdiction, oversight_areas, website_url, verification_url, complaint_url, display_order, is_active)
VALUES
  ('Serviço de Regulação e Inspeção de Jogos', 'Gaming Regulation and Inspection Service', 'SRIJ', 'Entidade responsável pela regulação e fiscalização do jogo online em Portugal', 'Entity responsible for regulating and supervising online gaming in Portugal', 'Portugal', '{"jogos online", "apostas desportivas", "lotarias"}', 'https://www.srij.turismodeportugal.pt', 'https://www.srij.turismodeportugal.pt/pt/registo-entidades', 'https://www.livroreclamacoes.pt', 1, true),
  ('Banco de Portugal', 'Bank of Portugal', 'BdP', 'Banco central e autoridade de supervisão do sistema financeiro português', 'Central bank and supervisory authority of the Portuguese financial system', 'Portugal', '{"bancos", "instituições de crédito", "sistemas de pagamento"}', 'https://www.bportugal.pt', 'https://www.bportugal.pt/page/entidades-supervisionadas', 'https://www.bportugal.pt/reclamacoes', 2, true),
  ('Comissão do Mercado de Valores Mobiliários', 'Portuguese Securities Market Commission', 'CMVM', 'Supervisiona e regula os mercados de valores mobiliários em Portugal', 'Supervises and regulates securities markets in Portugal', 'Portugal', '{"mercados de capitais", "investimentos", "fundos"}', 'https://www.cmvm.pt', 'https://web3.cmvm.pt/english/sdi/entidades/entidades.cfm', 'https://www.cmvm.pt/pt/AreaProfissional/ReclamacoesQuerelasProcessosContraordenacao/Pages/Reclamacoes.aspx', 3, true),
  ('Autoridade de Segurança Alimentar e Económica', 'Food and Economic Safety Authority', 'ASAE', 'Fiscaliza atividades económicas e protege consumidores em Portugal', 'Supervises economic activities and protects consumers in Portugal', 'Portugal', '{"e-commerce", "comércio", "segurança económica"}', 'https://www.asae.gov.pt', '', 'https://www.livroreclamacoes.pt', 4, true),
  ('Portal do Consumidor', 'Consumer Portal', 'PortalConsumidor', 'Portal oficial de informação e proteção ao consumidor português', 'Official portal for Portuguese consumer information and protection', 'Portugal', '{"direitos do consumidor", "reclamações", "proteção"}', 'https://www.consumidor.gov.pt', '', 'https://www.livroreclamacoes.pt', 5, true)
ON CONFLICT (acronym) DO NOTHING;

-- Insert Portuguese payment methods
INSERT INTO payment_methods_pt (name_pt, name_en, method_type, description_pt, description_en, pros_pt, pros_en, cons_pt, cons_en, security_level, typical_fees_pt, typical_fees_en, processing_time_pt, processing_time_en, icon_name, display_order, is_active)
VALUES
  ('Multibanco', 'Multibanco', 'bank_transfer', 'Sistema de pagamento interbancário português amplamente utilizado', 'Portuguese interbank payment system widely used', '{"Aceite em praticamente todos os locais", "Seguro e regulado"}', '{"Accepted almost everywhere", "Secure and regulated"}', '{"Requer acesso a caixa automática", "Processamento pode levar 1-3 dias"}', '{"Requires access to ATM", "Processing can take 1-3 days"}', 'alto', 'Geralmente gratuito', 'Usually free', '1-3 dias úteis', '1-3 business days', 'credit-card', 1, true),
  ('MB WAY', 'MB WAY', 'mobile_payment', 'Aplicação de pagamento móvel integrada com contas bancárias portuguesas', 'Mobile payment app integrated with Portuguese bank accounts', '{"Instantâneo", "Muito conveniente", "Seguro"}', '{"Instant", "Very convenient", "Secure"}', '{"Requer smartphone", "Limites diários"}', '{"Requires smartphone", "Daily limits"}', 'alto', 'Geralmente gratuito', 'Usually free', 'Instantâneo', 'Instant', 'smartphone', 2, true),
  ('Transferência Bancária SEPA', 'SEPA Bank Transfer', 'bank_transfer', 'Transferência bancária dentro da zona SEPA', 'Bank transfer within SEPA zone', '{"Seguro e rastreável", "Sem limites"}', '{"Secure and traceable", "No limits"}', '{"Pode demorar 1-3 dias", "Requer dados bancários"}', '{"Can take 1-3 days", "Requires banking details"}', 'alto', '€0-€5', '€0-€5', '1-3 dias úteis', '1-3 business days', 'landmark', 3, true),
  ('Cartão de Crédito/Débito', 'Credit/Debit Card', 'card', 'Pagamento com cartão Visa, Mastercard, ou American Express', 'Payment with Visa, Mastercard, or American Express card', '{"Instantâneo", "Conveniente"}', '{"Instant", "Convenient"}', '{"Taxas podem aplicar-se", "Expõe dados do cartão"}', '{"Fees may apply", "Exposes card data"}', 'médio', '1-3%', '1-3%', 'Instantâneo', 'Instant', 'credit-card', 4, true),
  ('Payshop', 'Payshop', 'cash_payment', 'Pagamento em dinheiro em agentes Payshop', 'Cash payment at Payshop agents', '{"Não requer conta bancária", "Pagamento em dinheiro"}', '{"No bank account required", "Cash payment"}', '{"Requer deslocação física", "Limites de valor"}', '{"Requires physical travel", "Amount limits"}', 'médio', '€0.50-€2.00', '€0.50-€2.00', 'Rápido', 'Fast', 'store', 5, true)
ON CONFLICT (name_pt) DO NOTHING;

-- Insert risk warnings
INSERT INTO risk_warnings (warning_key, title_pt, title_en, content_pt, content_en, severity_level, applies_to, display_order, is_active)
VALUES
  ('educational_only', 'Apenas para Fins Educacionais', 'For Educational Purposes Only', 'Este site é um recurso educacional independente. Não somos consultores financeiros e não temos afiliações com instituições financeiras, bancos, ou outras entidades. O conteúdo é apenas informativo, não constitui aconselhamento financeiro.', 'This site is an independent educational resource. We are not financial advisors and have no affiliations with financial institutions, banks, or other entities. Content is for informational purposes only, not financial advice.', 'high', '{"all"}', 1, true),
  ('deposit_risk', 'Risco de Perda de Depósitos', 'Risk of Deposit Loss', 'Depósitos em qualquer plataforma online comportam riscos. Pode perder parte ou todo o valor depositado. Apenas deposite valores que pode perder sem comprometer suas finanças pessoais.', 'Deposits on any online platform carry risks. You may lose part or all of the deposited amount. Only deposit amounts you can afford to lose without compromising your personal finances.', 'high', '{"jogos-srij", "lotarias", "criptomoedas"}', 2, true),
  ('license_verification', 'Verifique Sempre as Licenças', 'Always Verify Licenses', 'Antes de depositar em qualquer plataforma, verifique se possui licença válida das autoridades portuguesas competentes. Para jogos online, confirme no registo público do SRIJ.', 'Before depositing on any platform, verify it has a valid license from competent Portuguese authorities. For online gaming, confirm on SRIJ public registry.', 'high', '{"jogos-srij", "lotarias"}', 3, true),
  ('no_affiliates', 'Sem Relações de Afiliação', 'No Affiliate Relationships', 'Este site não tem relações de afiliação com nenhuma plataforma, banco, ou serviço mencionado. Não recebemos comissões por referências. Toda informação é puramente educacional e independente.', 'This site has no affiliate relationships with any platform, bank, or service mentioned. We do not receive commissions for referrals. All information is purely educational and independent.', 'medium', '{"all"}', 4, true),
  ('seek_professional_advice', 'Procure Aconselhamento Profissional', 'Seek Professional Advice', 'Para decisões financeiras importantes, consulte sempre profissionais qualificados (advogados, contabilistas, consultores financeiros) que possam avaliar sua situação específica.', 'For important financial decisions, always consult qualified professionals (lawyers, accountants, financial advisors) who can assess your specific situation.', 'medium', '{"all"}', 5, true)
ON CONFLICT (warning_key) DO NOTHING;

-- Update compliance settings
INSERT INTO compliance_settings (setting_key, setting_value, description)
VALUES
  ('site_mission', 'educational_financial_literacy', 'Educational portal about deposits/withdrawals'),
  ('target_market', 'portugal', 'Primary focus on Portuguese market'),
  ('regulatory_focus', 'SRIJ,BdP,CMVM,ASAE', 'Portuguese regulatory authorities'),
  ('language_primary', 'portuguese', 'Primary language'),
  ('google_ads_status', 'compliant', 'Designed for Google Ads compliance'),
  ('affiliate_disclosure', 'none', 'No affiliate relationships')
ON CONFLICT (setting_key) DO UPDATE SET
  setting_value = EXCLUDED.setting_value,
  description = EXCLUDED.description,
  updated_at = now();
