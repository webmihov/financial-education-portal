/*
  # Create Tracking Scripts Table

  1. New Tables
    - `tracking_scripts`
      - `id` (uuid, primary key) - Unique identifier for each script
      - `name` (text) - Friendly name for the script (e.g., "Google Analytics", "Facebook Pixel")
      - `script_type` (text) - Type of script: 'google_analytics', 'remarketing', 'custom'
      - `content` (text) - The actual script code/content
      - `placement` (text) - Where to inject: 'head' or 'body'
      - `priority` (integer) - Load order (lower numbers load first)
      - `is_active` (boolean) - Whether the script is enabled
      - `requires_consent` (boolean) - Whether script requires cookie consent
      - `consent_category` (text) - Which consent category: 'analytics', 'marketing', 'preferences'
      - `created_at` (timestamptz) - When the script was created
      - `updated_at` (timestamptz) - When the script was last updated

  2. Security
    - Enable RLS on `tracking_scripts` table
    - Add policy for public to read active scripts
    - Add policy for authenticated admins to manage scripts

  3. Important Notes
    - Scripts will only load on frontend if is_active is true
    - If requires_consent is true, script waits for user consent
    - Priority determines loading order (1 loads before 2, etc.)
    - Default scripts for common tracking tools can be pre-populated
*/

CREATE TABLE IF NOT EXISTS tracking_scripts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  script_type text NOT NULL CHECK (script_type IN ('google_analytics', 'remarketing', 'custom')),
  content text NOT NULL,
  placement text NOT NULL DEFAULT 'head' CHECK (placement IN ('head', 'body')),
  priority integer NOT NULL DEFAULT 100,
  is_active boolean NOT NULL DEFAULT false,
  requires_consent boolean NOT NULL DEFAULT true,
  consent_category text CHECK (consent_category IN ('analytics', 'marketing', 'preferences')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE tracking_scripts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active tracking scripts"
  ON tracking_scripts
  FOR SELECT
  USING (is_active = true);

CREATE POLICY "Authenticated admins can view all tracking scripts"
  ON tracking_scripts
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated admins can insert tracking scripts"
  ON tracking_scripts
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated admins can update tracking scripts"
  ON tracking_scripts
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated admins can delete tracking scripts"
  ON tracking_scripts
  FOR DELETE
  TO authenticated
  USING (true);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_tracking_scripts_active ON tracking_scripts(is_active, priority);
CREATE INDEX IF NOT EXISTS idx_tracking_scripts_type ON tracking_scripts(script_type);