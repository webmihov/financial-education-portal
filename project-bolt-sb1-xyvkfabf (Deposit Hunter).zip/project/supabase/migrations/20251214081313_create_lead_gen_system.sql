/*
  # Create Lead Generation System with Google Ads Compliance

  ## Overview
  This migration creates a complete lead-gen system where all promotions link ONLY
  to internal pages within the domain. This ensures full Google Ads policy compliance.

  ## Architecture
  1. lead_gen_pages - Internal landing pages at /lp/:slug
  2. lead_gen_promotions - Promotional content that links to internal pages only
  3. lead_gen_analytics - Track views, clicks, and performance

  ## Google Ads Compliance
  - Foreign key constraint enforces internal links (lead_gen_page_id NOT NULL)
  - All promotions must reference valid internal pages
  - No external URLs or redirects possible at database level

  ## Security
  - All tables have RLS enabled
  - Public read access for active content only
  - Admin-only write access

  ## Tables Created
  1. lead_gen_pages
     - id (uuid, primary key)
     - name (text) - Internal display name
     - slug (text, unique) - URL-safe identifier for /lp/:slug
     - category_id (uuid, FK to platform_categories)
     - hero_title (text) - Main headline
     - hero_subtitle (text) - Supporting text
     - bullets (text[]) - Key points array
     - preview_text (text) - Description before form
     - compliance_note (text) - Legal disclaimer
     - iframe_embed_code (text) - External form HTML
     - display_order (integer)
     - is_active (boolean)
     - timestamps

  2. lead_gen_promotions
     - id (uuid, primary key)
     - lead_gen_page_id (uuid, FK NOT NULL with CASCADE) - Enforces internal links
     - promotion_type (text) - banner|button|inline_card|text_ad
     - promotion_title (text)
     - promotion_description (text)
     - cta_text (text) - Call-to-action button text
     - target_locations (text[]) - Where to show: landing|article|category
     - target_category_ids (uuid[]) - Specific categories
     - placement_position (text) - top|middle|bottom|sidebar
     - display_order (integer)
     - is_active (boolean)
     - timestamps

  3. lead_gen_analytics
     - id (uuid, primary key)
     - lead_gen_page_id (uuid, FK to lead_gen_pages)
     - event_type (text) - page_view|promotion_click
     - referrer_page (text) - Source page
     - ip_hash (text) - Hashed for privacy
     - user_agent (text)
     - timestamp (timestamptz)
*/

-- Create lead_gen_pages table
CREATE TABLE IF NOT EXISTS lead_gen_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  category_id uuid REFERENCES platform_categories(id) ON DELETE SET NULL,
  hero_title text DEFAULT '',
  hero_subtitle text DEFAULT '',
  bullets text[] DEFAULT '{}',
  preview_text text DEFAULT '',
  compliance_note text DEFAULT '',
  iframe_embed_code text DEFAULT '',
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create lead_gen_promotions table with enforced internal linking
CREATE TABLE IF NOT EXISTS lead_gen_promotions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_gen_page_id uuid NOT NULL REFERENCES lead_gen_pages(id) ON DELETE CASCADE,
  promotion_type text NOT NULL CHECK (promotion_type IN ('banner', 'button', 'inline_card', 'text_ad')),
  promotion_title text DEFAULT '',
  promotion_description text DEFAULT '',
  cta_text text DEFAULT 'Saber Mais',
  target_locations text[] DEFAULT '{}',
  target_category_ids uuid[] DEFAULT '{}',
  placement_position text DEFAULT 'middle' CHECK (placement_position IN ('top', 'middle', 'bottom', 'sidebar')),
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add comment explaining Google Ads compliance architecture
COMMENT ON COLUMN lead_gen_promotions.lead_gen_page_id IS
  'Foreign key enforces internal links only - Google Ads compliant. All promotions must reference valid internal pages.';

-- Create lead_gen_analytics table
CREATE TABLE IF NOT EXISTS lead_gen_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_gen_page_id uuid REFERENCES lead_gen_pages(id) ON DELETE SET NULL,
  promotion_id uuid REFERENCES lead_gen_promotions(id) ON DELETE SET NULL,
  event_type text NOT NULL CHECK (event_type IN ('page_view', 'promotion_click')),
  referrer_page text DEFAULT '',
  ip_hash text DEFAULT '',
  user_agent text DEFAULT '',
  timestamp timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE lead_gen_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_gen_promotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_gen_analytics ENABLE ROW LEVEL SECURITY;

-- RLS Policies for lead_gen_pages
CREATE POLICY "Public can view active lead gen pages"
  ON lead_gen_pages FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage lead gen pages"
  ON lead_gen_pages FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for lead_gen_promotions
CREATE POLICY "Public can view active promotions"
  ON lead_gen_promotions FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage promotions"
  ON lead_gen_promotions FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for lead_gen_analytics
CREATE POLICY "Public can insert analytics"
  ON lead_gen_analytics FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view analytics"
  ON lead_gen_analytics FOR SELECT
  TO authenticated
  USING (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_lead_gen_pages_slug ON lead_gen_pages(slug);
CREATE INDEX IF NOT EXISTS idx_lead_gen_pages_category_id ON lead_gen_pages(category_id);
CREATE INDEX IF NOT EXISTS idx_lead_gen_pages_display_order ON lead_gen_pages(display_order);
CREATE INDEX IF NOT EXISTS idx_lead_gen_pages_active ON lead_gen_pages(is_active);

CREATE INDEX IF NOT EXISTS idx_lead_gen_promotions_page_id ON lead_gen_promotions(lead_gen_page_id);
CREATE INDEX IF NOT EXISTS idx_lead_gen_promotions_type ON lead_gen_promotions(promotion_type);
CREATE INDEX IF NOT EXISTS idx_lead_gen_promotions_active ON lead_gen_promotions(is_active);

CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_page_id ON lead_gen_analytics(lead_gen_page_id);
CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_timestamp ON lead_gen_analytics(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_event_type ON lead_gen_analytics(event_type);

-- Insert sample lead gen pages
INSERT INTO lead_gen_pages (name, slug, category_id, hero_title, hero_subtitle, bullets, preview_text, compliance_note, display_order, is_active)
VALUES
  (
    'Guia de Depósitos Bancários',
    'depositos-bancarios-guia',
    (SELECT id FROM platform_categories WHERE slug = 'bancos' LIMIT 1),
    'Aprenda a Escolher o Melhor Depósito Bancário',
    'Descubra como maximizar a segurança e rentabilidade dos seus depósitos em Portugal',
    ARRAY[
      'Comparação de taxas de juro atualizadas',
      'Informação sobre garantia do Fundo de Garantia de Depósitos',
      'Análise de produtos regulados pelo Banco de Portugal',
      'Guia completo sobre liquidez e prazos'
    ],
    'Complete o formulário abaixo para receber o nosso guia completo sobre depósitos bancários em Portugal. Este recurso educacional gratuito ajuda-o a compreender as opções disponíveis no mercado português.',
    'Este é um recurso educacional independente. Não somos consultores financeiros. A informação fornecida é apenas para fins informativos e não constitui aconselhamento financeiro.',
    1,
    true
  ),
  (
    'Regulação SRIJ - Guia Completo',
    'srij-regulacao-jogos',
    (SELECT id FROM platform_categories WHERE slug = 'jogos-srij' LIMIT 1),
    'Entenda a Regulação de Jogos Online em Portugal',
    'Guia educacional sobre licenciamento SRIJ e proteção do consumidor',
    ARRAY[
      'Como verificar licenças SRIJ válidas',
      'Direitos do consumidor em plataformas licenciadas',
      'Riscos e avisos importantes',
      'Como fazer reclamações ao SRIJ'
    ],
    'Preencha o formulário para receber informação educacional detalhada sobre a regulação de jogos online em Portugal e como proteger-se ao utilizar plataformas digitais.',
    'Este conteúdo é puramente educacional. Não promovemos nem temos afiliação com qualquer operador de jogos. Para aconselhamento legal específico, consulte um advogado especializado.',
    2,
    true
  );

-- Insert sample promotions with internal links enforced
INSERT INTO lead_gen_promotions (
  lead_gen_page_id,
  promotion_type,
  promotion_title,
  promotion_description,
  cta_text,
  target_locations,
  target_category_ids,
  placement_position,
  display_order,
  is_active
)
VALUES
  (
    (SELECT id FROM lead_gen_pages WHERE slug = 'depositos-bancarios-guia' LIMIT 1),
    'banner',
    'Guia Gratuito: Depósitos Bancários em Portugal',
    'Aprenda a escolher o melhor depósito bancário com o nosso guia completo. Informação atualizada e independente.',
    'Descarregar Guia Gratuito',
    ARRAY['landing', 'article'],
    ARRAY[]::uuid[],
    'top',
    1,
    true
  ),
  (
    (SELECT id FROM lead_gen_pages WHERE slug = 'srij-regulacao-jogos' LIMIT 1),
    'inline_card',
    'Proteja-se: Conheça a Regulação SRIJ',
    'Guia educacional sobre como identificar plataformas licenciadas e seus direitos como consumidor.',
    'Ver Guia Completo',
    ARRAY['article'],
    ARRAY[(SELECT id FROM platform_categories WHERE slug = 'jogos-srij' LIMIT 1)],
    'middle',
    2,
    true
  ),
  (
    (SELECT id FROM lead_gen_pages WHERE slug = 'depositos-bancarios-guia' LIMIT 1),
    'text_ad',
    'Novo Guia: Depósitos Seguros',
    'Descubra como proteger o seu dinheiro com depósitos bancários regulados.',
    'Saber Mais',
    ARRAY['article'],
    ARRAY[(SELECT id FROM platform_categories WHERE slug = 'bancos' LIMIT 1)],
    'bottom',
    3,
    true
  );
