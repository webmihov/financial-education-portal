/*
  # Consolidate Visitor Tracking to Single Table

  ## Summary
  This migration consolidates all visitor tracking into the `visitor_analytics` table
  as the single source of truth. It removes redundant visitor tracking columns from
  `lead_gen_analytics` to eliminate data duplication and simplify the system.

  ## Changes Made

  ### 1. Remove Redundant Columns from lead_gen_analytics
  The following columns are being removed as they duplicate visitor_analytics data:
  - `visitor_classification` - Moved to visitor_analytics.visitor_type
  - `ip_type` - No longer needed for basic tracking
  - `has_javascript` - No longer needed for basic tracking
  - `detection_signals` - No longer needed for basic tracking
  - `device_authenticity_score` - No longer needed for basic tracking
  - `is_headless_browser` - No longer needed for basic tracking
  - `is_old_browser` - No longer needed for basic tracking
  - `ptr_hostname` - No longer needed for basic tracking
  - `iframe_version_shown` - Tracked via visitor_analytics.saw_iframe
  - `detection_reason` - No longer needed for basic tracking
  - `page_url` - Tracked via visitor_analytics.page_id

  ### 2. Drop Associated Indexes
  Remove indexes that are no longer needed after column removal.

  ### 3. Updated Data Model
  - `visitor_analytics` - Single source for all visitor tracking data
  - `lead_gen_analytics` - Focused on event tracking (page views, promotion clicks)

  ## Benefits
  - Eliminates data duplication
  - Simplifies queries and maintenance
  - Makes IP lookup optional (not required for analytics)
  - Clearer separation of concerns
  - Better performance with reduced table size

  ## Backward Compatibility
  - Existing analytics data remains intact
  - Only removes unused/redundant columns
  - No data loss for critical tracking information
*/

-- Drop indexes for columns we're about to remove
DROP INDEX IF EXISTS idx_lead_gen_analytics_visitor_classification;
DROP INDEX IF EXISTS idx_lead_gen_analytics_ip_type;
DROP INDEX IF EXISTS idx_lead_gen_analytics_composite;
DROP INDEX IF EXISTS idx_lead_gen_analytics_iframe_version;

-- Remove redundant visitor tracking columns from lead_gen_analytics
ALTER TABLE lead_gen_analytics
  DROP COLUMN IF EXISTS visitor_classification,
  DROP COLUMN IF EXISTS ip_type,
  DROP COLUMN IF EXISTS has_javascript,
  DROP COLUMN IF EXISTS detection_signals,
  DROP COLUMN IF EXISTS device_authenticity_score,
  DROP COLUMN IF EXISTS is_headless_browser,
  DROP COLUMN IF EXISTS is_old_browser,
  DROP COLUMN IF EXISTS ptr_hostname,
  DROP COLUMN IF EXISTS iframe_version_shown,
  DROP COLUMN IF EXISTS detection_reason,
  DROP COLUMN IF EXISTS page_url;

-- Update table comments to clarify purpose
COMMENT ON TABLE visitor_analytics IS 'Single source of truth for all visitor tracking and classification data';
COMMENT ON TABLE lead_gen_analytics IS 'Event tracking for page views and promotion clicks';

-- Add helpful column comments
COMMENT ON COLUMN lead_gen_analytics.lead_gen_page_id IS 'Links to the page that was viewed or had a promotion clicked';
COMMENT ON COLUMN lead_gen_analytics.event_type IS 'Type of event: page_view or promotion_click';
COMMENT ON COLUMN lead_gen_analytics.referrer_page IS 'HTTP referrer header value';

COMMENT ON COLUMN visitor_analytics.visitor_type IS 'Visitor classification: human, bot, or uncertain';
COMMENT ON COLUMN visitor_analytics.saw_iframe IS 'Whether the visitor saw the iframe (based on manual_hide_iframe setting)';
COMMENT ON COLUMN visitor_analytics.ip_hash IS 'Optional SHA-256 hash of visitor IP - can be NULL if IP lookup fails';
