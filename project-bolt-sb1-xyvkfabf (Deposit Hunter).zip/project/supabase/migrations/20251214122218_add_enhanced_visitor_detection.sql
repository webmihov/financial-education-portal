/*
  # Enhanced Visitor Detection System
  
  ## Overview
  This migration adds comprehensive visitor detection and analytics capabilities
  for distinguishing between legitimate human visitors and automated bots.
  
  ## New Tables
  
  1. **visitor_detections**
     - Caches visitor detection results by IP hash
     - Stores classification (human/bot/uncertain)
     - Tracks detection signals and confidence scores
     - Includes IP type classification (residential/mobile/datacenter/organization)
     - 24-hour cache to optimize performance
  
  ## Enhanced Columns for lead_gen_analytics
  
  1. **visitor_classification** - human/bot/uncertain
  2. **ip_type** - residential/mobile/datacenter/organization/vpn/unknown
  3. **has_javascript** - Boolean indicating JavaScript availability
  4. **detection_signals** - JSONB storing all detection factors
  5. **device_authenticity_score** - Score 0-100 for device/browser authenticity
  6. **is_headless_browser** - Boolean for headless browser detection
  7. **is_old_browser** - Boolean for outdated browser detection
  8. **ptr_hostname** - Reverse DNS hostname for server IP detection
  
  ## Security
  - All tables have RLS enabled
  - Public can insert detection data (for tracking)
  - Authenticated users can view all analytics
  - Detection cache automatically expires after 24 hours
  
  ## Performance
  - Indexed on ip_hash for fast lookups
  - Indexed on timestamp for cache expiry queries
  - Composite index on visitor_classification and ip_type for analytics
*/

-- Create visitor_detections table for caching detection results
CREATE TABLE IF NOT EXISTS visitor_detections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_hash text NOT NULL,
  visitor_classification text DEFAULT 'uncertain' CHECK (visitor_classification IN ('human', 'bot', 'uncertain')),
  ip_type text DEFAULT 'unknown' CHECK (ip_type IN ('residential', 'mobile', 'datacenter', 'organization', 'vpn', 'proxy', 'unknown')),
  confidence_score integer DEFAULT 50 CHECK (confidence_score >= 0 AND confidence_score <= 100),
  detection_signals jsonb DEFAULT '{}'::jsonb,
  user_agent text DEFAULT '',
  has_javascript boolean DEFAULT true,
  is_headless_browser boolean DEFAULT false,
  is_old_browser boolean DEFAULT false,
  ptr_hostname text DEFAULT '',
  asn_number integer,
  asn_organization text DEFAULT '',
  country_code text DEFAULT '',
  is_mobile_carrier boolean DEFAULT false,
  detection_method text DEFAULT 'simple' CHECK (detection_method IN ('simple', 'fingerprint', 'maxmindLite', 'server_side')),
  cache_expires_at timestamptz DEFAULT (now() + interval '24 hours'),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add enhanced detection columns to lead_gen_analytics
ALTER TABLE lead_gen_analytics
ADD COLUMN IF NOT EXISTS visitor_classification text DEFAULT 'uncertain' CHECK (visitor_classification IN ('human', 'bot', 'uncertain')),
ADD COLUMN IF NOT EXISTS ip_type text DEFAULT 'unknown' CHECK (ip_type IN ('residential', 'mobile', 'datacenter', 'organization', 'vpn', 'proxy', 'unknown')),
ADD COLUMN IF NOT EXISTS has_javascript boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS detection_signals jsonb DEFAULT '{}'::jsonb,
ADD COLUMN IF NOT EXISTS device_authenticity_score integer DEFAULT 50 CHECK (device_authenticity_score >= 0 AND device_authenticity_score <= 100),
ADD COLUMN IF NOT EXISTS is_headless_browser boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS is_old_browser boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS ptr_hostname text DEFAULT '';

-- Enable RLS on visitor_detections table
ALTER TABLE visitor_detections ENABLE ROW LEVEL SECURITY;

-- RLS Policies for visitor_detections
CREATE POLICY "Public can insert visitor detections"
  ON visitor_detections FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Public can view own detections by IP hash"
  ON visitor_detections FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage visitor detections"
  ON visitor_detections FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_visitor_detections_ip_hash ON visitor_detections(ip_hash);
CREATE INDEX IF NOT EXISTS idx_visitor_detections_cache_expires ON visitor_detections(cache_expires_at);
CREATE INDEX IF NOT EXISTS idx_visitor_detections_classification ON visitor_detections(visitor_classification);
CREATE INDEX IF NOT EXISTS idx_visitor_detections_ip_type ON visitor_detections(ip_type);
CREATE INDEX IF NOT EXISTS idx_visitor_detections_created_at ON visitor_detections(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_visitor_classification ON lead_gen_analytics(visitor_classification);
CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_ip_type ON lead_gen_analytics(ip_type);
CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_composite ON lead_gen_analytics(visitor_classification, ip_type, timestamp DESC);

-- Function to automatically clean up expired detection cache
CREATE OR REPLACE FUNCTION cleanup_expired_visitor_detections()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM visitor_detections
  WHERE cache_expires_at < now();
END;
$$;

-- Add helpful comments
COMMENT ON TABLE visitor_detections IS 'Caches visitor detection results with 24-hour expiry for performance optimization';
COMMENT ON COLUMN visitor_detections.ip_hash IS 'SHA-256 hash of visitor IP address for privacy';
COMMENT ON COLUMN visitor_detections.visitor_classification IS 'Detected visitor type: human, bot, or uncertain';
COMMENT ON COLUMN visitor_detections.ip_type IS 'IP address classification for Google Ads compliance';
COMMENT ON COLUMN visitor_detections.detection_signals IS 'JSON object containing all detection factors and scores';
COMMENT ON COLUMN visitor_detections.ptr_hostname IS 'Reverse DNS hostname for identifying server/hosting IPs';
COMMENT ON COLUMN visitor_detections.is_mobile_carrier IS 'True if IP belongs to mobile carrier network';

COMMENT ON COLUMN lead_gen_analytics.visitor_classification IS 'Human/bot classification for analytics segmentation';
COMMENT ON COLUMN lead_gen_analytics.ip_type IS 'IP type for compliance and fraud detection';
COMMENT ON COLUMN lead_gen_analytics.has_javascript IS 'False if visitor has JavaScript disabled (likely bot)';
COMMENT ON COLUMN lead_gen_analytics.detection_signals IS 'JSON object with all detection factors for audit trail';