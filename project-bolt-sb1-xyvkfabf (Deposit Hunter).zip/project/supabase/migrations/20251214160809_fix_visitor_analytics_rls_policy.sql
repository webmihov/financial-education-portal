/*
  # Fix Visitor Analytics RLS Policy

  ## Problem
  - Anonymous visitors are getting 403 Forbidden errors when trying to insert visitor analytics
  - The current RLS policy for INSERT is not working properly for the `anon` role

  ## Changes
  1. Drop the existing INSERT policy
  2. Create a new INSERT policy that allows public (all roles) to insert
  3. Keep SELECT policies restrictive for admin-only access
  
  ## Security
  - INSERT: Open to all roles (public, anon, authenticated) to allow visitor tracking
  - SELECT: Restricted to authenticated users only (admins)
  - UPDATE/DELETE: No policies (implicitly denied)
*/

-- Drop the existing INSERT policy
DROP POLICY IF EXISTS "Anyone can insert visitor analytics" ON visitor_analytics;

-- Create a new policy that allows all roles to insert
CREATE POLICY "Public can insert visitor analytics"
  ON visitor_analytics
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Ensure the SELECT policy exists and is restrictive
DROP POLICY IF EXISTS "Only authenticated users can view visitor analytics" ON visitor_analytics;

CREATE POLICY "Authenticated users can view visitor analytics"
  ON visitor_analytics
  FOR SELECT
  TO authenticated
  USING (true);