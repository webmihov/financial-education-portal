/*
  # Initial Database Schema for Portuguese Websites Comparison Platform

  ## Overview
  This migration creates the complete database schema for a Google Ads compliant 
  Portuguese websites comparison platform with admin CMS functionality.

  ## New Tables
  
  ### 1. websites
  Stores information about Portuguese websites being compared
  - `id` (uuid, primary key)
  - `name` (text) - Website name
  - `rating` (numeric) - Rating out of 5
  - `status_badge` (text) - Registration status text
  - `special_offer` (text) - Special promotion text
  - `pros` (jsonb) - Array of pros
  - `cons` (jsonb) - Array of cons
  - `affiliate_url` (text) - Partner link URL
  - `display_order` (integer) - Sort order
  - `is_active` (boolean) - Published status
  - `icon_name` (text) - Icon identifier
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. reviews
  Stores user reviews and testimonials
  - `id` (uuid, primary key)
  - `user_name` (text) - Reviewer name
  - `location` (text) - City/region in Portugal
  - `review_text` (text) - Review content
  - `is_verified` (boolean) - Verified reviewer badge
  - `is_active` (boolean) - Published status
  - `display_order` (integer) - Sort order
  - `created_at` (timestamptz)

  ### 3. page_content
  Stores editable page content for CMS
  - `id` (uuid, primary key)
  - `section_key` (text, unique) - Section identifier
  - `title` (text) - Section title
  - `subtitle` (text) - Section subtitle
  - `content_json` (jsonb) - Flexible content storage
  - `is_active` (boolean) - Published status
  - `updated_at` (timestamptz)

  ### 4. admin_users
  Stores admin authentication and user management
  - `id` (uuid, primary key)
  - `email` (text, unique) - Admin email
  - `role` (text) - Admin role (admin, editor, viewer)
  - `last_login` (timestamptz) - Last login timestamp
  - `created_at` (timestamptz)

  ### 5. compliance_settings
  Stores compliance and legal configuration
  - `id` (uuid, primary key)
  - `setting_key` (text, unique) - Setting identifier
  - `setting_value` (text) - Setting value
  - `description` (text) - Setting description
  - `updated_at` (timestamptz)

  ### 6. user_interactions
  Tracks user interactions for analytics (anonymized)
  - `id` (uuid, primary key)
  - `action_type` (text) - Type of interaction
  - `website_id` (uuid) - Referenced website if applicable
  - `ip_hash` (text) - Hashed IP for basic analytics
  - `user_agent` (text) - Browser info
  - `timestamp` (timestamptz)

  ## Security
  - Enable RLS on all tables
  - Public read access for public-facing data (websites, reviews, page_content)
  - Admin-only write access for all tables
  - Authenticated-only access for admin tables
*/

-- Create websites table
CREATE TABLE IF NOT EXISTS websites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  rating numeric(2,1) NOT NULL CHECK (rating >= 0 AND rating <= 5),
  status_badge text NOT NULL,
  special_offer text,
  pros jsonb DEFAULT '[]'::jsonb,
  cons jsonb DEFAULT '[]'::jsonb,
  affiliate_url text,
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  icon_name text DEFAULT 'globe',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_name text NOT NULL,
  location text NOT NULL,
  review_text text NOT NULL,
  is_verified boolean DEFAULT false,
  is_active boolean DEFAULT false,
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create page_content table
CREATE TABLE IF NOT EXISTS page_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section_key text UNIQUE NOT NULL,
  title text,
  subtitle text,
  content_json jsonb DEFAULT '{}'::jsonb,
  is_active boolean DEFAULT true,
  updated_at timestamptz DEFAULT now()
);

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  role text DEFAULT 'viewer',
  last_login timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create compliance_settings table
CREATE TABLE IF NOT EXISTS compliance_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value text,
  description text,
  updated_at timestamptz DEFAULT now()
);

-- Create user_interactions table
CREATE TABLE IF NOT EXISTS user_interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action_type text NOT NULL,
  website_id uuid REFERENCES websites(id) ON DELETE SET NULL,
  ip_hash text,
  user_agent text,
  timestamp timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE websites ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE page_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_interactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for websites (public read, admin write)
CREATE POLICY "Public can view active websites"
  ON websites FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can view all websites"
  ON websites FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert websites"
  ON websites FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update websites"
  ON websites FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete websites"
  ON websites FOR DELETE
  TO authenticated
  USING (true);

-- RLS Policies for reviews (public read active, admin write)
CREATE POLICY "Public can view active reviews"
  ON reviews FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can view all reviews"
  ON reviews FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert reviews"
  ON reviews FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update reviews"
  ON reviews FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete reviews"
  ON reviews FOR DELETE
  TO authenticated
  USING (true);

-- RLS Policies for page_content (public read active, admin write)
CREATE POLICY "Public can view active page content"
  ON page_content FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage page content"
  ON page_content FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for admin_users (authenticated only)
CREATE POLICY "Authenticated users can view admin users"
  ON admin_users FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage admin users"
  ON admin_users FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for compliance_settings (public read, admin write)
CREATE POLICY "Public can view compliance settings"
  ON compliance_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage compliance settings"
  ON compliance_settings FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for user_interactions (write for all, admin read)
CREATE POLICY "Anyone can insert interactions"
  ON user_interactions FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view interactions"
  ON user_interactions FOR SELECT
  TO authenticated
  USING (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_websites_display_order ON websites(display_order);
CREATE INDEX IF NOT EXISTS idx_websites_is_active ON websites(is_active);
CREATE INDEX IF NOT EXISTS idx_reviews_display_order ON reviews(display_order);
CREATE INDEX IF NOT EXISTS idx_reviews_is_active ON reviews(is_active);
CREATE INDEX IF NOT EXISTS idx_user_interactions_timestamp ON user_interactions(timestamp);
CREATE INDEX IF NOT EXISTS idx_user_interactions_action_type ON user_interactions(action_type);