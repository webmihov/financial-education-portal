/*
  # Remove Cloaking Infrastructure - Google Ads Compliance

  ## Summary
  This migration removes all visitor detection and cloaking infrastructure to ensure
  full compliance with Google Ads policies against cloaking and deceptive practices.

  ## Changes Made

  ### 1. Tables Dropped
  - `visitor_detections` - Stored visitor classification data
  - `visitor_logs` - Logged all visitor detection events
  - `vds_settings` - Configuration for visitor detection service
  - `vds_service_integrations` - External service integrations
  - `fraud_protection_settings` - Fraud protection configuration

  ### 2. Columns Removed from lead_gen_pages
  - `iframe_version2` - Secondary iframe used for cloaking
  - `visitor_detection_mode` - Mode for visitor detection
  - `enable_maxmind_lite` - MaxMind geolocation toggle
  - `detection_threshold_score` - Detection threshold configuration

  ### 3. Data Updates
  - All pages updated to show content to all visitors (no selective showing)
  - `iframe_visibility_mode` restricted to only accept 'all'

  ## Security
  - No RLS changes needed (tables being dropped)
  - Maintains data integrity for remaining fields
*/

-- Drop all visitor detection and fraud protection tables
DROP TABLE IF EXISTS visitor_logs CASCADE;
DROP TABLE IF EXISTS visitor_detections CASCADE;
DROP TABLE IF EXISTS vds_service_integrations CASCADE;
DROP TABLE IF EXISTS vds_settings CASCADE;
DROP TABLE IF EXISTS fraud_protection_settings CASCADE;

-- Update all existing pages to show content to all visitors
UPDATE lead_gen_pages 
SET iframe_visibility_mode = 'all' 
WHERE iframe_visibility_mode IS NULL OR iframe_visibility_mode != 'all';

-- Drop the old constraint
ALTER TABLE lead_gen_pages 
  DROP CONSTRAINT IF EXISTS lead_gen_pages_iframe_visibility_mode_check;

-- Remove cloaking-related columns from lead_gen_pages
ALTER TABLE lead_gen_pages 
  DROP COLUMN IF EXISTS iframe_version2,
  DROP COLUMN IF EXISTS visitor_detection_mode,
  DROP COLUMN IF EXISTS enable_maxmind_lite,
  DROP COLUMN IF EXISTS detection_threshold_score;

-- Add new constraint that only allows 'all' (prevents future cloaking)
ALTER TABLE lead_gen_pages 
  ADD CONSTRAINT lead_gen_pages_iframe_visibility_mode_check 
  CHECK (iframe_visibility_mode = 'all');
