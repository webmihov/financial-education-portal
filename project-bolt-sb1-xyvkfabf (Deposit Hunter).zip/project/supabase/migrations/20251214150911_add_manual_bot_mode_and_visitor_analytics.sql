/*
  # Add Manual Bot Mode and Visitor Analytics

  ## Overview
  This migration adds manual bot mode control and basic visitor analytics that are
  compliant with Google Ads policies. Unlike the previous cloaking system, this:
  - Only logs visitor statistics AFTER the fact for analytics
  - Uses manual admin control, not automated cloaking
  - Maintains transparency (all real humans see the same content)

  ## Changes

  1. Lead Gen Pages Table Updates
    - Add `manual_hide_iframe` boolean column for admin control
    - Defaults to false (iframe visible to all visitors)
    - When enabled by admin, iframes are hidden from all visitors

  2. New Visitor Analytics Table
    - Create `visitor_analytics` table to track basic statistics
    - Records visitor type classification, page viewed, and what they saw
    - Used ONLY for post-visit analysis, not for real-time cloaking

  3. Indexes
    - Performance indexes for analytics queries

  ## Security
    - RLS enabled on visitor_analytics table
    - Only authenticated admins can view analytics
    - Anonymous users can insert analytics for tracking
*/

-- Add manual bot mode control to lead gen pages
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'lead_gen_pages' AND column_name = 'manual_hide_iframe'
  ) THEN
    ALTER TABLE lead_gen_pages ADD COLUMN manual_hide_iframe boolean DEFAULT false NOT NULL;
  END IF;
END $$;

-- Create visitor type enum if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'visitor_type_enum') THEN
    CREATE TYPE visitor_type_enum AS ENUM ('human', 'bot', 'uncertain');
  END IF;
END $$;

-- Create visitor analytics table for post-visit statistics
CREATE TABLE IF NOT EXISTS visitor_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid REFERENCES lead_gen_pages(id) ON DELETE CASCADE,
  visitor_type visitor_type_enum NOT NULL DEFAULT 'uncertain',
  saw_iframe boolean NOT NULL DEFAULT true,
  user_agent text,
  referrer text,
  ip_hash text,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Enable RLS on visitor analytics
ALTER TABLE visitor_analytics ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Admins can read visitor analytics" ON visitor_analytics;
DROP POLICY IF EXISTS "Anyone can insert visitor analytics" ON visitor_analytics;

-- Allow authenticated admins to read visitor analytics
CREATE POLICY "Admins can read visitor analytics"
  ON visitor_analytics
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow anonymous users to insert analytics (for tracking)
CREATE POLICY "Anyone can insert visitor analytics"
  ON visitor_analytics
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Add performance indexes for visitor analytics queries
CREATE INDEX IF NOT EXISTS idx_visitor_analytics_page_id ON visitor_analytics(page_id);
CREATE INDEX IF NOT EXISTS idx_visitor_analytics_visitor_type ON visitor_analytics(visitor_type);
CREATE INDEX IF NOT EXISTS idx_visitor_analytics_saw_iframe ON visitor_analytics(saw_iframe);
CREATE INDEX IF NOT EXISTS idx_visitor_analytics_created_at ON visitor_analytics(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_visitor_analytics_page_type ON visitor_analytics(page_id, visitor_type);

-- Create helper function to get visitor statistics
CREATE OR REPLACE FUNCTION get_visitor_statistics(page_id_param uuid DEFAULT NULL)
RETURNS TABLE (
  page_id uuid,
  page_slug text,
  page_title text,
  total_visitors bigint,
  human_visitors bigint,
  bot_visitors bigint,
  uncertain_visitors bigint,
  saw_iframe_count bigint,
  hidden_iframe_count bigint,
  human_saw_iframe bigint,
  bot_saw_iframe bigint
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    va.page_id,
    lgp.slug as page_slug,
    lgp.title as page_title,
    COUNT(*) as total_visitors,
    COUNT(*) FILTER (WHERE va.visitor_type = 'human') as human_visitors,
    COUNT(*) FILTER (WHERE va.visitor_type = 'bot') as bot_visitors,
    COUNT(*) FILTER (WHERE va.visitor_type = 'uncertain') as uncertain_visitors,
    COUNT(*) FILTER (WHERE va.saw_iframe = true) as saw_iframe_count,
    COUNT(*) FILTER (WHERE va.saw_iframe = false) as hidden_iframe_count,
    COUNT(*) FILTER (WHERE va.visitor_type = 'human' AND va.saw_iframe = true) as human_saw_iframe,
    COUNT(*) FILTER (WHERE va.visitor_type = 'bot' AND va.saw_iframe = true) as bot_saw_iframe
  FROM visitor_analytics va
  JOIN lead_gen_pages lgp ON va.page_id = lgp.id
  WHERE page_id_param IS NULL OR va.page_id = page_id_param
  GROUP BY va.page_id, lgp.slug, lgp.title;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;