/*
  # Additional Performance Indexes

  ## Overview
  Adds additional composite indexes to optimize common analytics query patterns.
  (Most basic indexes already exist from previous migrations)

  ## New Composite Indexes

  ### lead_gen_analytics table
  1. `idx_lead_gen_analytics_page_event_time` - Page-level analytics with time filtering
  2. `idx_lead_gen_analytics_promo_event_time` - Promotion-level analytics with time filtering
  3. `idx_lead_gen_analytics_page_class_time` - Page analytics by visitor classification

  ## Performance Impact
  - Faster page-specific analytics queries with time ranges
  - Improved promotion performance tracking
  - Better visitor classification analytics per page
*/

-- Composite indexes for optimized analytics queries

-- Page-level analytics with event type and time filtering
CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_page_event_time 
  ON lead_gen_analytics(lead_gen_page_id, event_type, timestamp DESC)
  WHERE lead_gen_page_id IS NOT NULL;

-- Promotion-level analytics with event type and time filtering
CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_promo_event_time 
  ON lead_gen_analytics(promotion_id, event_type, timestamp DESC)
  WHERE promotion_id IS NOT NULL;

-- Page analytics by visitor classification with time filtering
CREATE INDEX IF NOT EXISTS idx_lead_gen_analytics_page_class_time 
  ON lead_gen_analytics(lead_gen_page_id, visitor_classification, timestamp DESC)
  WHERE lead_gen_page_id IS NOT NULL;