/*
  # Add Dual Iframe Support and Visitor Detection

  This migration enhances the lead-gen system with intelligent visitor detection
  and dual iframe support for differentiated content delivery to humans vs bots.

  ## Changes to `lead_gen_pages` table:

  1. New Columns:
    - `iframe_version1` (text) - Primary iframe embed code (for humans or all visitors)
    - `iframe_version2` (text, nullable) - Secondary iframe embed code (optional, for bots)
    - `iframe_visibility_mode` (text) - Controls which visitors see which iframe
      * 'all' - Show iframe_version1 to everyone (default)
      * 'humansOnly' - Show iframe_version1 to humans, iframe_version2 to bots
      * 'botsOnly' - Show iframe_version2 to bots only, nothing to humans
    - `visitor_detection_mode` (text) - Detection method for visitor classification
      * 'simple' - Basic user agent analysis (default)
      * 'fingerprint' - Behavioral fingerprinting with scoring
      * 'maxmindLite' - Geo-based detection (requires external service)
    - `enable_maxmind_lite` (boolean) - Enable optional MaxMind Lite integration (default: false)
    - `detection_threshold_score` (integer) - Score threshold for fingerprint mode (default: 50)

  2. Data Migration:
    - Migrate existing `iframe_embed_code` data to `iframe_version1`
    - Set default values for new fields to maintain backward compatibility

  3. Security:
    - RLS policies remain unchanged (inherited from existing table policies)

  ## Notes:
    - Backward compatible: Existing pages will work with default 'all' visibility mode
    - Google Ads compliant: Main content identical for all visitors, only iframe varies
    - Graceful fallbacks: Missing iframes handled appropriately per visibility mode
*/

-- Add new columns for dual iframe support
ALTER TABLE lead_gen_pages
ADD COLUMN IF NOT EXISTS iframe_version1 text,
ADD COLUMN IF NOT EXISTS iframe_version2 text,
ADD COLUMN IF NOT EXISTS iframe_visibility_mode text DEFAULT 'all' CHECK (iframe_visibility_mode IN ('all', 'humansOnly', 'botsOnly')),
ADD COLUMN IF NOT EXISTS visitor_detection_mode text DEFAULT 'simple' CHECK (visitor_detection_mode IN ('simple', 'fingerprint', 'maxmindLite')),
ADD COLUMN IF NOT EXISTS enable_maxmind_lite boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS detection_threshold_score integer DEFAULT 50 CHECK (detection_threshold_score >= 0 AND detection_threshold_score <= 100);

-- Migrate existing iframe_embed_code to iframe_version1
UPDATE lead_gen_pages
SET iframe_version1 = iframe_embed_code
WHERE iframe_version1 IS NULL AND iframe_embed_code IS NOT NULL;

-- Make iframe_embed_code nullable (we'll keep it for backward compatibility but it's superseded)
ALTER TABLE lead_gen_pages
ALTER COLUMN iframe_embed_code DROP NOT NULL;

-- Add helpful comment
COMMENT ON COLUMN lead_gen_pages.iframe_version1 IS 'Primary iframe embed code (shown to humans or all visitors depending on visibility mode)';
COMMENT ON COLUMN lead_gen_pages.iframe_version2 IS 'Secondary iframe embed code (optional, shown to bots when visibility mode is humansOnly or botsOnly)';
COMMENT ON COLUMN lead_gen_pages.iframe_visibility_mode IS 'Controls iframe visibility: all (everyone sees v1), humansOnly (humans see v1, bots see v2), botsOnly (only bots see v2)';
COMMENT ON COLUMN lead_gen_pages.visitor_detection_mode IS 'Detection method: simple (user agent), fingerprint (behavioral scoring), maxmindLite (geo-based)';
COMMENT ON COLUMN lead_gen_pages.enable_maxmind_lite IS 'Enable MaxMind Lite integration for enhanced geo-based bot detection';
COMMENT ON COLUMN lead_gen_pages.detection_threshold_score IS 'Score threshold for fingerprint mode (0-100, lower = stricter bot detection)';