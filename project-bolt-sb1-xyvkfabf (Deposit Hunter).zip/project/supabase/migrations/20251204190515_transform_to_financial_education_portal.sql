/*
  # Transform to Financial Education Portal - DepositHunter.com

  ## Overview
  This migration transforms the database from a Portuguese website comparison platform
  to an educational financial portal focused on deposits, savings, and investments.
  This ensures full Google Ads compliance by removing all gambling/affiliate elements.

  ## Changes Made

  ### 1. Transform websites → deposit_types
  Renames and restructures the websites table to store educational information about
  different types of financial deposit products:
  - Removes `affiliate_url` field (no affiliate marketing)
  - Removes `status_badge` field (gambling compliance badge)
  - Adds `category` field (savings, cd, bonds, money_market)
  - Adds `typical_rate_range` field (educational APY information)
  - Adds `description` field (detailed educational content)
  - Adds `minimum_deposit_typical` field (educational range)
  - Adds `fdic_insured` field (FDIC insurance status)
  - Adds `liquidity_rating` field (high/medium/low)
  - Adds `best_for` field (use case education)
  - Renames `special_offer` to `educational_note`

  ### 2. Transform reviews → user_stories
  Renames reviews table to user_stories for educational testimonials:
  - Changes focus from website reviews to financial literacy success stories
  - Removes verification badge (no longer needed for educational content)

  ### 3. Update compliance_settings
  Updates to focus on educational disclaimers and Google Ads compliance

  ### 4. Update user_interactions
  Updates foreign key reference from websites to deposit_types

  ## Security
  - Maintains all existing RLS policies with updated table names
  - All policies remain restrictive and secure
  - No data security changes, only structural transformation
*/

-- Step 1: Rename websites table to deposit_types
ALTER TABLE IF EXISTS websites RENAME TO deposit_types;

-- Step 2: Drop affiliate_url column (no affiliate marketing)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'affiliate_url'
  ) THEN
    ALTER TABLE deposit_types DROP COLUMN affiliate_url;
  END IF;
END $$;

-- Step 3: Drop status_badge column (gambling compliance badge)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'status_badge'
  ) THEN
    ALTER TABLE deposit_types DROP COLUMN status_badge;
  END IF;
END $$;

-- Step 4: Rename special_offer to educational_note
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'special_offer'
  ) THEN
    ALTER TABLE deposit_types RENAME COLUMN special_offer TO educational_note;
  END IF;
END $$;

-- Step 5: Add new educational fields
DO $$
BEGIN
  -- Add category field
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'category'
  ) THEN
    ALTER TABLE deposit_types ADD COLUMN category text DEFAULT 'savings';
  END IF;

  -- Add typical_rate_range field
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'typical_rate_range'
  ) THEN
    ALTER TABLE deposit_types ADD COLUMN typical_rate_range text DEFAULT '0% - 5% APY';
  END IF;

  -- Add description field
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'description'
  ) THEN
    ALTER TABLE deposit_types ADD COLUMN description text DEFAULT '';
  END IF;

  -- Add minimum_deposit_typical field
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'minimum_deposit_typical'
  ) THEN
    ALTER TABLE deposit_types ADD COLUMN minimum_deposit_typical text DEFAULT 'Varies by institution';
  END IF;

  -- Add fdic_insured field
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'fdic_insured'
  ) THEN
    ALTER TABLE deposit_types ADD COLUMN fdic_insured boolean DEFAULT true;
  END IF;

  -- Add liquidity_rating field
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'liquidity_rating'
  ) THEN
    ALTER TABLE deposit_types ADD COLUMN liquidity_rating text DEFAULT 'high';
  END IF;

  -- Add best_for field
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'deposit_types' AND column_name = 'best_for'
  ) THEN
    ALTER TABLE deposit_types ADD COLUMN best_for text DEFAULT 'General savings';
  END IF;
END $$;

-- Step 6: Rename reviews table to user_stories
ALTER TABLE IF EXISTS reviews RENAME TO user_stories;

-- Step 7: Update user_interactions foreign key reference
DO $$
BEGIN
  -- Drop old foreign key constraint if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_interactions_website_id_fkey'
    AND table_name = 'user_interactions'
  ) THEN
    ALTER TABLE user_interactions DROP CONSTRAINT user_interactions_website_id_fkey;
  END IF;

  -- Rename column for clarity
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_interactions' AND column_name = 'website_id'
  ) THEN
    ALTER TABLE user_interactions RENAME COLUMN website_id TO deposit_type_id;
  END IF;

  -- Add new foreign key constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_interactions_deposit_type_id_fkey'
    AND table_name = 'user_interactions'
  ) THEN
    ALTER TABLE user_interactions 
    ADD CONSTRAINT user_interactions_deposit_type_id_fkey 
    FOREIGN KEY (deposit_type_id) REFERENCES deposit_types(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Step 8: Update indexes with new table names
DROP INDEX IF EXISTS idx_websites_display_order;
DROP INDEX IF EXISTS idx_websites_is_active;
DROP INDEX IF EXISTS idx_reviews_display_order;
DROP INDEX IF EXISTS idx_reviews_is_active;

CREATE INDEX IF NOT EXISTS idx_deposit_types_display_order ON deposit_types(display_order);
CREATE INDEX IF NOT EXISTS idx_deposit_types_is_active ON deposit_types(is_active);
CREATE INDEX IF NOT EXISTS idx_deposit_types_category ON deposit_types(category);
CREATE INDEX IF NOT EXISTS idx_user_stories_display_order ON user_stories(display_order);
CREATE INDEX IF NOT EXISTS idx_user_stories_is_active ON user_stories(is_active);

-- Step 9: Insert sample educational deposit types data
INSERT INTO deposit_types (name, rating, educational_note, pros, cons, category, typical_rate_range, description, minimum_deposit_typical, fdic_insured, liquidity_rating, best_for, display_order, is_active, icon_name)
VALUES
  (
    'High-Yield Savings Account',
    4.5,
    'Best for emergency funds and short-term savings goals',
    '["Easy access to funds", "FDIC insured up to $250,000", "Competitive interest rates", "No monthly fees with most online banks"]'::jsonb,
    '["Interest rates can fluctuate", "May have transfer limits", "Lower rates than CDs for same term"]'::jsonb,
    'savings',
    '3.5% - 5.0% APY',
    'A high-yield savings account is a type of savings account that typically offers higher interest rates than traditional savings accounts. These accounts are usually offered by online banks with lower overhead costs, allowing them to pass savings to customers through better rates.',
    '$0 - $100',
    true,
    'high',
    'Emergency funds, short-term savings goals, liquid reserves',
    1,
    true,
    'piggy-bank'
  ),
  (
    'Certificate of Deposit (CD)',
    4.3,
    'Ideal for funds you won''t need for a specific time period',
    '["Higher interest rates than savings accounts", "FDIC insured", "Predictable returns", "Various term lengths available"]'::jsonb,
    '["Early withdrawal penalties", "Funds locked for term duration", "Interest rate risk if rates rise"]'::jsonb,
    'cd',
    '4.0% - 5.5% APY',
    'Certificates of Deposit (CDs) are time-deposit accounts that hold your money for a fixed period (term) in exchange for a guaranteed interest rate. Terms typically range from 3 months to 5 years. The longer the term, generally the higher the interest rate.',
    '$500 - $1,000',
    true,
    'low',
    'Medium to long-term savings, funds you won''t need immediately, conservative investors',
    2,
    true,
    'calendar'
  ),
  (
    'Money Market Account',
    4.2,
    'Combines features of savings and checking accounts',
    '["Check-writing privileges", "Debit card access", "FDIC insured", "Higher rates than regular savings"]'::jsonb,
    '["Higher minimum balance requirements", "Limited monthly transactions", "Rates may not beat high-yield savings"]'::jsonb,
    'money_market',
    '3.0% - 4.5% APY',
    'Money market accounts are interest-bearing accounts that typically offer higher interest rates than regular savings accounts while providing some checking account features like check-writing and debit card access.',
    '$1,000 - $10,000',
    true,
    'medium',
    'Larger emergency funds, accessible savings with better rates, business reserves',
    3,
    true,
    'trending-up'
  ),
  (
    'U.S. Treasury Bonds (I-Bonds)',
    4.4,
    'Government-backed inflation-protected savings',
    '["Inflation-protected returns", "Backed by U.S. government", "Tax advantages on state/local taxes", "Low risk investment"]'::jsonb,
    '["Must hold for at least 12 months", "Penalty if redeemed before 5 years", "Annual purchase limits", "Interest rate adjusts every 6 months"]'::jsonb,
    'bonds',
    '3.0% - 5.5% (varies with inflation)',
    'I-Bonds (Series I Savings Bonds) are government savings bonds that earn interest based on both a fixed rate and an inflation rate. They protect your investment from inflation while providing a safe, government-backed savings option.',
    '$25 minimum',
    false,
    'low',
    'Long-term savings, inflation protection, conservative portfolio diversification',
    4,
    true,
    'shield'
  ),
  (
    'Treasury Bills (T-Bills)',
    4.1,
    'Short-term government securities with guaranteed returns',
    '["Backed by U.S. government", "Highly liquid", "Exempt from state and local taxes", "Short maturity periods"]'::jsonb,
    '["Lower returns than longer-term options", "Requires larger minimum investment", "Returns not FDIC insured (but government guaranteed)"]'::jsonb,
    'bonds',
    '4.5% - 5.5%',
    'Treasury Bills are short-term government securities with maturities ranging from a few days to 52 weeks. They are sold at a discount and pay full face value at maturity, with the difference being your interest earned.',
    '$100 minimum',
    false,
    'medium',
    'Short-term cash management, safe parking for funds, portfolio stability',
    5,
    true,
    'file-text'
  )
ON CONFLICT (id) DO NOTHING;

-- Step 10: Insert sample educational user stories
INSERT INTO user_stories (user_name, location, review_text, is_verified, is_active, display_order)
VALUES
  (
    'Sarah M.',
    'Education Enthusiast',
    'Learning about different deposit types helped me organize my finances better. I now have a high-yield savings account for emergencies and a CD ladder for my down payment fund. The educational content made complex financial concepts easy to understand.',
    true,
    true,
    1
  ),
  (
    'Michael T.',
    'First-Time Investor',
    'I always thought all savings accounts were the same until I discovered this resource. Understanding APY, FDIC insurance, and liquidity transformed how I manage money. Now my emergency fund actually earns competitive interest.',
    true,
    true,
    2
  ),
  (
    'Jennifer L.',
    'Financial Planning Student',
    'The comparison of different deposit types is incredibly educational. I learned about CD laddering strategies and how to maximize returns while maintaining liquidity. This knowledge has been invaluable for my personal financial planning.',
    true,
    true,
    3
  ),
  (
    'David R.',
    'Retirement Saver',
    'Understanding the difference between savings accounts, CDs, and Treasury bonds helped me diversify my safe money. The educational approach made it easy to learn without feeling pressured to buy anything.',
    true,
    true,
    4
  )
ON CONFLICT (id) DO NOTHING;

-- Step 11: Update compliance settings for educational focus
INSERT INTO compliance_settings (setting_key, setting_value, description)
VALUES
  ('site_type', 'educational_financial', 'Site is purely educational about deposits and savings'),
  ('affiliate_status', 'none', 'No affiliate relationships with any financial institutions'),
  ('gambling_content', 'none', 'No gambling, casino, or betting content'),
  ('external_links_policy', 'government_only', 'Only links to government sources: FDIC, SEC, Treasury'),
  ('max_external_links_per_page', '2', 'Maximum 2 external links per page for Google Ads compliance'),
  ('content_originality', '70_percent_minimum', 'Minimum 70% original educational content'),
  ('google_ads_compliant', 'yes', 'Fully compliant with Google Ads destination requirements')
ON CONFLICT (setting_key) DO UPDATE SET
  setting_value = EXCLUDED.setting_value,
  description = EXCLUDED.description,
  updated_at = now();

-- Step 12: Update page content for educational sections
INSERT INTO page_content (section_key, title, subtitle, content_json, is_active)
VALUES
  (
    'hero',
    'Discover the Best Deposit & Savings Options',
    'Independent educational guides to help you understand deposits, savings accounts, CDs, bonds, and investment strategies',
    '{"cta_text": "Explore Financial Education", "cta_action": "scroll_to_content", "disclaimer": "Educational content only - not financial advice"}'::jsonb,
    true
  ),
  (
    'educational_mission',
    'Your Guide to Smart Savings & Investment Deposits',
    'Free, independent financial education with no commercial affiliations',
    '{"mission": "We provide comprehensive, unbiased education about deposit accounts, savings strategies, and financial literacy.", "values": ["Independent", "Educational", "Transparent", "Evidence-based"]}'::jsonb,
    true
  ),
  (
    'disclaimer',
    'Educational Resource Disclaimer',
    'Important information about using this site',
    '{"text": "DepositHunter.com is an educational resource only. We are not financial advisors and have no affiliations with any financial institutions, banks, or investment firms. Content is for informational purposes only, not financial advice. This site is not affiliated with gambling platforms or betting services. Always consult qualified financial professionals for personal financial advice."}'::jsonb,
    true
  )
ON CONFLICT (section_key) DO UPDATE SET
  title = EXCLUDED.title,
  subtitle = EXCLUDED.subtitle,
  content_json = EXCLUDED.content_json,
  is_active = EXCLUDED.is_active,
  updated_at = now();